import setuptools

with open("requirements.txt", "r") as f:
    requirements = f.read().splitlines()

setuptools.setup(
    name="tabtransformer",
    description="Tabular data transformer for common ML tasks.",
    url="https://github.com/betterdataai/data",
    author="Li, Jiayu",
    author_email="jiayu@betterdata.ai",
    packages=setuptools.find_packages("."),
    version="1.0.0",
    install_requires=requirements,
    package_data={
        "tabtransformer": [
            "column/transformer/encoding/country.csv"
        ]
    },
)
