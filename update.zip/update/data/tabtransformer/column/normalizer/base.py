"""Common structure for normalizers for different standard types."""

import logging
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Tuple, Type, Union

import numpy as np
import pandas as pd

from ...dtypes import ColumnName, SType
from ...utils import log, log_time, make_enum

NumericalType = "float64"
"""The numerical data type after normalization."""
MainValueColumn = "val"
"""Name of the column of main value after normalization."""


class StdColumnNormalizer(ABC):
    """
    Standard column normalizer to normalize standard boolean/categorical/numerical data to numerical matrix.
    """
    registry: Dict[SType, Type["StdColumnNormalizer"]] = {}
    """Registry of standardized for different standard types."""

    def __init__(self,
                 name: str = "",
                 parent: ColumnName = ""):
        """
        Initialize a new instance of `ColumnTransformer`, for a new column.

        Parameters
        ----------
        name : str, optional
            Name of the standard column.
        parent : ColumnName, optional
            Name of the original column in raw data.
        """
        self.name = name
        self.parent = parent
        self.normalized_columns = None
        self._fitted = False

    @property
    @abstractmethod
    def stype(self) -> SType:
        """Standard data type."""
        raise NotImplementedError()

    @property
    def normalized_dim(self) -> int:
        """Number of dimensions after normalization."""
        self._check_fitted("getting dimension")
        return len(self.normalized_columns)

    @log_time("Fitting standardized column", "Finished fitting stamdardized column",
              start_level=log.TRACE_LEVEL, end_level=logging.DEBUG, with_name=True)
    def fit(self, data: pd.Series):
        """
        Fit the normalizer to given data.
        
        Parameters
        ----------
        data : pd.Series
            The standardized data to fit the normalizer with.
        """
        data = self._validate_dtype(data)
        self._fit(data)
        self._fitted = True
    
    def _validate_dtype(self, data: pd.Series) -> pd.Series:
        return data.astype(self.stype.pd_dtype)
    
    def _check_fitted(self, act: str):
        if not self._fitted:
            raise RuntimeError(f"The normalizer is not yet fitted. Please fit before {act}.")
    
    def normalize(self, data: pd.Series) -> pd.DataFrame:
        """
        Normalize a given standardized column.

        Parameters
        ----------
        data : pd.Series
            The standardized column to normalize.

        Returns
        -------
        pd.DataFrame
            The normalized data.
        """
        self._check_fitted("normalization")
        data = self._validate_dtype(data)
        result = self._normalize(data)
        result = result[self.normalized_columns].astype(NumericalType)
        return result

    @abstractmethod
    def _normalize(self, data: pd.Series) -> pd.DataFrame:
        raise NotImplementedError()

    def inverse_normalize(self, normalized: pd.DataFrame) -> pd.Series:
        """
        Recover a given normalized matrix back to standard column.

        Parameters
        ----------
        normalized : pd.DataFrame
            The normalized data.

        Returns
        -------
        pd.DataFrame
            The standardized column recovered from the normalized data.
        """
        self._check_fitted("inverse normalization")
        normalized = normalized.astype(NumericalType)
        result = self._inverse_normalize(normalized)
        return self._validate_dtype(result)

    @abstractmethod
    def _inverse_normalize(self, normalized: pd.DataFrame) -> pd.Series:
        raise NotImplementedError()

    @abstractmethod
    def _fit(self, data: pd.Series):
        raise NotImplementedError()

    def discretize(self, data: pd.Series) -> pd.Series:
        """
        Discretize the given data.

        Parameters
        ----------
        data : pd.Series
            The data to discretize.

        Returns
        -------
        pd.Series
            The discretized data.
        """
        return data

    def inverse_discretize(self, data: pd.Series) -> pd.Series:
        """
        Inverse the discretization step. If the original data is continuous, recovered continuous data is very unlikely
        to be identical to the original.

        Parameters
        ----------
        data : pd.Series
            The discretized data.

        Returns
        -------
        pd.Series
            The recovered data from discretized result.
        """
        return data

    def __repr__(self) -> str:
        return f"{self.__name__}({self.parent}|{self.name})"

    @staticmethod
    def _reshape_to_2d(data: pd.Series) -> np.ndarray:
        return data.values.reshape((-1, 1))

    @classmethod
    def make(cls, stype: Union[str, SType], *args, **kwargs) -> "StdColumnNormalizer":
        """
        Construct a `StdColumnNormalizer` instance based on the given types and arguments.

        Parameters
        ----------
        stype : str or SType
            The standard column type of the normalizer.
        method_type: str or XXXNormalizerMethods
            The method type for handling the `stype` (except for non_std).
        *args, **kwargs
            Parameters to the normalizer of the given method type in the given stype.
        """
        stype: SType = make_enum(stype, SType)
        return cls.registry[stype].make(stype, *args, **kwargs)

    @property
    @abstractmethod
    def normalized_span_info(self) -> List[Tuple[int, SType]]:
        """
        Normalized columns span information (list of width (int) and standardized column type).
        Non-standard columns are excluded.
        The order follows the output data columns of calling
        [`normalize`](/tabtransformer/column/normalizer#tabtransformer.column.normalizer.StdColumnNormalizer.normalize).
        Non-target and target columns are separated in this order.
        This result will be helpful in activation function construction for some training tasks.
        """
        raise NotImplementedError()

    @classmethod
    @abstractmethod
    def validate_kwargs(cls, args: Dict[str, Any]):
        """
        Check whether the arguments are valid to the constructor.

        Parameters
        ----------
        args : dict
            The arguments to the constructor.

        Raises
        ------
        ValueError | jsonschema.ValidationError
            If the arguments are invalid.
        """
        raise NotImplementedError()


