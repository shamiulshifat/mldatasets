"""Label encoding."""

from copy import deepcopy
from typing import Any, Collection, Dict, List, Optional, Tuple

import jsonschema
import pandas as pd
from sklearn.preprocessing import LabelEncoder

from .base import MulticlassNormalizerMethods, MulticlassNormalizer
from ..base import StdColumnNormalizer
from ....dtypes import ColumnName, SType
from ....utils import register


@register(MulticlassNormalizer.sub_registry, MulticlassNormalizerMethods.label)
class LabelNormalizer(MulticlassNormalizer):
    """
    Multi-class column normalizer by label-encoding.
    The scikit-learn component used is
    [`LabelEncoder`](https://scikit-learn.org/stable/modules/generated/sklearn.preprocessing.LabelEncoder.html).
    The label number is transformed again by another NumericalNormalizer.
    """
    def __init__(self,
                 name: str = "",
                 parent: ColumnName = "",
                 *,
                 enforce_categories: Optional[Collection] = None,
                 num_normalization_method: str = "min_max",
                 **kwargs):
        """
        Parameters
        ----------
        num_normalized_method : str, optional
            The numerical normalization method of labels.
            By default, min-max scaling is used.
        **kwargs
            Arguments to the numerical normalizer.
        Other parameters are inherited from parent `MulticlassNormalizer`.
        """
        super().__init__(name, parent, enforce_categories=enforce_categories)
        self.le = LabelEncoder()
        self.num_norm = StdColumnNormalizer.make(
            SType.numerical, num_normalization_method,
            name=f"{name}|NUM", parent=parent, rounding=0, min_val=0, **kwargs
        )

    def _normalize(self, data: pd.Series) -> pd.DataFrame:
        numerical = self.le.transform(data)
        return self.num_norm.normalize(pd.Series(numerical))

    def _inverse_normalize(self, normalized: pd.DataFrame) -> pd.Series:
        numerical = self.num_norm.inverse_normalize(normalized)
        numerical = numerical.clip(upper=len(self.le.classes_) - 1).round().astype("int")
        inverse_transformed = self.le.inverse_transform(numerical)
        return pd.Series(inverse_transformed)

    def _fit_categorical(self, data: pd.Series):
        transformed = self.le.fit_transform(data)
        self.num_norm.fit(pd.Series(transformed))
        self.normalized_columns = self.num_norm.normalized_columns

    @property
    def normalized_span_info(self) -> List[Tuple[int, SType]]:
        return self.num_norm.normalized_span_info

    @classmethod
    def validate_kwargs(cls, args: Dict[str, Any]):
        if "enforce_categories" in args:
            cls._validate_kwargs_common({
                "enforce_categories": args["enforce_categories"]
            })
        schema = {
            "type": "object",
            "properties": {
                "num_normalization_method": {
                    "type": "string",
                    "enum": ["identity", "max_abs", "min_max", "quantile", "robust", "standard", "cluster_based"]
                }
            }
        }
        jsonschema.validate(instance=args, schema=schema)

        if "rounding" in args or "min_val" in args:
            raise ValueError("Rounding and min values are inferred from label encoder and should not be provided.")

        args = deepcopy(args)
        method = args.get("num_normalization_method", "min_max")
        for a in ["enforce_categories", "num_normalization_method", "method_type"]:
            if a in args:
                del args[a]
        args["method_type"] = method
        cls.registry[SType.numerical].validate_kwargs(args)
