"""Numerical transformations wrappers."""

from abc import ABC, abstractmethod
from typing import Any, Dict, Optional, Type, Union

import jsonschema
import numpy as np

from ....utils import register

_AllowedType = Union[float, np.ndarray]


class BaseTransform(ABC):
    """Numerical transformation for better understanding of distribution."""
    registry: Dict[str, Type["BaseTransform"]] = {}

    @abstractmethod
    def fit(self, v: np.ndarray):
        """
        Fit the transformation on the given data.

        Parameters
        ----------
        v : np.ndarray
            The data to fit the transformation on.
        """
        raise NotImplementedError()

    @abstractmethod
    def forward(self, v: _AllowedType) -> _AllowedType:
        """
        Apply the transform to the given data.

        Parameters
        ----------
        v : float or np.ndarray
            The value to apply the transformation on.

        Returns
        -------
        float or np.ndarray
            Transformed data, in the format of the input data.
        """
        raise NotImplementedError()

    def backward(self, v: _AllowedType) -> _AllowedType:
        """
        Reverse the transformation from a transformed data.

        Parameters
        ----------
        v : float or np.ndarray
            The value after applying the transformation.

        Returns
        -------
        float or np.ndarray
            The recovered original data, in the format of the input data.
        """
        raise NotImplementedError()

    @classmethod
    def make(cls, transform_type: str, **kwargs) -> "BaseTransform":
        """
        Make a transformation from given information.

        Parameters
        ----------
        transform_type : str
            The transform type name.
        **kwargs
            Arguments to this transformation.
        """
        return cls.registry[transform_type](**kwargs)

    @classmethod
    @abstractmethod
    def validate_kwargs(cls, args: Dict[str, Any]):
        """
        Check whether the arguments are valid to the constructor.

        Parameters
        ----------
        args : dict
            The arguments to the constructor.

        Raises
        ------
        ValueError | jsonschema.ValidationError
            If the arguments are invalid.
        """
        raise NotImplementedError()


@register(BaseTransform.registry, "log")
class LogTransform(BaseTransform):
    """Apply log function on the data. Data will be made positive if negative value is found."""
    def __init__(self, *,
                 eps: float = 1,
                 min_val: Optional[float] = None,
                 base: Optional[float] = None):
        """
        Initialize a log transform instance.

        Parameters
        ----------
        eps : float, optional
            The minimum positive if some data is found to be negative or 0.
        min_val : float, optional
            The minimum value in the dataset.
            If not provided, we will learn from the data given while fitting.
        base : float, optional
            Logarithm base.
            If not provided, the ln value will be calculated (base is the natural number e).
        """
        if eps <= 0:
            raise ValueError("The smallest value cannot be negative for log transformation.")
        self.eps = eps
        self.min_val = min_val
        self.base = base

    def fit(self, v: np.ndarray):
        if self.min_val is None:
            self.min_val = np.min(v)

    def forward(self, v: _AllowedType) -> _AllowedType:
        if self.min_val <= 0:
            v = v - self.min_val + self.eps
        if self.base is None:
            return np.log(v)
        if self.base == 2:
            return np.log2(v)
        if self.base == 10:
            return np.log10(v)
        return np.log(v) / np.log(self.base)

    def backward(self, v: _AllowedType) -> _AllowedType:
        if self.base is None:
            v = np.exp(v)
        else:
            v = np.power(self.base, v)
        if self.min_val <= 0:
            return v - self.eps + self.min_val
        return v

    @classmethod
    def validate_kwargs(cls, args: Dict[str, Any]):
        schema = {
            "type": "object",
            "properties": {
                "eps": {
                    "type": "number",
                    "exclusiveMinimum": 0
                },
                "min_val": {
                    "oneOf": [
                        {"type": "null"},
                        {"type": "number"}
                    ]
                },
                "base": {
                    "oneOf": [
                        {"type": "null"},
                        {"type": "number", "exclusiveMinimum": 0}
                    ]
                }
            },
            "additionalProperties": False
        }
        jsonschema.validate(instance=args, schema=schema)

