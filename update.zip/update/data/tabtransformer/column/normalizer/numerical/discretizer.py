"""Helpers for discretization."""

import enum
from abc import ABC, abstractmethod
from typing import Dict, Union, Type

import numpy as np
import pandas as pd
from sklearn.preprocessing import KBinsDiscretizer as KBins
from sklearn.cluster import KMeans

from ....dtypes import RawDType
from ....utils import make_enum, register


class DiscretizerAlgo(enum.Enum):
    """Discretization algorithms."""

    kbins = enum.auto()
    """KBins discretizer."""
    kmeans = enum.auto()
    """KMeans cluster."""


class Discretizer(ABC):
    """A class that converts a target column to categorical."""
    registry: Dict[DiscretizerAlgo, Type["Discretizer"]] = {}

    def __init__(self,
                 discretize_threshold: int = 20):
        """
        Initialize a discretizer instance.

        Parameters
        ----------
        discretize_threshold : int, optional
            The maximum number of unique numerical values for it to be treated as numerical.
            If exceeded, some discretization will be done. Default value is 20.
        **kwargs
            The arguments to the sklearn component.
        """
        self.discretize_threshold = discretize_threshold
        self._fitted = False
        self._original_dtype = None
        self._need_conversion = False
        self._need_model = False

    def fit(self, data: pd.Series):
        """
        Fit the data for discretization.

        Parameters
        ----------
        data : pd.Series
            The data to discretize on.
        """
        dtype = data.dtype
        self._original_dtype = dtype
        if RawDType.numerical.is_valid_dtype(str(dtype)):
            self._need_conversion = True
            if data.nunique(dropna=False) > self.discretize_threshold:
                self._need_model = True
                data = self._make_2d(data)
                self._fit(data)
        self._fitted = True

    @abstractmethod
    def _fit(self, data: np.ndarray):
        raise NotImplementedError()

    def _check_fitted(self, act: str):
        if not self._fitted:
            raise NotImplementedError(f"The discretizer is not yet fitted. Please fit before {act}.")

    def discretize(self, data: pd.Series) -> pd.Series:
        """
        Discretize the given data.

        Parameters
        ----------
        data : pd.Series
            The data to discretize on.

        Returns
        -------
        pd.Series
            The discretized data.
        """
        self._check_fitted("discretization")
        if self._need_conversion:
            if self._need_model:
                data = self._make_2d(data)
                data = self._discretize(data)
            return data.astype("str")
        return data.copy()

    @abstractmethod
    def _discretize(self, data: np.ndarray) -> pd.Series:
        raise NotImplementedError()

    @staticmethod
    def _make_2d(data: pd.Series) -> np.ndarray:
        return data.values.reshape((-1, 1))

    def recover(self, data: pd.Series) -> pd.Series:
        """
        Recover the discretized data back to the original format.

        Parameters
        ----------
        data : pd.Series
            The after discretization.

        Returns
        -------
        pd.Series
            The recovered data.
        """
        self._check_fitted("recovery")
        if self._need_conversion:
            if self._need_model:
                data = self._recover(data)
            return data.astype(self._original_dtype)
        return data.copy()

    @abstractmethod
    def _recover(self, data: pd.Series) -> pd.Series:
        raise NotImplementedError()

    @classmethod
    def make(cls,
             algo: Union[str, DiscretizerAlgo] = DiscretizerAlgo.kmeans,
             **kwargs) -> "Discretizer":
        """
        Make a concrete discretizer instance.

        Parameters
        ----------
        algo : DiscretizerAlgo, optional
            The discretization algorithm to apply.
        **kwargs
            Other arguments to the corresponding scikit-learn model.
        """
        return cls.registry[make_enum(algo, DiscretizerAlgo)](**kwargs)


@register(Discretizer.registry, DiscretizerAlgo.kbins)
class KBinsDiscretizer(Discretizer):
    """
    [K-Bins discretizer](https://scikit-learn.org/stable/modules/generated/sklearn.preprocessing.KBinsDiscretizer.html)
    from scikit-learn preprocessing.
    """
    def __init__(self,
                 discretize_threshold: int = 20,
                 **kwargs):
        super().__init__(discretize_threshold)
        self.discretizer = KBins(discretize_threshold, encode="ordinal", **kwargs)

    def _fit(self, data: np.ndarray):
        self.discretizer.fit(data)

    def _discretize(self, data: np.ndarray) -> pd.Series:
        discretized = self.discretizer.transform(data)
        return pd.Series(discretized.reshape((-1,)))

    def _recover(self, data: pd.Series) -> pd.Series:
        data = self._make_2d(data)
        return pd.Series(self.discretizer.inverse_transform(data).reshape((-1,)))


@register(Discretizer.registry, DiscretizerAlgo.kmeans)
class KMeansDiscretizer(Discretizer):
    """
    [K-Means clustering](https://scikit-learn.org/stable/modules/generated/sklearn.cluster.KMeans.html) as
    discretization. To recover, we will assume Gaussian distribution and randomly sample from there.
    """
    def __init__(self,
                 discretize_threshold: int = 20,
                 **kwargs):
        super().__init__(discretize_threshold)
        self.kmeans = KMeans(discretize_threshold, **kwargs)
        self._stds = None

    def _fit(self, data: np.ndarray):
        self.kmeans.fit(data)
        n_clusters = len(self.kmeans.cluster_centers_)
        self._stds = np.zeros(n_clusters)
        for i in range(n_clusters):
            extracted = data[self.kmeans.labels_ == i, :].reshape((-1,))
            self._stds[i] = extracted.std()

    def _discretize(self, data: np.ndarray) -> pd.Series:
        return pd.Series(self.kmeans.predict(data))

    def _recover(self, data: pd.Series) -> pd.Series:
        means = self.kmeans.cluster_centers_[data.values]
        stds = self._stds[data.values]
        data = np.random.normal(means, stds)
        return pd.Series(data)
