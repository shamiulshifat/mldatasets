"""Transformer for handling categorical data."""

import logging
import numbers
from copy import deepcopy
from typing import Any, Dict, Optional, Union

import jsonschema
import pandas as pd

from .base import ColumnTransformer, FillNaPolicy, MainValueColumn
from ..normalizer import StdColumnNormalizer
from ..normalizer.binary import BinaryNormalizer
from ..normalizer.multiclass import MulticlassNormalizer, MulticlassNormalizerMethods
from ...dtypes import ColumnName, RawDType, SType
from ...utils import find_special_category, make_enum, register


@register(ColumnTransformer.registry, RawDType.categorical)
class CategoricalTransformer(ColumnTransformer):
    """
    Column transformer to numerical matrix for categorical raw data type,
    including binary and multi-class categorical columns.
    """
    def __init__(self,
                 name: ColumnName = "",
                 *,
                 max_n_category: int = 200,
                 other_category: Any = "<other>",
                 pos_label: Optional = None,
                 fillna_value: Optional = "<nan>",
                 fillna_policy: Union[FillNaPolicy, str] = FillNaPolicy.sample,
                 **kwargs):
        """
        Parameters
        ----------
        max_n_category : int, optional
            Maximum number of categories allowed. Default is 200.
        other_category : optional
            If the number of unique values exceed `max_n_category`, say M, we will replace the rare classes with
            this `other_category`. Top M-1 frequency classes will be retained.
        pos_label : optional
            The positive label value in this categorical column.
            If not provided, this column is treated as multi-class, regardless of the number of classes it has.
        **kwargs
            Other arguments to make a categorical (multi-class if pos_label is not provided, or binary otherwise)
            normalizer.
        Other parameters are inherited from parent `ColumnTransformer`.
        """
        super().__init__(
            name,
            fillna_value=fillna_value,
            fillna_policy=fillna_policy
        )
        self._max_n_category = max_n_category
        self._other_category = other_category
        self._other_categories = set()
        self._other_pool = None
        self.pos_label = pos_label
        self._kwargs = kwargs

    def _fit_cleaned(self, data: pd.Series):
        if self.pos_label is None:
            self._standardized_dtypes[MainValueColumn] = SType.multiclass
            self.normalizers[MainValueColumn] = StdColumnNormalizer.make(
                SType.multiclass,
                name=MainValueColumn, parent=self.name,
                **self._kwargs
            )
            vc = data.value_counts()
            if len(vc) > self._max_n_category:
                logging.warning(f"The number of unique categories detected is {len(vc)}, "
                                f"but we allow maximally {self._max_n_category} categories only. "
                                f"Infrequent categories will be converted to an other type denoted by "
                                f"{self._other_category}, and will be recovered by randomly sampling from all "
                                f"other values, for which reversibility of format is guaranteed but reversibility of "
                                f"exact data value is not.")
            self._other_pool = vc.iloc[self._max_n_category - 1:]
            self._other_categories |= {*self._other_pool.index}
        else:
            self._standardized_dtypes[MainValueColumn] = SType.binary
            self.normalizers[MainValueColumn] = StdColumnNormalizer.make(
                SType.binary,
                name=MainValueColumn, parent=self.name,
                **self._kwargs
            )

    def _standardize(self, data: pd.Series, retain_non_std: bool = False) -> pd.DataFrame:
        return pd.DataFrame({
            MainValueColumn: data.replace({
                v: self._other_category
                for v in self._other_categories
            })
        })

    def _inverse_standardize(self, standardized: pd.DataFrame) -> pd.Series:
        if MainValueColumn in self._standardized_dtypes:
            extracted = standardized.loc[:, MainValueColumn]
            other_types = extracted == self._other_category
            if other_types.sum() > 0:
                extracted.loc[other_types] = pd.Series(self._other_pool.index)\
                    .sample(n=other_types.sum(), weights=self._other_pool.values, replace=True).values
        else:
            extracted = pd.Series(
                [self.fillna_value for _ in range(len(standardized))],
                index=standardized.index,
                name=MainValueColumn
            )
        return extracted

    @property
    def raw_dtype(self) -> RawDType:
        return RawDType.categorical

    @classmethod
    @register(ColumnTransformer.args_learner, RawDType.categorical)
    def learn_args(cls,
                   data: pd.Series,
                   **kwargs) -> Dict[str, Any]:
        """
        We will do the following in sequence:

        1. Count the number of unique values, if the result is smaller than or equal to 2, this column can be binary. 
           We can then assign a positive label.
            1. If one of the unique values is some commonly used positive boolean indicator
               (such as True, 1, Y, Yes, T), they will be the positive label.
            2. Assign the value with smaller frequency to be positive (this is different from the positive label
               inference in the binary `normalize` step because the normalizer allows more than one category, although
               not recommended).
        2. Learn a valid "other" label that does not appear in the seen categories.
            1. If `"<other>"` is not one of the categories, it will be used.
            2. Iterate integers 0, 1, 2, … until `"<other>"` concatenated with this integer does not appear in the seen
               categories, and this will be used.
        3. Learn a valid "nan" label that does not appear in the seen categories, in the same way as "other" but the
           default value is `"<nan>"` instead of `"<other>"`.
        4. Learn the normalizer arguments.
            1. If `"pos_label"` is learned or is provided, the standardized result should be binary.
            2. If the total number of different categories (after grouping others type) is larger than some threshold
               (`label_threshold`), the categorical value will be normalized by label multiclass normalizer.
            3. Otherwise, we will use one-hot multiclass normalizer.
    
        Parameters
        ----------
        label_threshold : float, optional
            The maximum categories for default one-hot encoding.
            This argument is used only if the default category normalizer type is one-hot encoding,
            and the exact normalizer type is not provided.
            If the total number of categories is larger than this threshold, we will use label encoding instead of
            one-hot encoding.
            The default value is 50.
        **kwargs
            Other parameters to the categorical normalizer `make` functions (could be for
            [binary](/tabtransformer/column/normalizer/binary#tabtransformer.column.normalizer.binary.BinaryNormalizer)
            or for
            [multiclass](/tabtransformer/column/normalizer/multiclass#tabtransformer.column.normalizer.multiclass.MulticlassNormalizer)
            depending on the actual data, but only one should be chosen).
        Other parameters are inherited from parent
        [`ColumnTransformer.learn_args`](/tabtransformer/column/transformer#tabtransformer.column.transformer.ColumnTransformer.learn_args).
        """
        return super().learn_args(
            data,
            raw_dtype=RawDType.categorical,
            **kwargs
        )

    def _convert_dtype(self, data: pd.Series) -> pd.Series:
        return data.apply(
            lambda x: str(int(x)) if isinstance(x, numbers.Number) and x % 1 == 0
            else x if pd.isnull(x) else str(x)
        )

    @classmethod
    @register(ColumnTransformer._args_learner, RawDType.categorical)
    def _learn_args(cls,
                    data: pd.Series,
                    *,
                    default_args: Dict[str, Any],
                    provided_args: Dict[str, Any],
                    default_norm_args_by_stype: Dict[SType, Dict[str, Any]],
                    label_threshold: float = 50,
                    **kwargs) -> Dict[str, Any]:
        args = deepcopy(default_args)
        if "pos_label" not in provided_args:
            cls._check_binary(data, args)

        cls._learn_special_values(data, args, provided_args)

        if provided_args.get("pos_label", args.get("pos_label")) is not None:
            old = deepcopy(default_norm_args_by_stype[SType.binary])
            old.update(args)
            args = old
        else:
            args = cls._update_learned_arg_for_mc(data, args, default_norm_args_by_stype[SType.multiclass],
                                                  label_threshold, provided_args)

        return args

    @classmethod
    def _learn_special_values(cls, data: pd.Series, args: Dict[str, Any], provided_args: Dict[str, Any]):
        if "other_category" in provided_args and "fillna_value" in provided_args:
            return args
        data = cls._get_unique_values(data)
        if "other_category" not in provided_args:
            args["other_category"] = find_special_category("<other>", data)
        if "fillna_value" not in provided_args:
            data.add(provided_args.get("other_category", args["other_category"]))
            args["fillna_value"] = find_special_category("<nan>", data)

    @classmethod
    def _get_unique_values(cls, data: pd.Series) -> set:
        return {*data.dropna().unique()}

    @classmethod
    def _update_learned_arg_for_mc(cls,
                                   data: pd.Series,
                                   args: Dict[str, Any],
                                   default_for_mc: Dict[str, Any],
                                   label_threshold: float,
                                   provided_args: Dict[str, Any]) -> Dict[str, Any]:
        method_type = provided_args.get(
            "method_type", args.get(
                "method_type", default_for_mc.get(
                    "method_type", MulticlassNormalizerMethods.one_hot)))
        method_type = make_enum(method_type, MulticlassNormalizerMethods)
        old = deepcopy(default_for_mc)
        if method_type == MulticlassNormalizerMethods.one_hot:
            nunique = data.nunique()
            max_n_cat = provided_args.get(
                "max_n_category",
                args.get("max_n_category", 200)
            )
            nunique = min(nunique, max_n_cat)
            if nunique > label_threshold:
                method_type = MulticlassNormalizerMethods.label
                args["num_normalization_method"] = "min_max"
                args["max_val"] = nunique
                for a in ["categories", "drop", "dtype", "handle_unknown", "min_frequency", "max_categories"]:
                    if a in old:
                        del old[a]
        args["method_type"] = method_type
        old.update(args)
        args = old
        args["pos_label"] = None
        return args

    @classmethod
    def _check_binary(cls, data: pd.Series, args: Dict[str, Any]):
        nunique = data.nunique()
        if nunique <= 2:
            pool = data.unique()
            for v in [True, 1, 1., "Y", "Yes", "T"]:
                s = str(v)
                for x in [v, s, s.lower(), s.upper()]:
                    if x in pool:
                        args["pos_label"] = x
                        break
                if "pos_label" in args:
                    break
            if "pos_label" not in args or args["pos_label"] is None:
                vc = data.value_counts(ascending=True)
                if len(vc) > 0:
                    args["pos_label"] = vc.index[0]
                else:
                    args["pos_label"] = None

    @classmethod
    def validate_kwargs(cls, args: Dict[str, Any]):
        schema = {
            "type": "object",
            "properties": {
                "max_n_category": {
                    "type": "integer",
                    "minimum": 1
                },
                "other_category": {},
                "pos_label": {},
                "fillna_value": {},
                "fillna_policy": {
                    "type": "string",
                    "enum": ["mean", "min", "special", "sample"]
                },
                "raw_dtype": {
                    "enum": ["categorical"]
                }
            }
        }
        jsonschema.validate(instance=args, schema=schema)
        if args.get("fillna_value") is None:
            fillna_policy = args.get("fillna_policy")
            if fillna_policy is not None and fillna_policy.startswith("m"):
                raise ValueError("Without a fillna value, the fillna policy for categorical cannot be the "
                                 f"continuous-specific policies mean or min. But get {fillna_policy}.")

        is_binary = args.get("pos_label") is not None

        args = deepcopy(args)
        for c in schema["properties"]:
            if c in args and c != "pos_label":
                del args[c]

        if is_binary:
            BinaryNormalizer.validate_kwargs(args)
        else:
            if "pos_label" in args:
                del args["pos_label"]
            MulticlassNormalizer.validate_kwargs(args)
