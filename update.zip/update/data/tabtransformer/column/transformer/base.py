"""Common structure for transformers for different raw data types."""

import enum
import json
import logging
from abc import ABC, abstractmethod
from copy import deepcopy
from typing import Any, Callable, Collection, Dict, List, Optional, Tuple, Type, Union

import numpy as np
import pandas as pd

from ..normalizer import StdColumnNormalizer
from ...dtypes import ColumnName, RawDType, SType, learn_raw_dtype_for_transformer
from ...utils import find_special_category, log, log_time, make_dict, make_enum, make_json_compatible

MainValueColumn = "val"
"""The column name corresponding to the main value after standardization."""
IsNaColumn = "isna"
"""The isna indicator column name."""


class FillNaPolicy(enum.Enum):
    """Policies to fill N/A values after extracting the isna indicator."""

    mean = enum.auto()
    """Use the mean value in the column. This applies to continuous columns only."""
    min = enum.auto()
    """Use the minimum value in the column. This applies to continuous columns only."""
    special = enum.auto()
    """Use a special value to replace N/A values. This applies to categorical columns only."""
    sample = enum.auto()
    """Use samples from the given data."""

    def fillna_pool(self, data: pd.Series) -> pd.Series:
        """
        Calculate the value source pool to sample values to fill N/A values under this policy.

        Parameters
        ----------
        data : pd.Series
            The data to sample from.

        Returns
        -------
        pd.Series
            The value source pool to fill N/A values.
        """
        if self == FillNaPolicy.mean:
            return pd.Series([data.mean()])
        elif self == FillNaPolicy.special:
            special_value = find_special_category("<nan>", data)
            return pd.Series([special_value])
        elif self == FillNaPolicy.sample:
            return data.dropna()
        raise NotImplementedError(f"Fill N/A policy {self.name} is not recognized.")


class ColumnTransformer(ABC):
    """
    Column transformer to numerical matrix for any raw data type.
    """

    registry: Dict[RawDType, Type["ColumnTransformer"]] = {}
    """Registry of transformer for different raw data types."""
    args_learner: Dict[RawDType, Callable] = {}
    """Argument learners of different raw data types."""
    _args_learner: Dict[RawDType, Callable] = {}

    _default_na_equiv = ["-", "", "N/A", "nan", "na", "Nil", "Nil."]

    def __init__(self,
                 name: ColumnName = "",
                 *,
                 fillna_value: Optional = None,
                 fillna_policy: Union[FillNaPolicy, str] = FillNaPolicy.sample,
                 na_equivalences: Optional[Collection] = None):
        """
        Initialize a new instance of `ColumnTransformer`, for a new column.

        Parameters
        ----------
        name : ColumnName, optional
            Name of the column.
        fillna_value : Any, optional
            Value to fill NA values. Details will be given in `clean` method.
        fillna_policy : FillNaPolicy, optional
            Policy to fill NA value after extracting isna indicator.
        na_equivalences : Collection, optional
            Values treated as N/A because sometimes such values are not represented as nan in the data,
            typically due to data formatting and IO.
            If not provided, the set of N/A equivalence values are (strings after stripping):
            "-", "", "N/A", "nan", "na", "Nil", "Nil."
        """
        self.name = name
        self.fillna_value = fillna_value
        self.fillna_policy: FillNaPolicy = make_enum(fillna_policy, FillNaPolicy)
        self.na_equiv = self._default_na_equiv if na_equivalences is None else na_equivalences

        self._standardized_dtypes: Dict[str, SType] = {}
        self._standardized_columns: List[str] = []
        self.normalizers: Dict[str, StdColumnNormalizer] = {}
        self._normalized_dim = 0

        self._fillna_value_pool: Optional[pd.Series] = None

        self._fitted = False

    @property
    @abstractmethod
    def raw_dtype(self) -> RawDType:
        """Raw data type."""
        raise NotImplementedError()


    @property
    def standardized_columns(self) -> List[str]:
        """Standardized column names."""
        self._check_fitted("getting standardized columns")
        return self._standardized_columns

    @property
    def standardized_dtypes(self) -> Dict[str, SType]:
        """Standardized column names with the corresponding `SType`."""
        self._check_fitted("getting standardized columns")
        return self._standardized_dtypes

    def _validate_dtype(self, data: pd.Series) -> pd.Series:
        data = data.replace({
            v: np.nan for v in self.na_equiv
        })
        if self.raw_dtype.is_valid_dtype(str(data.dtype)):
            return data
        return self._convert_dtype(data)

    def _convert_dtype(self, data: pd.Series) -> pd.Series:
        return data.astype(self.raw_dtype.default_dtype)

    @log_time("Fitting column", "Finished fitting column",
              start_level=log.TRACE_LEVEL, end_level=logging.DEBUG, with_name=True)
    def fit(self, data: pd.Series):
        """
        Fit this column transformer to the given data.

        Parameters
        ----------
        data : pd.Series
            The original data to fit on.
        """
        data = self._validate_dtype(data)
        isna = data.isna()
        self._fitted = True
        if (~isna).sum() == 0:
            return

        self._fit_clean(data, isna)

        cleaned = self.clean(data)
        self._fit_cleaned(cleaned.loc[:, MainValueColumn])
        self._standardized_columns = [*self._standardized_dtypes]

        standardized = self.standardize(cleaned)
        for c in standardized.columns:
            self.normalizers[c].fit(standardized.loc[:, c])
            self._normalized_dim += self.normalizers[c].normalized_dim

    @property
    def normalized_dim(self) -> int:
        """Number of dimensions after normalization."""
        self._check_fitted("getting fitted dimension")
        return self._normalized_dim


    @property
    def normalized_span_info(self) -> List[Tuple[int, SType]]:
        """
        Normalized columns span information (list of width (int) and standardized column type).
        Non-standard columns are excluded.
        The order follows the output data columns of calling `normalize`.
        Non-target and target columns are separated in this order.
        This result will be helpful in activation function construction for some training tasks.
        """
        out = []
        for c, normalizer in self.normalizers.items():
            out.extend(normalizer.normalized_span_info)
        return out

    @abstractmethod
    def _fit_cleaned(self, data: pd.Series):
        raise NotImplementedError()

    def _fit_clean(self, data: pd.Series, isna: pd.Series):
        if self.fillna_value is None:
            if isna.sum() > 0:
                self._fillna_value_pool = self.fillna_policy.fillna_pool(data)
                self._standardized_dtypes[IsNaColumn] = SType.binary
                self.normalizers[IsNaColumn] = StdColumnNormalizer.make(
                    SType.binary, "single", name=IsNaColumn, parent=self.name
                )
        else:
            if self.fillna_value == "mean" and self.raw_dtype.continuous:
                self.fillna_value = data.mean()

    def _check_fitted(self, act: str):
        if not self._fitted:
            raise RuntimeError(f"This standardizer is not yet fitted. Please fit before {act}.")

    @log_time("Cleaning so as to remove N/A values in", "Cleaned column",
              start_level=log.TRACE_LEVEL, end_level=logging.DEBUG, with_name=True)
    def clean(self, data: pd.Series) -> pd.DataFrame:
        """
        Remove N/A values in the column.
        If `fillna_value` is provided, the N/A values will directly be replaced by the value.
        If the string "mean" is given for continuous raw types (numerical, datetime, or timedelta), the mean value
        will be used to replace N/A values.
        If the `fillna_value` is not provided, there will be an additional isna indicator in the output.
        Then, the N/A values will be filled according to the `fillna_policy`.

        Parameters
        ----------
        data : pd.Series
            The original column data.

        Returns
        -------
        pd.DataFrame
            DataFrame after handling with N/A values.
        """
        self._check_fitted("handling NaN")
        data = self._validate_dtype(data)
        out = {}
        if IsNaColumn in self._standardized_dtypes:
            out[IsNaColumn] = data.isna()
        if self.fillna_value is not None:
            out[MainValueColumn] = data.fillna(self.fillna_value)
        elif self._fillna_value_pool is not None:
            isna = data.isna()
            data.loc[isna] = self._fillna_value_pool.sample(n=isna.sum(), replace=True).values
            out[MainValueColumn] = data
        elif data.isna().sum() == 0:
            out[MainValueColumn] = data
        return pd.DataFrame(out, index=data.index)

    @log_time("Inversely cleaning so as to recover N/A values in column", "Recovered N/A values in column",
              start_level=log.TRACE_LEVEL, end_level=logging.DEBUG, with_name=True)
    def inverse_clean(self, data: pd.DataFrame) -> pd.Series:
        """
        Recover N/A values from the data.

        Parameters
        ----------
        data : pd.DataFrame
            The data after handling N/A values.

        Returns
        -------
        pd.Series
            Series after N/A values are recovered.
        """
        self._check_fitted("inversely handling NaN")
        if len(data.columns) == 0:
            return self._validate_dtype(pd.Series(index=data.index))
        if IsNaColumn not in data.columns:
            data = data.loc[:, MainValueColumn].replace({self.fillna_value: np.nan})
        else:
            data = data.apply(
                lambda row: np.nan if row[IsNaColumn] else row[MainValueColumn], axis=1
            )
        return self._validate_dtype(data)

    @log_time("Standardizing to categorical-or-numerical for column", "Finished standardizing column",
              start_level=log.TRACE_LEVEL, end_level=logging.DEBUG, with_name=True)
    def standardize(self, data: pd.DataFrame, retain_non_std: bool = False) -> pd.DataFrame:
        """
        Standardize a column after N/A value is handled.

        Parameters
        ----------
        data : pd.DataFrame
            The result of `clean`.
        retain_non_std : bool, optional
            Whether to retain non-standard values in standardized result.

        Returns
        -------
        pd.DataFrame
            DataFrame after standardization.
        """
        self._check_fitted("standardization")
        if len(data.columns) == 0:
            return data
        if IsNaColumn in self._standardized_dtypes:
            isna = data[[IsNaColumn]]
        else:
            isna = data[[]]
        data = self._validate_dtype(data.loc[:, MainValueColumn])
        standardized = self._standardize(data, retain_non_std)
        columns = [
            c for c in self._standardized_columns
            if c in standardized.columns
            and (self._standardized_dtypes[c] != RawDType.non_std or retain_non_std)
        ]
        standardized = standardized[columns].astype({
            c: t.pd_dtype for c, t
            in self._standardized_dtypes.items()
            if c in columns
        })
        return pd.concat([isna, standardized], axis=1)

    def _standardize(self, data: pd.Series, retain_non_std: bool = False) -> pd.DataFrame:
        return pd.DataFrame({
            MainValueColumn: data
        })

    @log_time("Inversely standardizing to recover raw data values in column", "Recovered raw values in column",
              start_level=log.TRACE_LEVEL, end_level=logging.DEBUG, with_name=True)
    def inverse_standardize(self, standardized: pd.DataFrame, assign_non_std: bool = True) -> pd.DataFrame:
        """
        Recover N/A-free values and isna indicator (if available) from the standardized data.

        Parameters
        ----------
        standardized : pd.DataFrame
            The data after standardization.
        assign_non_std : bool, optional
            If the input data does not contain values for non-standard columns, whether to give a dummy
            value from sequential integers (1, 2, ...) (and whether this data is N/A can possibly be recovered).

        Returns
        -------
        pd.Series
            Result of `clean` after inverse standardization.
        """
        self._check_fitted("inverse standardization")
        cleaned = self._inverse_standardize(standardized)
        if IsNaColumn in self._standardized_dtypes:
            return pd.DataFrame({
                IsNaColumn: standardized.loc[:, IsNaColumn],
                MainValueColumn: cleaned
            })
        else:
            return pd.DataFrame({
                MainValueColumn: cleaned
            })

    def _inverse_standardize(self, standardized: pd.DataFrame) -> pd.Series:
        return standardized.loc[:, MainValueColumn]

    @log_time("Normalizing standardized values to numerical in column", "Finished normalizing column",
              start_level=log.TRACE_LEVEL, end_level=logging.DEBUG, with_name=True)
    def normalize(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        Normalized a standardized categorical-or-numerical DataFrame to numerical-only matrix
        (unless this is non-standard column).

        Parameters
        ----------
        data : pd.DataFrame
            The standardized data.

        Returns
        -------
        pd.DataFrame
            DataFrame after normalization. It will contain 2 levels of columns.
            Level 1 for the standardized column, and level 2 for the normalized column.
        """
        result = {}
        data_columns = {*data.columns}
        for c in self._standardized_columns:
            if c in data_columns or self._standardized_dtypes[c] == RawDType.non_std:
                result[c] = self.normalizers[c].normalize(data.loc[:, c])
        return pd.concat(result, axis=1)

    @log_time("Inversely normalizing numerical data to standardized format in column", "Inversely normalized column",
              start_level=log.TRACE_LEVEL, end_level=logging.DEBUG, with_name=True)
    def inverse_normalize(self, normalized: pd.DataFrame) -> pd.DataFrame:
        """
        Recover normalized values to standardized values.

        Parameters
        ----------
        normalized : pd.DataFrame
            The data after normalization. This normalized DataFrame should have column values in 2 levels.

        Returns
        -------
        pd.DataFrame
            Standard values recovered.
        """
        result = {}
        all_columns = {a for a, b in normalized.columns}
        for c in self._standardized_columns:
            if c not in all_columns and self.standardized_dtypes[c] == SType.non_std:
                continue
            result[c] = self.normalizers[c].inverse_normalize(normalized[c])
        return pd.DataFrame(result)

    @log_time("Transforming to pure numerical data on column", "Finished transforming column", with_name=True)
    def transform(self, data: pd.Series) -> pd.DataFrame:
        """
        Transform a column of any raw type that may or may not contain N/A values to a numerical-only matrix
        (unless this is non-standard column).

        Parameters
        ----------
        data : pd.Series
            The raw data.

        Returns
        -------
        pd.DataFrame
            The transformed matrix.
        """
        clean = self.clean(data)
        standardized = self.standardize(clean)
        return self.normalize(standardized)

    @log_time("Inversely transforming from pure numerical data on column",
              "Finished inversely transforming column", with_name=True)
    def inverse_transform(self, normalized: pd.DataFrame) -> pd.Series:
        """
        Recover normalized numerical values to raw column data.

        Parameters
        ----------
        normalized : pd.DataFrame
            The data after normalization. This normalized DataFrame should have column values in 2 levels.

        Returns
        -------
        pd.Series
            Raw values recovered.
        """
        standardized = self.inverse_normalize(normalized)
        clean = self.inverse_standardize(standardized)
        return self.inverse_clean(clean)

    def __repr__(self) -> str:
        return f"{self.__name__}({self.name})"

    @classmethod
    def make(cls,
             raw_dtype: Union[RawDType, str],
             name: ColumnName = "",
             **kwargs) -> "ColumnTransformer":
        """
        Construct a `ColumnTransformer` instance based on the given type and arguments.

        Parameters
        ----------
        raw_dtype : str or RawDType
            The raw column type.
        name : ColumnName
            Name of the column.
        **kwargs
            Parameters to the transformer of the given method type in the given `raw_type`.
            One can direct to the documentation for each of the types:
            [categorical](/tabtransformer/column/transformer/categorical#tabtransformer.column.transformer.categorical.CategoricalTransformer),
            [numerical](/tabtransformer/column/transformer/numerical#tabtransformer.column.transformer.numerical.NumericalTransformer),
            [datetime](/tabtransformer/column/transformer/datetime#tabtransformer.column.transformer.datetime.DatetimeTransformer),
            [timedelta](/tabtransformer/column/transformer/timedelta#tabtransformer.column.transformer.timedelta.TimedeltaTransformer),
            [mixed](/tabtransformer/column/transformer/mixed#tabtransformer.column.transformer.mixed.MixedTransformer),
            [encoding](/tabtransformer/column/transformer/encoding#tabtransformer.column.transformer.encoding.EncodingTransformer),
            [non_std](/tabtransformer/column/transformer/non_std#tabtransformer.column.transformer.non_std.NonStdTransformer)
        """
        raw_dtype: RawDType = make_enum(raw_dtype, RawDType)
        if raw_dtype == RawDType.encoding:
            return cls.registry[raw_dtype].make(raw_dtype, name, **kwargs)
        return cls.registry[raw_dtype](name, **kwargs)

    @classmethod
    @log_time("Learning column kwargs for", "Finished learning column kwargs for",
              start_level=log.TRACE_LEVEL, end_level=logging.DEBUG, with_name=True)
    def learn_args(cls,
                   data: pd.Series,
                   *,
                   unique_threshold: float = .95,
                   force_min_category: int = 3,
                   try_casting: bool = True,
                   max_mixed_category: int = 5,
                   raw_dtype: Optional[Union[RawDType, str]] = None,
                   default_args: Optional[Dict[RawDType, Dict[str, Any]]] = None,
                   provided_args: Optional[Dict[str, Any]] = None,
                   default_norm_args_by_stype: Optional[Dict[Union[SType, str], Dict[str, Any]]] = None,
                   **kwargs) -> Dict[str, Any]:
        """
        Learn the arguments for transformer from a given column.
        To learn the arguments specific to each raw data type, N/A values will be removed before input to the learner.
        The learned result will be the default overriden by learned overriden by provided.
        The detailed argument learning for each raw data type specifically may refer to the child classes' method.

        Parameters
        ----------
        data : pd.Series
            The column data.
        raw_dtype : RawDType, optional
            The known raw dtype. If not provided, we will learn.
            To learn the raw data type, we will do the following in sequence:

            1. If this column is N/A in all rows, it is categorical. If not, remove N/A values and continue.
            2. If the total number of different values in the data is smaller than some value (`force_min_category`),
               it is categorical. For example, `1, 1, 1, 2, 2, 2`, although being numerical in data type, we will
               `standardize` it as categorical.
            3. If all data can be safely cast to some types, it is of this type. We will check the types in the order:
               a. numerical, by applying Python built-in `float` type casting,
               b. datetime, by applying `pandas.to_datetime` without error,
               c. timedelta, by applying `pandas.to_timedelta` without error.
            4. If the total number of unique values exceed some proportion (`unique_threshold`) in all data, it is
               non-standard.
            5. Try to cast to some types again, in the same order as step 3, but count the number of failures
               (in terms of unique values). If the number of failures does not exceed some threshold
               (`max_mixed_category`), we can understand this column as mixed type with the base type mixed with
               categorical type being the data type to where other values successfully cast.
            6. Anything else is treated as categorical.
        unique_threshold : float, optional
            From this argument on, we learn the data types for the columns not mentioned above.
            After removing N/A values in the column, if the number of unique non-continuous values divided by the
            number of rows hit this threshold, this column will be treated as non-standard. Default is 0.95.
        force_min_category : int, optional
            If the number of unique non-N/A values does not exceed this number, we will treat this column as categorical
            regardless of the data type. Default is 3.
        try_casting : bool, optional
            Sometimes the data provided is in `object` data type, but all content can be converted to some other data
            type (e.g. numerical, datetime), so learning from dtype of input DataFrame might be insufficient.
            By setting this argument on, we will try to do casting for all values.
            If succeeded for all items in the column except for N/As, we will use this succeeded data type.
            It also allows detection of mixed types.
            Default is True.
        max_mixed_category : int, optional
            If some value casting is successful but some are not, this column may be of mixed type.
            This value specifies how many failures (in terms of unique value) are allowed for this column to be a mixed
            type. Default is 5.
        default_args : dict, optional
            Default arguments per raw data type.
        provided_args : dict, optional
            Arguments already provided for this column.
        default_norm_args_by_stype : dict, optional
            The default normalizer arguments for each standardized type.
        **kwargs
            Other arguments for learning.

        Returns
        -------
        dict
            The complete argument as a dict. Details will be given per sub-type.
        """
        args = {}
        provided_args = make_dict(provided_args)
        raw_dtype = raw_dtype if raw_dtype is not None else provided_args.get("raw_dtype")
        if raw_dtype is not None:
            raw_dtype = make_enum(raw_dtype, RawDType)
        raw_dtype = learn_raw_dtype_for_transformer(data, raw_dtype, unique_threshold, force_min_category, try_casting,
                                                    max_mixed_category, args, provided_args)
        logging.debug(f"Inferred raw data type is {raw_dtype.name}.")

        default_args = make_dict(default_args)
        default_dtype_args = deepcopy(default_args.get(raw_dtype, {}))
        default_dtype_args.update(args)
        args = default_dtype_args

        default_norm_args_by_stype = make_dict(default_norm_args_by_stype)
        default_norm_args_by_stype = {
            k: default_norm_args_by_stype.get(k, default_norm_args_by_stype.get(k.name, {}))
            for k in [SType.binary, SType.multiclass, SType.numerical]
        }
        args = cls._args_learner[raw_dtype](
            cls=cls.registry[raw_dtype],
            data=data,
            default_args=args,
            provided_args=provided_args,
            default_norm_args_by_stype=default_norm_args_by_stype,
            default_dtype_args=default_args,
            **kwargs
        )
        args.update(provided_args)
        args["raw_dtype"] = raw_dtype
        logging.log(log.TRACE_LEVEL, f"The learned argument is {json.dumps(make_json_compatible(args), indent=2)}.")
        return args

    @classmethod
    @abstractmethod
    @log_time("Learning the arguments for column w.r.t. to the raw type", "Finished learning arguments for column",
              start_level=log.TRACE_LEVEL, end_level=logging.DEBUG, with_name=True)
    def _learn_args(cls,
                    data: pd.Series,
                    *,
                    default_args: Dict[str, Any],
                    provided_args: Dict[str, Any],
                    default_norm_args_by_stype: Dict[SType, Dict[str, Any]],
                    **kwargs) -> Dict[str, Any]:
        raise NotImplementedError()

    @classmethod
    @abstractmethod
    def validate_kwargs(cls, args: Dict[str, Any]):
        """
        Check whether the arguments are valid to the constructor.

        Parameters
        ----------
        args : dict
            The arguments to the constructor.

        Raises
        ------
        ValueError | jsonschema.ValidationError
            If the arguments are invalid.
        """
        raise NotImplementedError()

    @log_time("Discretizing column", "Finished discretizing column",
              start_level=log.TRACE_LEVEL, end_level=logging.DEBUG, with_name=True)
    def discretize(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        Discretize the given data.

        Parameters
        ----------
        data : pd.Series
            The data to discretize, which should be standardized ideally.

        Returns
        -------
        pd.DataFrame
            The discretized data.
        """
        discretized = {}
        for c in data.columns:
            discretized[c] = self.normalizers[c].discretize(data.loc[:, c])
        return pd.DataFrame(discretized)

    @log_time("Inversely discretizing column", "Finished recovering discretized column",
              start_level=log.TRACE_LEVEL, end_level=logging.DEBUG, with_name=True)
    def inverse_discretize(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        Inverse the discretization step. If the original data is continuous, recovered continuous data is very unlikely
        to be identical to the original.

        Parameters
        ----------
        data : pd.DataFrame
            The discretized data.

        Returns
        -------
        pd.DataFrame
            The recovered data from discretized result.
        """
        recovered = {}
        for c in data.columns:
            recovered[c] = self.normalizers[c].inverse_discretize(data.loc[:, c])
        return pd.DataFrame(recovered)

        def inverse_normalized_na(self, normalized: pd.DataFrame) -> pd.DataFrame:
            """
            Recover N/A values but maintain the data as numerical-only.
            If the `fillna_value` is not None and it appears in the original data, there will be data loss after this step,
            because all data with this value will be replaced with N/A.

            Parameters
            ----------
            normalized : pd.DataFrame
                The data after normalization.

            Returns
            -------
            pd.DataFrame
                Result of N/A values are recovered.
            """
        normalized = normalized.copy()
        standardized = self.inverse_normalize(normalized)
        isna = None
        if self.fillna_value is not None:
            if MainValueColumn in standardized.columns:
                isna = normalized.loc[:, MainValueColumn] == self.fillna_value
        else:
            if IsNaColumn in normalized.columns:
                isna = standardized[IsNaColumn]
        if isna is not None:
            normalized.loc[isna, :] = np.nan
        return normalized

    def inverse_normalized_na(self, normalized: pd.DataFrame) -> pd.DataFrame:
        """
        Recover N/A values but maintain the data as numerical-only.
        If the `fillna_value` is not None and it appears in the original data, there will be data loss after this step,
        because all data with this value will be replaced with N/A.

        Parameters
        ----------
        normalized : pd.DataFrame
            The data after normalization.

        Returns
        -------
        pd.DataFrame
            Result of N/A values are recovered.
        """
        normalized = normalized.copy()
        standardized = self.inverse_normalize(normalized)
        isna = None
        if self.fillna_value is not None:
            if MainValueColumn in standardized.columns:
                isna = normalized.loc[:, MainValueColumn] == self.fillna_value
        else:
            if IsNaColumn in normalized.columns:
                isna = standardized[IsNaColumn]
        if isna is not None:
            normalized.loc[isna, :] = np.nan
        return normalized

