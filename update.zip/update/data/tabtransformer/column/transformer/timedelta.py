"""Transformer for handling timedelta data."""

from copy import deepcopy
from datetime import datetime, timedelta
from typing import Any, Dict, Optional, Union

import jsonschema
import pandas as pd

from .base import ColumnTransformer, FillNaPolicy, MainValueColumn
from ..normalizer import StdColumnNormalizer
from ..normalizer.numerical import NumericalNormalizer
from ...dtypes import ColumnName, RawDType, SType
from ...utils import register


@register(ColumnTransformer.registry, RawDType.timedelta)
class TimedeltaTransformer(ColumnTransformer):
    """
    Column transformer to numerical matrix for time-delta raw data type.
    """

    def __init__(self,
                 name: ColumnName = "",
                 *,
                 fillna_value: Optional[Union[timedelta, str]] = None,
                 fillna_policy: Union[FillNaPolicy, str] = FillNaPolicy.sample,
                 **kwargs):
        """
        Parameters
        ----------
        **kwargs
            Other arguments to make a
            [numerical normalizer](/tabtransformer/column/normalizer/numerical#tabtransformer.column.normalizer.numerical.NumericalTransformer.make).
        Other parameters are inherited from parent `ColumnTransformer`.
        """
        self._base_date = datetime.now().date()
        if isinstance(fillna_value, str):
            fillna_value = pd.to_timedelta(fillna_value)
        super().__init__(
            name,
            fillna_value=fillna_value, fillna_policy=fillna_policy
        )
        self._kwargs = kwargs

    def _convert_dtype(self, data: pd.Series) -> pd.Series:
        return pd.to_timedelta(data, errors="coerce")

    def _standardize(self, data: pd.Series, retain_non_std: bool = False) -> pd.DataFrame:
        return pd.DataFrame({MainValueColumn: data.apply(lambda x: x.total_seconds())})

    def _inverse_standardize(self, standardized: pd.DataFrame) -> pd.Series:
        return standardized.loc[:, MainValueColumn].apply(lambda x: timedelta(seconds=x))

    def _fit_cleaned(self, data: pd.Series):
        self._standardized_dtypes[MainValueColumn] = SType.numerical
        if isinstance(self._kwargs.get("min_val"), timedelta):
            self._kwargs["min_val"] = self._kwargs["min_val"].total_seconds()
        if isinstance(self._kwargs.get("max_val"), timedelta):
            self._kwargs["max_val"] = self._kwargs["max_val"].total_seconds()
        self.normalizers[MainValueColumn] = StdColumnNormalizer.make(
            SType.numerical,
            name=MainValueColumn, parent=self.name,
            **self._kwargs
        )

    @property
    def raw_dtype(self) -> RawDType:
        return RawDType.timedelta

    @classmethod
    @register(ColumnTransformer.args_learner, RawDType.timedelta)
    def learn_args(cls,
                   data: pd.Series,
                   **kwargs) -> Dict[str, Any]:
        """
        The only thing need to be learned is the minimum and maximum value if enforcement is required.

        Parameters
        ----------
        enforce_min : bool, optional
            Whether to enforce the minimum value as the value range.
            If not provided, we will not restrict the range.
        enforce_max : bool, optional
            Whether to enforce the maximum value as the value range.
            If not provided, we will not restrict the range.
        Other parameters are inherited from parent
        [`ColumnTransformer.learn_args`](/tabtransformer/column/transformer#tabtransformer.column.transformer.ColumnTransformer.learn_args).
        permitted in this method.
        """
        return super().learn_args(
            data,
            raw_dtype=RawDType.timedelta,
            **kwargs
        )

    @classmethod
    @register(ColumnTransformer._args_learner, RawDType.timedelta)
    def _learn_args(cls,
                    data: pd.Series,
                    *,
                    default_args: Dict[str, Any],
                    provided_args: Dict[str, Any],
                    default_norm_args_by_stype: Dict[SType, Dict[str, Any]],
                    enforce_min: bool = False,
                    enforce_max: bool = False,
                    **kwargs) -> Dict[str, Any]:
        args = cls._args_learner[RawDType.numerical](
            cls=cls.registry[RawDType.numerical],
            data=data.apply(lambda x: x.total_seconds()),
            default_args=default_args,
            provided_args=provided_args,
            default_norm_args_by_stype=default_norm_args_by_stype
        )
        args.update(default_args)
        data = pd.to_timedelta(data, errors="coerce").dropna()
        if len(data) <= 0:
            return args

        enforce_min = provided_args.get("enforce_min", args.get("enforce_min", enforce_min))
        enforce_max = provided_args.get("enforce_max", args.get("enforce_max", enforce_max))
        if enforce_min and "min_val" not in provided_args:
            args["min_val"] = data.min()
        if enforce_max and "max_val" not in provided_args:
            args["max_val"] = data.min()
        for key, src in zip(
                ["min_val", "min_val", "max_val", "max_val"],
                [args, provided_args, args, provided_args]
        ):
            if isinstance(src.get(key), str):
                if "inf" in src[key]:
                    src[key] = float(src[key])
                else:
                    src[key] = pd.to_timedelta(src[key])

        return args

    @classmethod
    def validate_kwargs(cls, args: Dict[str, Any]):
        schema = {
            "type": "object",
            "properties": {
                "fillna_value": {
                    "type": ["number", "string", "null"]
                },
                "fillna_policy": {
                    "type": "string",
                    "enum": ["mean", "min", "special", "sample"]
                },
                "enforce_min": {
                    "type": "boolean"
                },
                "enforce_max": {
                    "type": "boolean"
                },
                "raw_dtype": {
                    "enum": ["timedelta"]
                }
            }
        }
        jsonschema.validate(instance=args, schema=schema)
        fillna_value = args.get("fillna_value")
        if fillna_value is not None and isinstance(fillna_value, str):
            pd.to_timedelta(fillna_value)

        args = deepcopy(args)
        for c in ["fillna_value", "fillna_policy", "raw_dtype"]:
            if c in args:
                del args[c]

        NumericalNormalizer.validate_kwargs(args)
