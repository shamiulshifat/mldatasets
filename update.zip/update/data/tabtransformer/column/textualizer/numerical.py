"""Textualizer for handling numerical data."""

from typing import Any, Dict, Tuple, Union

import pandas as pd

from .base import ColumnTextualizer
from ...dtypes import ColumnName, RawDType
from ...tokenizer import TabularDataTokenizer
from ...utils import register


@register(ColumnTextualizer.registry, RawDType.numerical)
class NumericalTextualizer(ColumnTextualizer):
    """
    Column textualizer for numerical raw data type.
    """
    def __init__(self,
                 tokenizer: TabularDataTokenizer,
                 name: ColumnName = "",
                 index: int = 0,
                 *,
                 is_small_integers: bool = False,
                 **kwargs):
        """
        Parameters
        ----------
        is_small_integers : bool
            Whether this numerical data is small integers.
        Other parameters are inherited from parent `ColumnTextualizer`.
        """
        super().__init__(tokenizer, name, index, **kwargs)
        self._is_small_integers = is_small_integers
        self._sign = None

    def _textualize_notna_cell(self, x: Union[int, float]) -> str:
        if self._is_small_integers:
            return self.tokenizer.denote_small_integer(x, include_sign=self._sign is None)
        return self.tokenizer.factorize_scientific_notation(x, include_sign=self._sign is None)

    def _inverse_raw(self, x: str) -> float:
        return pd.to_numeric(x, errors="coerce")

    def _fit(self, data: pd.Series):
        data = data.dropna()
        if (data >= 0).sum() == len(data):
            self._sign = 1
        if (data <= 0).sum() == len(data):
            self._sign = -1

    def _inverse_tokens(self, x: str) -> Tuple[float, bool]:
        if self._is_small_integers:
            unsigned, valid = self.tokenizer.revert_small_integer(x, including_sign=self._sign is None)
        else:
            unsigned, valid = self.tokenizer.defactorize_scientific_notation(x, including_sign=self._sign is None)
        if self._sign is not None:
            return unsigned * self._sign, valid
        return unsigned, valid

    @property
    def raw_dtype(self) -> RawDType:
        return RawDType.numerical

    @classmethod
    def _dtype_specific_update(cls, data: pd.Series, tokenizer: TabularDataTokenizer, default_args: Dict[str, Any]):
        pool = {*range(tokenizer.max_small_integer + 1)}
        data = data.dropna()
        if data.abs().isin(pool).sum() == len(data):
            default_args["is_small_integers"] = True
        if default_args.get("is_small_integer"):
            default_args["use_raw_data"] = False

    @classmethod
    def _learn_default_args(cls,
                            tokenizer: TabularDataTokenizer,
                            default_args: Dict[str, Any]) -> Dict[str, Any]:
        if default_args.get("use_raw_data") is None:
            if default_args.get("is_small_integer") and tokenizer.max_small_integer >= 0:
                default_args["use_raw_data"] = False
            else:
                default_args["use_raw_data"] = not tokenizer.has_exponent
        return default_args
