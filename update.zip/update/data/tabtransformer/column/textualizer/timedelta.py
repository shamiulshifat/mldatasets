"""Textualizer for handling timedelta data."""

from datetime import timedelta
from typing import Any, Dict, Tuple

import numpy as np
import pandas as pd

from .base import ColumnTextualizer
from ...dtypes import ColumnName, RawDType
from ...tokenizer import TabularDataTokenizer
from ...utils import register


@register(ColumnTextualizer.registry, RawDType.timedelta)
class TimedeltaTextualizer(ColumnTextualizer):
    """
    Column textualizer for timedelta raw data type.
    """
    def __init__(self,
                 tokenizer: TabularDataTokenizer,
                 name: ColumnName = "",
                 index: int = 0,
                 *,
                 wkno_as_small_integers: bool = False,
                 **kwargs):
        """
        Parameters
        ----------
        wkno_as_small_integers : bool
            Whether this timedelta data's number of weeks is small integers.
        Other parameters are inherited from parent `ColumnTextualizer`.
        """
        super().__init__(tokenizer, name, index, **kwargs)
        self._sign = None
        self._week = None
        self._day = None
        self._hour = None
        self._minute = None
        self._second = None
        self._microsecond = None

        self._wkno_as_small_integers = wkno_as_small_integers

    def _textualize_notna_cell(self, x: timedelta) -> str:
        out = ""
        if self._sign is None:
            if x >= timedelta(0):
                out += self.tokenizer.pos_token
            else:
                out += self.tokenizer.neg_token
        if x < timedelta(0):
            x = timedelta(0) - x
        if self._week is None:
            out += self.tokenizer.wkno_token
            if self._wkno_as_small_integers:
                out += self.tokenizer.denote_small_integer(x.days // 7, include_sign=False)
            else:
                out += self.tokenizer.factorize_scientific_notation(x.days // 7, include_sign=False)
        if self._day is None:
            out += self.tokenizer.day_token
            out += self.tokenizer.denote_small_integer(x.days % 7, include_sign=False)
        if self._hour is None:
            out += self.tokenizer.hour_token
            out += self.tokenizer.denote_small_integer(x.seconds // 3600, include_sign=False)
        if self._minute is None:
            out += self.tokenizer.minute_token
            out += self.tokenizer.denote_small_integer((x.seconds % 3600) // 60, include_sign=False)
        if self._second is None:
            out += self.tokenizer.second_token
            out += self.tokenizer.denote_small_integer(x.seconds % 60, include_sign=False)
        if self._microsecond is None:
            out += self.tokenizer.microsecond_token
            out += self.tokenizer.denote_small_integer(x.microseconds // 10000, include_sign=False)
            out += self.tokenizer.denote_small_integer((x.microseconds % 10000) // 100, include_sign=False)
            out += self.tokenizer.denote_small_integer(x.microseconds % 100, include_sign=False)
        return out

    def _inverse_raw(self, x: str) -> timedelta:
        return pd.to_timedelta(x, errors="coerce")

    def _remove_sign(self, data: pd.Series) -> pd.Series:
        if self._sign == 1:
            return data
        elif self._sign == -1:
            return timedelta(0) - data
        else:
            return data.apply(lambda x: x if x > timedelta(0) else timedelta(0) - x)

    def _fit(self, data: pd.Series):
        data = data.dropna()
        if len(data) <= 0:
            return
        if (data >= timedelta(0)).sum() == len(data):
            self._sign = 1
        elif (data <= timedelta(0)).sum() == len(data):
            self._sign = -1
        data = self._remove_sign(data)
        weeks = (data.dt.days // 7)
        days = data.dt.days % 7
        hours = data.dt.components.hours
        minutes = data.dt.components.minutes
        seconds = data.dt.components.seconds
        microseconds = data.dt.microseconds

        for name, partial_data in zip(
            ["week", "day", "hour", "minute", "second", "microsecond"],
            [weeks, days, hours, minutes, seconds, microseconds]
        ):
            if partial_data.std() == 0:
                setattr(self, f"_{name}", int(partial_data.mean()))

    def _inverse_tokens(self, x: str) -> Tuple[timedelta, bool]:
        sign = self._sign
        if self._sign is None:
            if x.startswith(self.tokenizer.pos_token):
                sign = 1
                x = x[len(self.tokenizer.pos_token):]
            elif x.startswith(self.tokenizer.neg_token):
                sign = -1
                x = x[len(self.tokenizer.neg_token):]
            else:
                return pd.to_timedelta(np.nan, errors="coerce"), False

        timedelta_dict = {}
        remaining_units = []
        for attr, token in zip(
            ["week", "day", "hour", "minute", "second", "microsecond"],
            ["wkno", "day", "hour", "minute", "second", "microsecond"]
        ):
            if getattr(self, f"_{attr}") is not None:
                timedelta_dict[f"{attr}s"] = getattr(self, f"_{attr}")
            else:
                try:
                    this_token = getattr(self.tokenizer, f"{token}_token")
                    this_indicator = x.index(this_token)
                    if this_token in x[this_indicator + len(this_token):]:
                        return pd.to_timedelta(np.nan, errors="coerce"), False
                    remaining_units.append((this_indicator, attr, this_token))
                except ValueError:
                    return pd.to_timedelta(np.nan, errors="coerce"), False

        remaining_units = sorted(remaining_units)
        remaining_units.append((len(x), "end", "end"))
        for (st, attr, token), (ed, _, _) in zip(remaining_units[:-1], remaining_units[1:]):
            extracted = x[st + len(token):ed]
            if attr == "week" and not self._wkno_as_small_integers:
                recovered, valid = self.tokenizer.defactorize_scientific_notation(
                    extracted, including_sign=False
                )
            else:
                recovered, valid = self.tokenizer.revert_small_integer(
                    extracted,
                    including_sign=False,
                    group_digits=2 if attr == "microsecond" else None,
                    n_groups=3 if attr == "microsecond" else None
                )
            if not valid:
                return pd.to_timedelta(np.nan, errors="coerce"), False
            timedelta_dict[f"{attr}s"] = recovered

        if "weeks" in timedelta_dict:
            timedelta_dict["days"] += 7 * timedelta_dict["weeks"]
            del timedelta_dict["weeks"]
        try:
            tdel = timedelta(**timedelta_dict)
            if sign < 0:
                tdel = timedelta(0) - tdel
            return tdel, True
        except (ValueError, TypeError):
            return pd.to_timedelta(np.nan, errors="coerce"), False

    @property
    def raw_dtype(self) -> RawDType:
        return RawDType.timedelta

    @classmethod
    def _dtype_specific_update(cls, data: pd.Series, tokenizer: TabularDataTokenizer, default_args: Dict[str, Any]):
        pool = {*range(tokenizer.max_small_integer + 1)}
        data = data.dropna().apply(lambda x: x.days // 7)
        if data.isin(pool).sum() == len(data):
            default_args["wkno_as_small_integers"] = True

    @classmethod
    def _learn_default_args(cls,
                            tokenizer: TabularDataTokenizer,
                            default_args: Dict[str, Any]) -> Dict[str, Any]:
        if any(x is not None for x in [
            tokenizer.wkno_token, tokenizer.day_token, tokenizer.hour_token,
            tokenizer.minute_token, tokenizer.second_token, tokenizer.microsecond_token
        ]):
            default_args["use_raw_data"] = False
        return default_args
