"""Textualizer for handling non-standard data."""

from typing import Any, Dict, Tuple

import pandas as pd

from .base import ColumnTextualizer
from ...dtypes import RawDType
from ...tokenizer import TabularDataTokenizer
from ...utils import register


@register(ColumnTextualizer.registry, RawDType.non_std)
class NonStdTextualizer(ColumnTextualizer):
    """
    Column textualizer for mixed raw data type.
    For textualization, we don't care about what data type we are mixing.
    And we can mix data of multiple different types.
    """
    def _textualize_notna_cell(self, x: Any) -> str:
        return ""

    def _inverse_raw(self, x: str) -> str:
        return x

    def _fit(self, data: pd.Series):
        pass

    def _inverse_tokens(self, x: str) -> Tuple[str, bool]:
        if x != "":
            return "", False
        return "", True

    def inverse_textualize(self, data: pd.Series) -> Tuple[pd.Series, pd.Series]:
        data, success = super().inverse_textualize(data)
        data[success] = [*range(success.sum())]
        return data, success

    @property
    def raw_dtype(self) -> RawDType:
        return RawDType.non_std

    @classmethod
    def _learn_default_args(cls,
                            tokenizer: TabularDataTokenizer,
                            default_args: Dict[str, Any]) -> Dict[str, Any]:
        return default_args

