"""Textualizer for handling datetime data."""

from datetime import datetime
from typing import Any, Dict, Tuple

import numpy as np
import pandas as pd

from .base import ColumnTextualizer
from ...dtypes import ColumnName, RawDType
from ...tokenizer import TabularDataTokenizer
from ...utils import register


@register(ColumnTextualizer.registry, RawDType.datetime)
class DatetimeTextualizer(ColumnTextualizer):
    """
    Column textualizer for datetime raw data type.
    """
    def __init__(self,
                 tokenizer: TabularDataTokenizer,
                 name: ColumnName = "",
                 index: int = 0,
                 *,
                 include_weekday: bool = True,
                 include_am_pm: bool = False,
                 include_day_of_year: bool = False,
                 include_week_number: bool = False,
                 include_timezone: bool = True,
                 **kwargs):
        """
        Parameters
        ----------
        include_weekday : bool
            Whether weekday information is included after textualization.
        include_am_pm : bool
            Whether AM/PM information is included after textualization.
        include_day_of_year : bool
            Whether day of the year information is included after textualization.
        include_week_number : bool
            Whether week number information is included after textualization.
        include_timezone : bool
            Whether timezone information is included after textualization.
        Other parameters are inherited from parent `ColumnTextualizer`.
        """
        super().__init__(tokenizer, name, index, **kwargs)
        self._year = None
        self._month = None
        self._day = None
        self._hour = None
        self._minute = None
        self._second = None
        self._microsecond = None

        self._include_weekday = include_weekday
        self._include_am_pm = include_am_pm
        self._include_day_of_year = include_day_of_year
        self._include_week_number = include_week_number
        self._include_timezone = include_timezone

    def _textualize_notna_cell(self, x: datetime) -> str:
        out = ""
        if self._year is None:
            out += self.tokenizer.year_token
            out += self.tokenizer.denote_small_integer(x.year // 100, include_sign=False)
            out += self.tokenizer.denote_small_integer(x.year % 100, include_sign=False)
        if self._include_week_number:
            out += self.tokenizer.wkno_token
            out += self.tokenizer.denote_small_integer(int(x.strftime("%U")), include_sign=False)
        if self._include_day_of_year:
            out += self.tokenizer.day_of_year_token
            out += self.tokenizer.denote_small_integer(int(x.strftime("%j")), include_sign=False)
        if self._month is None:
            out += self.tokenizer.month_token
            out += self.tokenizer.denote_small_integer(x.month, include_sign=False)
        if self._include_weekday:
            out += self.tokenizer.weekday_token
            out += self.tokenizer.denote_small_integer(int(x.strftime("%w")), include_sign=False)
        if self._day is None:
            out += self.tokenizer.day_token
            out += self.tokenizer.denote_small_integer(x.day, include_sign=False)
        if self._include_am_pm:
            out += self.tokenizer.am_pm_token
            is_am = x.strftime("%p") == "AM"
            out += self.tokenizer.get_category_token(0 if is_am else 1)
        if self._include_timezone:
            out += self.tokenizer.tz_token
            tz = x.strftime("%z")
            if tz == "":
                tz = 0
            else:
                tz = int(tz)
            out += self.tokenizer.denote_small_integer(tz, include_sign=True)
        for attr in ["hour", "minute", "second"]:
            if getattr(self, f"_{attr}") is None:
                out += getattr(self.tokenizer, f"{attr}_token")
                out += self.tokenizer.denote_small_integer(getattr(x, attr), include_sign=False)
        if self._microsecond is None:
            out += self.tokenizer.microsecond_token
            out += self.tokenizer.denote_small_integer(x.microsecond // 10000, include_sign=False)
            out += self.tokenizer.denote_small_integer((x.microsecond % 10000) // 100, include_sign=False)
            out += self.tokenizer.denote_small_integer(x.microsecond % 100, include_sign=False)

        return out

    def _inverse_raw(self, x: str) -> datetime:
        return pd.to_datetime(x, errors="coerce")

    def _fit(self, data: pd.Series):
        data = data.dropna()
        if len(data) <= 0:
            return
        for attr in ["year", "month", "day", "hour", "minute", "second", "microsecond"]:
            if getattr(data.dt, attr).std() == 0:
                setattr(self, f"_{attr}", getattr(data.dt, attr).mean())
        if self._day is not None:
            self._include_weekday = False
            self._include_day_of_year = False
            self._include_week_number = False
        if self._hour is not None:
            self._include_am_pm = False
        if (data.apply(lambda x: x.strftime("%z")) != "").sum() == 0:
            self._include_timezone = False

    def _inverse_tokens(self, x: str) -> Tuple[datetime, bool]:
        datetime_dict = {}
        remaining_units = []
        all_units = ["year", "month", "day", "hour", "minute", "second", "microsecond"]
        for attr in all_units:
            if getattr(self, f"_{attr}") is not None:
                datetime_dict[attr] = int(getattr(self, f"_{attr}"))
            else:
                try:
                    this_token = getattr(self.tokenizer, f"{attr}_token")
                    this_indicator = x.index(this_token)
                    if this_token in x[this_indicator + len(this_token):]:
                        return pd.to_datetime(np.nan, errors="coerce"), False
                    remaining_units.append((this_indicator, attr, this_token))
                except ValueError:
                    return pd.to_datetime(np.nan, errors="coerce"), False
        for aux_token, var_name in zip(
            ["weekday", "am_pm", "wkno", "day_of_year", "tz"],
            ["weekday", "am_pm", "week_number", "day_of_year", "timezone"]
        ):
            this_token = getattr(self.tokenizer, f"{aux_token}_token")
            should_include = getattr(self, f"_include_{var_name}")
            count = 0 if this_token is None else x.count(this_token)
            if (should_include and count != 1) or (not should_include and count != 0):
                return pd.to_datetime(np.nan, errors="coerce"), False
            if should_include:
                this_indicator = x.index(this_token)
                remaining_units.append((this_indicator, aux_token, this_token))

        remaining_units = sorted(remaining_units)
        remaining_units.append((len(x), "end", "end"))
        for (st, attr, token), (ed, _, _) in zip(remaining_units[:-1], remaining_units[1:]):
            if attr not in all_units:
                continue
            extracted = x[st + len(token):ed]
            recovered, valid = self.tokenizer.revert_small_integer(
                extracted,
                including_sign=False,
                group_digits=2 if attr in {"year", "microsecond"} else None,
                n_groups=2 if attr == "year" else 3 if attr == "microsecond" else None
            )
            if not valid:
                return pd.to_datetime(np.nan, errors="coerce"), False
            datetime_dict[attr] = recovered
        try:
            return datetime(**datetime_dict), True
        except (ValueError, TypeError):
            return pd.to_datetime(np.nan, errors="coerce"), False

    @property
    def raw_dtype(self) -> RawDType:
        return RawDType.datetime

    @classmethod
    def _learn_default_args(cls,
                            tokenizer: TabularDataTokenizer,
                            default_args: Dict[str, Any]) -> Dict[str, Any]:
        if any(x is not None for x in [
            tokenizer.year_token, tokenizer.month_token, tokenizer.day_token, tokenizer.hour_token,
            tokenizer.minute_token, tokenizer.second_token, tokenizer.microsecond_token
        ]):
            default_args["use_raw_data"] = False

        for token, key in zip(
            [tokenizer.weekday_token, tokenizer.am_pm_token, tokenizer.day_of_year_token,
             tokenizer.wkno_token, tokenizer.tz_token],
            ["weekday", "am_pm", "day_of_year", "week_number", "timezone"]
        ):
            if token is None:
                default_args[f"include_{key}"] = False
        return default_args
