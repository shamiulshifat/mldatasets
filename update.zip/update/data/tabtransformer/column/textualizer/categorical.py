"""Textualizer for handling categorical data."""

from typing import Any, Dict, Tuple

import pandas as pd

from .base import ColumnTextualizer
from ...dtypes import RawDType
from ...tokenizer import TabularDataTokenizer
from ...utils import register


@register(ColumnTextualizer.registry, RawDType.categorical)
class CategoricalTextualizer(ColumnTextualizer):
    """
    Column textualizer for categorical raw data type.
    """
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._cat2id = {}
        self._id2cat = []

    def _textualize_notna_cell(self, x: Any) -> str:
        return self.tokenizer.get_category_token(self._cat2id[x])

    def _inverse_raw(self, x: str) -> Any:
        return x

    def _fit(self, data: pd.Series):
        categories = data.dropna().unique()
        for i, c in enumerate(categories):
            self._cat2id[c] = i
            self._id2cat.append(c)

    def _inverse_tokens(self, x: str) -> Tuple[Any, bool]:
        cat_id, valid = self.tokenizer.check_category_token(x)
        if cat_id > len(self._id2cat):
            valid = False
        if valid:
            return self._id2cat[cat_id], True
        else:
            return "", False

    @property
    def raw_dtype(self) -> RawDType:
        return RawDType.categorical

    @classmethod
    def _learn_default_args(cls,
                            tokenizer: TabularDataTokenizer,
                            default_args: Dict[str, Any]) -> Dict[str, Any]:
        if default_args.get("use_raw_data") is None:
            default_args["use_raw_data"] = tokenizer.num_categories == 0
        return default_args
