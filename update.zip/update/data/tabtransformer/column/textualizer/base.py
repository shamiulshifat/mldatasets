"""Common structure for textualizers for different raw data types."""

import json
import logging
from abc import ABC, abstractmethod
from copy import deepcopy
from typing import Any, Collection, Dict, Optional, Tuple, Type, Union

import numpy as np
import pandas as pd

from ...dtypes import ColumnName, RawDType, learn_raw_dtype_for_textualizer
from ...tokenizer import TabularDataTokenizer
from ...utils import log, log_time, make_dict, make_enum, make_json_compatible


class ColumnTextualizer(ABC):
    """
    Textualizer of columns that converts data in a column into texts.
    """
    registry: Dict[RawDType, Type["ColumnTextualizer"]] = {}
    """Registry of textualizer for different raw data types."""
    _default_na_equiv = ["-", "", "N/A", "nan", "na", "Nil", "Nil.", "NaT", "NaN", "None"]

    def __init__(self,
                 tokenizer: TabularDataTokenizer,
                 name: ColumnName = "",
                 index: int = 0,
                 *,
                 use_raw_data: bool = False,
                 na_equivalences: Optional[Collection] = None):
        """
        Initialize a new instance of `ColumnTextualizer`, for a new column.

        Parameters
        ----------
        tokenizer : TabularDataTokenizer
            The tokenizer to use for the data.
        name : ColumnName, optional
            Name of the column.
        index : int, optional
            Index of this column.
        use_raw_data : bool, optional
            Whether to use the raw data directly converted to string, or use some special encodings
            (depending on the column type).
        na_equivalences : Collection, optional
            Values treated as N/A because sometimes such values are not represented as nan in the data,
            typically due to data formatting and IO.
            If not provided, the set of N/A equivalence values are (strings after stripping):
            "-", "", "N/A", "nan", "na", "Nil", "Nil."
        """
        self.tokenizer = tokenizer
        self.name = name
        self.index = index
        self.na_equiv = self._default_na_equiv if na_equivalences is None else na_equivalences
        self.use_raw_data = use_raw_data
        self._fitted = False
        self._max_tokens = None

    @property
    @abstractmethod
    def raw_dtype(self) -> RawDType:
        """Raw data type of this column."""
        raise NotImplementedError()

    def cell_prefix(self, use_raw_column_name: bool = False) -> str:
        """
        Get the prefix for each cell in this column.

        Parameters
        ----------
        use_raw_column_name : bool, optional
            Whether to use raw column name, or to use the special column tokens.

        Returns
        -------
        str
            The prefix for each cell in this column in text.
        """
        if use_raw_column_name:
            return self.name + self.tokenizer.kv_sep_token
        else:
            return self.tokenizer.get_column_token(self.index)

    @property
    def n_tokens(self) -> int:
        """The number of tokens needed for this column. This is the maximum number of tokens in the data fitted on."""
        if not self._fitted:
            raise RuntimeError("The texualizer is not yet fitted. Please fit before getting the "
                               "number of tokens.")
        return self._max_tokens

    @log_time("Fitting column textualizer", "Finished fitting column textualizer",
              start_level=log.TRACE_LEVEL, end_level=logging.DEBUG, with_name=True)
    def fit(self, data: pd.Series):
        """
        Fit the textualizer to the data.

        Parameters
        ----------
        data : pd.Series
            The data to fit textualizer on.
        """
        data = self._validate_dtype(data)
        if not self.use_raw_data:
            self._fit(data)
            self._fitted = True
            data = self.textualize(data)
        else:
            data = data.astype(str)
            self._fitted = True
        lengths = data.drop_duplicates().apply(
            lambda x: len(self.tokenizer.encode(x))
        )
        self._max_tokens = lengths.max()

    @log_time("Converting column to text for", "Finished text conversion for",
              start_level=log.TRACE_LEVEL, end_level=logging.DEBUG, with_name=True)
    def textualize(self, data: pd.Series, pad: bool = False) -> pd.Series:
        """
        Convert raw data to text for each data cell, without prefix.

        Parameters
        ----------
        data : pd.Series
            The data to textualize.
        pad : bool, optional
            Whether to pad the data to the maximum number of tokens in the cell.

        Returns
        -------
        pd.Series
            Textualized data for each data cell.
        """
        if not self._fitted:
            raise RuntimeError("The texualizer is not yet fitted. Please fit before textualization.")
        data = self._validate_dtype(data)
        if self.use_raw_data:
            out = data.astype(str)
        else:
            out = data.apply(self._textualize_cell)
        if pad:
            out = out.apply(self._pad)
        return out

    def _textualize_cell(self, x: Any) -> str:
        if pd.isnull(x):
            out = self.tokenizer.nan_token
        else:
            out = self._textualize_notna_cell(x)
        return out

    def _pad(self, x: str) -> str:
        encoded = self.tokenizer.encode(x)
        if len(encoded) > self._max_tokens:
            raise RuntimeError(f"The cell value {x} is tokenized to {len(encoded)} tokens "
                               f"but only {self._max_tokens} are allowed.")
        padding = [
            self.tokenizer.in_cell_pad_token
            for _ in range(self._max_tokens - len(encoded))
        ]
        encoded += padding
        return self.tokenizer.decode(encoded)

    @abstractmethod
    def _textualize_notna_cell(self, x: Any) -> str:
        raise NotImplementedError()

    @log_time("Recovering raw data from text for", "Recovered raw data from text for",
              start_level=log.TRACE_LEVEL, end_level=logging.DEBUG, with_name=True)
    def inverse_textualize(self, data: pd.Series) -> Tuple[pd.Series, pd.Series]:
        """
        Convert textualized data to raw format for each data cell, without prefix.

        Parameters
        ----------
        data : pd.Series
            The data after textualization.

        Returns
        -------
        pd.Series
            Raw data recovered for each data cell.
            If input passed is nan in some cells, the nan values will be retained.
        pd.Series
            A boolean Series indicating whether the inverse process on this value succeeds or not.
            True means success.
        """
        if not self._fitted:
            raise RuntimeError("The texualizer is not yet fitted. Please fit before inverse textualization.")
        index = data.index
        isna_indices = data.isna()
        data = data.dropna().astype(str).apply(self._remove_pad)
        if len(data) > 0:
            if self.use_raw_data:
                data = data.apply(self._inverse_raw)
                success = data[data.notna()]
            else:
                inversed_data, success = data.apply(self._inverse_tokens_with_na).apply(pd.Series).T.values
                data = pd.Series(inversed_data, index=data.index)
                success = pd.Series(success, index=data.index, dtype=bool)
        else:
            data = pd.Series(name=data.name)
            success = pd.Series()
        data = pd.Series({
            i: np.nan if isna else data[i]
            for i, isna in zip(index, isna_indices)
        }, name=self.name)
        data = self._validate_dtype(data)
        success = pd.Series({
            i: False if isna else success[i]
            for i, isna in zip(index, isna_indices)
        })
        return data, success

    def _remove_pad(self, x: str) -> str:
        tokenized = self.tokenizer.tokenize(x)
        tokenized = [
            w for w in tokenized if w != self.tokenizer.in_cell_pad_token
        ]
        return self.tokenizer.de_tokenize(tokenized)

    @abstractmethod
    def _inverse_raw(self, x: str) -> Any:
        raise NotImplementedError()

    @abstractmethod
    def _fit(self, data: pd.Series):
        raise NotImplementedError()

    def _inverse_tokens_with_na(self, x: str) -> Tuple[Any, bool]:
        if x == self.tokenizer.nan_token:
            return np.nan, True
        else:
            return self._inverse_tokens(x)

    @abstractmethod
    def _inverse_tokens(self, x: str) -> Tuple[Any, bool]:
        raise NotImplementedError()

    def _validate_dtype(self, data: pd.Series) -> pd.Series:
        data = data.replace({
            v: np.nan for v in self.na_equiv
        })
        if self.raw_dtype.is_valid_dtype(str(data.dtype)):
            return data
        return self._convert_dtype(data)

    def _convert_dtype(self, data: pd.Series) -> pd.Series:
        return data.astype(self.raw_dtype.default_dtype)

    @classmethod
    def make(cls,
             raw_dtype: Union[RawDType, str],
             *args,
             **kwargs) -> "ColumnTextualizer":
        """
        Construct a `ColumnTransformer` instance based on the given type and arguments.

        Parameters
        ----------
        raw_dtype : str or RawDType
            The raw column type.
        *args, **kwargs
            Parameters to the transformer of the given method type in the given stype.
        """
        raw_dtype: RawDType = make_enum(raw_dtype, RawDType)
        return cls.registry[raw_dtype](*args, **kwargs)

    @classmethod
    def learn_default_args(cls,
                           tokenizer: TabularDataTokenizer,
                           default_args: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Learn the default arguments by the given tokenizer.
        We will make use of the special tokens in the tokenizer as far as possible, unless restricted by the default
        given.

        Parameters
        ----------
        tokenizer : TabularDataTokenizer
            The tokenizer to use.
        default_args : dict, optional
            The default arguments for this column to force the result to be.
            However, very rarely occasionally, if the provided args conflict with the tokenizer (such that the default
            argument provided is not applicable to this tokenizer, the default values provided may be overriden).

        Returns
        -------
        dict
            The learned default arguments.
        """
        default_args = deepcopy(make_dict(default_args))
        return cls._learn_default_args(tokenizer, default_args)

    @classmethod
    @log_time("Learning kwargs for textualizer of", "Finished learning column textualizer kwargs for",
              start_level=log.TRACE_LEVEL, end_level=logging.DEBUG, with_name=True)
    def learn_args(cls,
                   data: pd.Series,
                   tokenizer: TabularDataTokenizer,
                   *,
                   raw_dtype: Optional[Union[RawDType, str]] = None,
                   unique_threshold: float = .95,
                   encoding_threshold: int = 200,
                   default_args: Optional[Dict[Union[RawDType, str], Dict[str, Any]]] = None,
                   provided_args: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Learn the arguments for textualizer from a given column.

        Parameters
        ----------
        data : pd.Series
            The column data.
        tokenizer : TabularDataTokenizer
            The tokenizer to be used.
        raw_dtype : RawDType, optional
            The known raw dtype. If not provided, we will learn.
        unique_threshold : float
            After removing N/A values in the column, if the number of unique non-continuous values divided by the
            number of rows hit this threshold, this column will be treated as non-standard. Default is 0.95.
        encoding_threshold : int
            If the number of different categories (besides N/A) is greater or equal to this value,
            and we do not hit the unique threshold above, we will treat it as encoding. Default is 200.
        default_args : dict, optional
            Default arguments per raw data type.
            This dict maps each raw data type to its corresponding default kwargs.
            The args for each raw data type may refer to the textualizers for
            [categorical](/tabtransformer/column/textualizer/categorical#tabtransformer.column.textualizer.categorical.CategoricalTextualizer),
            [numerical](/tabtransformer/column/textualizer/numerical#tabtransformer.column.textualizer.numerical.NumericalTextualizer),
            [datetime](/tabtransformer/column/textualizer/datetime#tabtransformer.column.textualizer.datetime.DatetimeTextualizer),
            [timedelta](/tabtransformer/column/textualizer/timedelta#tabtransformer.column.textualizer.timedelta.TimedeltaTextualizer),
            [mixed](/tabtransformer/column/textualizer/mixed#tabtransformer.column.textualizer.mixed.MixedTextualizer),
            [encoding](/tabtransformer/column/textualizer/encoding#tabtransformer.column.textualizer.encoding.EncodingTextualizer),
            [non_std](/tabtransformer/column/textualizer/non_std#tabtransformer.column.textualizer.non_std.NonStdTextualizer).
        provided_args : dict, optional
            Arguments already provided for this column.
        """
        provided_args = make_dict(provided_args)
        raw_dtype = raw_dtype if raw_dtype is not None else provided_args.get("raw_dtype")
        raw_dtype = learn_raw_dtype_for_textualizer(data, raw_dtype, unique_threshold, encoding_threshold)
        logging.debug(f"Inferred raw data type is {raw_dtype.name}.")

        default_args = {
            make_enum(k, RawDType): v
            for k, v in make_dict(default_args).items()
        }
        args = cls._get_args_from_default(default_args, raw_dtype)
        sub_class: Type[ColumnTextualizer] = cls.registry[raw_dtype]
        sub_class._dtype_specific_update(data, tokenizer, args)
        args.update(provided_args)
        args["raw_dtype"] = raw_dtype
        logging.log(log.TRACE_LEVEL, f"The learned argument is {json.dumps(make_json_compatible(args), indent=2)}.")
        return args

    @classmethod
    def _dtype_specific_update(cls, data: pd.Series, tokenizer: TabularDataTokenizer, default_args: Dict[str, Any]):
        return

    @classmethod
    def _get_args_from_default(cls, default_args: Dict[RawDType, Dict[str, Any]], raw_dtype: RawDType) \
            -> Dict[str, Any]:
        args = deepcopy(default_args.get(raw_dtype, {}))
        if raw_dtype == RawDType.mixed:
            base_args = {"use_raw_data", "na_equivalences"}
            sub_types = [RawDType.categorical, RawDType.numerical, RawDType.datetime, RawDType.timedelta]
            for dt in sub_types:
                default_for_dt = default_args.get(dt, {})
                for k, v in default_for_dt.items():
                    if k not in base_args and k not in args:
                        args[k] = v
        return args

    @classmethod
    @abstractmethod
    def _learn_default_args(cls,
                            tokenizer: TabularDataTokenizer,
                            default_args: Dict[str, Any]) -> Dict[str, Any]:
        raise NotImplementedError()
