"""Textualizer for handling encoding data."""

from typing import Any, Dict, Tuple

import pandas as pd

from .base import ColumnTextualizer
from ...dtypes import ColumnName, RawDType
from ...tokenizer import TabularDataTokenizer
from ...utils import register


@register(ColumnTextualizer.registry, RawDType.encoding)
class EncodingTextualizer(ColumnTextualizer):
    """
    Column textualizer for encoding raw data type.
    The good feature of LLM is that it can learn embeddings over large vocabulary.
    Therefore, detailed information associated to each encoding is not used.
    We will understand the data as natural language per se.
    However, do take care that if there are encoding columns in a dataset,
    it is suggested not to abandon the pre-trained weights.
    """
    def __init__(self,
                 tokenizer: TabularDataTokenizer,
                 name: ColumnName = "",
                 index: int = 0,
                 *,
                 out_of_pool_allowed: bool = True,
                 **kwargs):
        """
        Parameters
        ----------
        out_of_pool_allowed : bool
            Whether to allow data outside of the pool of data that it has seen during fitting.
            If allowed, zero-shot synthesis is possible.

        Other parameters are inherited from parent `ColumnTextualizer`.
        """
        super().__init__(tokenizer, name, index, **kwargs)
        self._out_of_pool_allowed = out_of_pool_allowed
        self._pool = None

    def _textualize_notna_cell(self, x: str) -> str:
        return x

    def _inverse_raw(self, x: str) -> str:
        return x

    def _fit(self, data: pd.Series):
        if not self._out_of_pool_allowed:
            self._pool = {*data.dropna().astype(str)}

    def _inverse_tokens(self, x: str) -> Tuple[str, bool]:
        if not self._out_of_pool_allowed and x not in self._pool:
            return "", False
        return x, True

    @property
    def raw_dtype(self) -> RawDType:
        return RawDType.encoding

    @classmethod
    def _learn_default_args(cls,
                            tokenizer: TabularDataTokenizer,
                            default_args: Dict[str, Any]) -> Dict[str, Any]:
        return default_args
