"""Imputing NaN values from context."""

from typing import Any, Collection, Dict, Optional

import pandas as pd
from sklearn.impute import KNNImputer

from ..dtypes import ColumnName
from ..utils import log_time, make_dict, make_list


class TableImputer:
    """A class that imputes NaN values."""
    def __init__(self,
                 impute_columns: Optional[Collection[ColumnName]] = None,
                 imputer_kwargs: Optional[Dict[str, Any]] = None):
        """
        Initialize a `TableImputer` instance.

        Parameters
        ----------
        impute_columns : list, optional
            The columns to impute on. If not provided, we will keep the normalized data as it is.
        imputer_kwargs : dict, optional
            Arguments to scikit-learn
            [`KNNImputer`](https://scikit-learn.org/stable/modules/generated/sklearn.impute.KNNImputer.html).
        """
        self.impute_columns = make_list(impute_columns)
        self.imputer = KNNImputer(**make_dict(imputer_kwargs))

    @log_time("Fitting KNNImputer", "Finished fitting KNNImputer")
    def fit(self, data: pd.DataFrame):
        """
        Fit the imputer on the given data.

        Parameters
        ----------
        data : pd.DataFrame
            The raw data that contains some raw values.
        """
        self.imputer.fit(data.values)

    @log_time("Imputing data by KNN", "Finished KNN imputing")
    def impute(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        Impute data.

        Parameters
        ----------
        data : pd.DataFrame
            The raw data that contains some raw values.

        Returns
        -------
        pd.DataFrame
            Data after imputation.
        """
        columns = data.columns
        data = self.imputer.transform(data)
        return pd.DataFrame(data, columns=columns)
