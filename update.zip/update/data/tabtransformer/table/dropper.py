"""Dropping unnecessary data."""

import logging
import time
from typing import List, Optional

import pandas as pd

from ..dtypes import ColumnName
from ..utils import make_list, make_printable_lapse_time


class TableDropper:
    """
    Class that drops unused data.
    """
    def __init__(self, *,
                 drop_columns: Optional[List[ColumnName]] = None,
                 dropna_columns: Optional[List[ColumnName]] = None):
        """
        Initialize a new instance of `TableDropper`, for a new dataset.

        Parameters
        ----------
        drop_columns : list[str], optional
            Columns to drop. They will never appear in any transformation steps later.
            If not provided, no columns are dropped.
            This set should not overlap with any other set below.
        dropna_columns : list[str], optional
            Columns to drop N/A values. That is, rows containing N/A value in these columns are to be removed.
            If not provided, no rows are dropped.
            This set can overlap with any other set below.
        """
        self.drop_columns = make_list(drop_columns)
        self.dropna_columns = make_list(dropna_columns)

    def drop(self, data: pd.DataFrame, drop_duplicates: bool = True) -> pd.DataFrame:
        """
        Drop undesired part from the data. Including the following operations:
        - drop_column
        - dropna
        - drop_duplicates (optional)

        Parameters
        ----------
        data : pd.DataFrame
            The data to handle with.
        drop_duplicates : bool, optional (default True)
            Whether to remove duplicates.

        Returns
        -------
        pd.DataFrame
            The DataFrame after the dropping operation.
        """
        logging.debug("Dropping unnecessary components from the data ...")
        start_time = time.time()
        data = self.drop_column(data)
        data = self.dropna(data)
        if drop_duplicates:
            data = self.drop_duplicates(data)
        end_time = time.time()
        logging.info(f"Finished dropping unnecessary components from data "
                     f"in {make_printable_lapse_time(start_time, end_time)}.")
        return data

    def drop_column(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        Drop the columns to drop from the data.

        Parameters
        ----------
        data : pd.DataFrame
            The data to handle with.

        Returns
        -------
        pd.DataFrame
            The DataFrame after dropping the columns.
        """
        out = data.drop(columns=self.drop_columns)
        logging.debug("Dropped unnecessary columns.")
        return out

    def dropna(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        Drop rows containing N/A values in columns that should not have N/A.

        Parameters
        ----------
        data : pd.DataFrame
            The data to handle with.

        Returns
        -------
        pd.DataFrame
            The DataFrame after dropping N/A rows, and row indices being upgraded to consecutive integers.
        """
        if data.empty:
            return data
        indicator = data.iloc[:, 0] != data.iloc[:, 0]
        for col in self.dropna_columns:
            indicator |= data.loc[:, col].isna()
        out = data[~indicator].reset_index(drop=True)
        logging.debug("Dropped rows that has N/A in columns that should be N/A free.")
        return out

    @staticmethod
    def drop_duplicates(data: pd.DataFrame) -> pd.DataFrame:
        """
        Drop duplicated rows.

        Parameters
        ----------
        data : pd.DataFrame
            The data to handle with.

        Returns
        -------
        pd.DataFrame
            The DataFrame after dropping duplicates, and row indices being upgraded to consecutive integers.
        """
        out = data.drop_duplicates().reset_index(drop=True)
        logging.debug("Dropped duplicates.")
        return out
