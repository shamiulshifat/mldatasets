"""Combined dimension reducer that contains multiple reduction steps."""

from typing import Optional, List, Union, Tuple, Dict, Any

import pandas as pd

from .base import DimReducer, DimReducerType
from .select import VTDimReducer
from ...dtypes import ColumnName
from ...utils import log_time, make_list


class TableDimReducer:
    """
    Dimension reducer of a table after normalization.
    """
    def __init__(self, *,
                 reversible_reducers: Optional[List[Union[
                     DimReducer, Tuple[Union[str, DimReducerType], int, Dict[str, Any]]
                 ]]] = None,
                 irreversible_reducers: Optional[List[Union[
                     DimReducer, Tuple[Union[str, DimReducerType], int, Dict[str, Any]]
                 ]]] = None):
        """
        Initialize a new instance of `TableDimReducer`, for a new dataset.

        Parameters
        ----------
        reversible_reducers : list[DimReducer or (DimReducerType, int, dict)], optional
            Reversible reducers.
            If a tuple is given as a list element, the tuple means (reducer type, maximum dimension, other arguments).
            The reducers are applied in order.
            Reversible reducers are applied before irreversible ones.
            So ideally the max dimension for previous reducers should be larger than the later ones.
            If nothing is given, we will apply only the removal of columns of variance being 0.
        irreversible_reducers : list[DimReducer or (DimReducerType, int, dict)], optional
            Irreversible reducers. If nothing is given, no reducers will be applied.
        """
        self.important_dim = None
        if reversible_reducers is None:
            self._reversible = [VTDimReducer()]
        else:
            self._reversible = self._construct_reducers(reversible_reducers)
        self._irreversible = self._construct_reducers(make_list(irreversible_reducers))
        self._columns = None
        self._original_columns = None
        self._fitted = False

    @staticmethod
    def _construct_reducers(reversible_reducers: List[Union[
        DimReducer, Tuple[Union[str, DimReducerType], int, Dict[str, Any]]
    ]]) -> List[DimReducer]:
        reducers = []
        for r in reversible_reducers:
            if isinstance(r, DimReducer):
                reducers.append(r)
            else:
                t, d, args = r
                if t == DimReducerType.variance_threshold:
                    reducers.append(DimReducer.make(t, **args))
                else:
                    reducers.append(DimReducer.make(t, max_dim=d, **args))
        return reducers

    @log_time("Fitting dimension reducers", "Finished fitting dimension reducers")
    def fit(self, data: pd.DataFrame, important_columns: Optional[List[ColumnName]] = None):
        """
        Fit dimension reducers for the data.

        Parameters
        ----------
        data : pd.DataFrame
            The data to fit dimension reducers on.
        important_columns : list[ColumnName], optional
            Important columns that are not to be reduced in any dimension reducer.
        """
        important = {}
        for c in make_list(important_columns):
            important[c] = data[c].iloc[:10]
        if len(important) > 0:
            important = pd.concat(important, axis=1)
        else:
            important = pd.DataFrame(index=data.index)
        self._original_columns = data.columns
        self.important_dim = len(important.columns)
        self._columns = pd.concat([
            important,
            data.drop(columns=important.columns).iloc[:10]
        ], axis=1).columns

        data = data[self._columns]
        data = data.iloc[:, self.important_dim:]
        for r in self._reversible + self._irreversible:
            data = pd.DataFrame(data)
            r.fit(data)
            data = r.reduce(data)
        self._fitted = True

    def _check_fitted(self, act: str):
        if not self._fitted:
            raise RuntimeError(f"The dimension reducer is not yet fitted. Please fit before {act}.")

    @log_time("Reducing dimensions by reversible reducers", "Finished reducing dimensions by reversible reducers")
    def reversible_reduce(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        Dimension reduction for reversible reducers.

        Parameters
        ----------
        data : pd.DataFrame
            The data to reduce dimension on.

        Returns
        -------
        pd.DataFrame
            The data after dimension reduction.
        """
        data = data[self._columns]
        return self._reduce(data, self._reversible)

    @log_time("Reducing dimensions by irreversible reducers", "Finished reducing dimensions by irreversible reducers")
    def irreversible_reduce(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        Dimension reduction for irreversible reducers.

        Parameters
        ----------
        data : pd.DataFrame or np.ndarray
            The data to reduce dimension on, after reversible reduction is done.

        Returns
        -------
        np.ndarray or pd.DataFrame
            The data after dimension reduction.
            The result is pd.DataFrame only in there are no reducers.
        """
        return self._reduce(data, self._irreversible)

    def _reduce(self, data: pd.DataFrame, reducers: List[DimReducer]) -> pd.DataFrame:
        important = data.iloc[:, :self.important_dim]
        data = data.iloc[:, self.important_dim:]
        nlevels = data.columns.nlevels
        for r in reducers:
            data = r.reduce(data)
            if data.shape[-1] > 0:
                columns = pd.MultiIndex.from_tuples([
                    ("",) * (nlevels - 1) + (f"col{x}",)
                    for x in range(data.shape[-1])
                ])
            else:
                columns = []
            data = pd.DataFrame(data, columns=columns)
        return pd.concat([important, data], axis=1)

    @log_time("Reducing dimensions", "Finished reducing dimensions")
    def reduce(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        Dimension reduction for all reducers.

        Parameters
        ----------
        data : pd.DataFrame
            The data to reduce dimension on.

        Returns
        -------
        pd.DataFrame
            The data after dimension reduction.
        """
        result = self.reversible_reduce(data)
        return self.irreversible_reduce(result)

    @log_time("Recovering data before dimension reduction for reversible reducers",
              "Data before dimension reduction is recovered")
    def recover(self, reduced: pd.DataFrame) -> pd.DataFrame:
        """
        Recover original data from dimension-reduced data (reversible part only).

        Parameters
        ----------
        reduced : pd.DataFrame
            Reversibly reduced data.

        Returns
        -------
        pd.DataFrame
            The recovered data.
        """
        important = reduced.iloc[:, :self.important_dim]
        data = reduced.iloc[:, self.important_dim:]
        for r in self._reversible:
            data = r.recover(data.values)
        return pd.concat([important, data], axis=1)[self._original_columns]
