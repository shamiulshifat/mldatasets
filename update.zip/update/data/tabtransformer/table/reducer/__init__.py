"""Dimension reduction of high-dimensional data."""

from .base import DimReducer, DimReducerType
from .combined import TableDimReducer
from .da import LDADimReducer
from .manifold import ManifoldDimReducer
from .pca import DecompositionDimReducer
from .select import VTDimReducer


__all__ = (
    "DimReducerType",
    "DimReducer",
    "TableDimReducer"
)
