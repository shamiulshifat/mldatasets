"""Dimension reducers based on decomposition methods."""

import enum
from typing import Type, Union

import numpy as np
import pandas as pd

from sklearn.base import TransformerMixin
from sklearn.decomposition import PCA, KernelPCA, IncrementalPCA, SparsePCA, MiniBatchSparsePCA, TruncatedSVD

from .base import DimReducer, DimReducerType
from ...utils import register, make_enum


class DecompositionPolicy(enum.Enum):
    """Decomposition dimension-reduction policies. They come from scikit-learn `decomposition` package."""

    PCA = enum.auto()
    """PCA."""
    KPCA = enum.auto()
    """Kernel PCA."""
    IPCA = enum.auto()
    """Incremental PCA."""
    SPCA = enum.auto()
    """Space PCA."""
    MBSPCA = enum.auto()
    """Minibatch Sparce PCA."""
    SVD = enum.auto()
    """Truncated SVD."""

    @property
    def sklearn_model(self) -> Type[TransformerMixin]:
        """
        The corresponding scikit-learn class. They are
        [`PCA`](https://scikit-learn.org/stable/modules/generated/sklearn.decomposition.PCA.html),
        [`KPCA`](https://scikit-learn.org/stable/modules/generated/sklearn.decomposition.KernelPCA.html),
        [`IPCA`](https://scikit-learn.org/stable/modules/generated/sklearn.decomposition.IncrementalPCA.html),
        [`SPCA`](https://scikit-learn.org/stable/modules/generated/sklearn.decomposition.SparsePCA.html),
        [`MBSPCA`](https://scikit-learn.org/stable/modules/generated/sklearn.decomposition.MiniBatchSparsePCA.html),
        [`SVD`](https://scikit-learn.org/stable/modules/generated/sklearn.decomposition.TruncatedSVD.html).
        """
        if self == DecompositionPolicy.PCA:
            return PCA
        elif self == DecompositionPolicy.KPCA:
            return KernelPCA
        elif self == DecompositionPolicy.IPCA:
            return IncrementalPCA
        elif self == DecompositionPolicy.SPCA:
            return SparsePCA
        elif self == DecompositionPolicy.MBSPCA:
            return MiniBatchSparsePCA
        elif self == DecompositionPolicy.SVD:
            return TruncatedSVD
        raise NotImplementedError(f'There is no scikit-learn model matching dimension reduction method {self.name}.')


@register(DimReducer.registry, DimReducerType.decomposition)
class DecompositionDimReducer(DimReducer):
    """Dimension reducer by decomposition. This class if reversible."""
    def __init__(self,
                 max_dim: int = 100,
                 policy: Union[str, DecompositionPolicy] = DecompositionPolicy.PCA,
                 **kwargs):
        """
        Parameters
        ----------
        policy : DecompositionPolicy
            The decomposition algorithm.
        **kwargs
            Arguments to the
            [scikit-learn model](/tabtransformer/table/reducer/pca#tabtransformer.table.reducer.pca.DecompositionPolicy.sklearn_model)
            besides `n_components`.
        Other arguments are inherited from the parent `DimReducer`.
        """
        super().__init__(max_dim)
        self._policy: DecompositionPolicy = make_enum(policy, DecompositionPolicy)
        self._model = self._policy.sklearn_model(n_components=max_dim, **kwargs)
        self._columns = None

    def _fit(self, original: pd.DataFrame):
        self._model.fit(original)
        self._columns = original.columns

    def _reduce(self, original: pd.DataFrame) -> np.ndarray:
        return self._model.transform(original)

    def recover(self, reduced: np.ndarray) -> pd.DataFrame:
        recovered = self._model.inverse_transform(reduced)
        return pd.DataFrame(recovered, columns=self._columns)

    @property
    def name(self) -> str:
        return f"{self._policy.name}(dim={self._max_dim})"
