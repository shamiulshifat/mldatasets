"""Argument validation functions."""

import logging
from copy import deepcopy
from typing import Any, Dict, Optional

import jsonschema
import numpy as np
import pandas as pd

from ..column import ColumnTransformer, StdColumnNormalizer
from ..dtypes import RawDType, SType, learn_raw_dtype_for_transformer
from ..utils import log_time, make_dict, make_json_compatible, make_list


__all__ = (
    "validate_format_kwargs",
    "validate_learn_kwargs",
    "validate_data_kwargs"
)


def validate_format_kwargs(data_path: str, args: Dict[str, Any]):
    """
    Check whether the arguments are valid for pandas IO.

    Parameters
    ----------
    data_path : str
        The path of the file.
    args : dict
        The arguments to pandas IO function.

    Raises
    ------
    ValueError | jsonschema.ValidationError
        If the arguments are invalid.
    """
    hashable = {
        "type": ["string", "number", "integer", "boolean"]
    }
    dtype = {
        "type": "string",
        "enum": [
            "int", "int32", "int64", "float", "float32", "float64", "bool",
            "datetime64[ns]", "timedelta64[ns]", "category", "object"
        ]
    }
    char = {
        "type": "string",
        "minLength": 1,
        "maxLength": 1
    }
    nullable_char = {
        "type": ["string", "null"],
        "minLength": 1,
        "maxLength": 1
    }
    null = {
        "type": "null"
    }
    boolean = {
        "type": "boolean"
    }
    non_neg_int = {
        "type": "integer",
        "minimum": 0
    }
    non_neg_int_list_flexible = {
        "oneOf": [
            non_neg_int,
            {
                "type": "array",
                "items": non_neg_int
            },
            null
        ]
    }
    compression = {
        "oneOf": [
            {
                "type": "string",
                "enum": ["infer", "gzip", "bz2", "zip", "xz", "zstd", "tar"]
            },
            null,
            {
                "type": "object",
                "propertyNames": {
                    "type": "string"
                }
            }
        ]
    }
    storage_options = {
        "type": ["object", "null"]
    }
    header = {
        "oneOf": [
            null,
            non_neg_int,
            {
                "type": "array",
                "items": non_neg_int
            },
        ]
    }
    dtypes = {
        "oneOf": [
            null,
            dtype,
            {
                "type": "object",
                "propertyNames": hashable,
                "additionalProperties": dtype
            }
        ]
    }
    parse_dates = {
        "oneOf": [
            boolean,
            {
                "type": "array",
                "items": hashable
            },
            {
                "type": "array",
                "items": {
                    "type": "array",
                    "items": hashable
                }
            },
            {
                "type": "object",
                "propertyNames": hashable,
                "additionalProperties": {
                    "type": "array",
                    "items": non_neg_int
                }
            }
        ]
    }
    encoding = {
        "type": ["string", "null"],
        "enum": ["utf-8", "latin1", "ISO-8859-1", "cp1252", "utf-16", "utf-32", None]
    }
    dtype_backend = {
        "type": "string",
        "enum": ["numpy_nullable", "pyarrow"]
    }
    common = {
        "dtype": dtypes,
        "true_values": {
            "type": ["array", "null"]
        },
        "false_values": {
            "type": ["array", "null"]
        },
        "skiprows": non_neg_int_list_flexible,
        "nrows": {
            "oneOf": [
                null,
                non_neg_int
            ]
        },
        "na_values": {
            "oneOf": [
                hashable,
                {
                    "type": "array",
                    "items": hashable
                },
                null,
                {
                    "type": "object",
                    "propertyNames": hashable,
                    "additionalProperties": {
                        "type": "array"
                    }
                }
            ]
        },
        "keep_default_na": boolean,
        "na_filter": boolean,
        "parse_dates": parse_dates,
        "date_format": {
            "type": ["string", "null"]
        },
        "thousands": nullable_char,
        "decimal": char,
        "comment": nullable_char,
        "skipfooter": non_neg_int,
        "storage_options": storage_options,
        "dtype_backend": dtype_backend
    }
    if data_path.endswith(".csv") or data_path.endswith(".tsv"):
        schema = {
            "type": "object",
            "properties": {
                "sep": {
                    "type": ["string", "null"]
                },
                "delimiter": {
                    "type": ["string", "null"]
                },
                "header": {
                    "oneOf": header["oneOf"] + [
                        {
                            "type": "string",
                            "enum": ["infer"]
                        }
                    ]
                },
                "names": {
                    "type": ["array", "null"],
                    "items": hashable,
                    "uniqueItems": True
                },
                "index_col": {
                    "oneOf": [
                        hashable,
                        {
                            "type": "array",
                            "items": hashable
                        },
                        null,
                        {
                            "type": "boolean",
                            "enum": [False]
                        }
                    ]
                },
                "usecols": {
                    "type": "array",
                    "items": hashable
                },
                "engine": {
                    "type": ["string", "null"],
                    "enum": ["c", "python", "pyarrow", "python-fwf", None]
                },
                "skipinitialspace": boolean,
                "skip_blank_lines": boolean,
                "infer_datetime_format": boolean,
                "keep_date_col": boolean,
                "dayfirst": boolean,
                "cache_dates": boolean,
                "iterator": boolean,
                "chunksize": {
                    "type": ["integer", "null"],
                    "minimum": 1
                },
                "compression": compression,
                "lineterminator": nullable_char,
                "quotechar": char,
                "quoting": {
                    "type": "integer",
                    "minimum": 0,
                    "maximum": 3
                },
                "doublequote": boolean,
                "escapechar": nullable_char,
                "encoding": encoding,
                "encoding_errors": {
                    "type": ["string", "null"],
                    "enum": ["strict", "replace", "ignore", "backslashreplace", "xmlcharrefreplace", None]
                },
                "dialect": {
                    "type": ["string", "null"],
                    "enum": ["excel", "excel-tab", "unix", None]
                },
                "on_bad_lines": {
                    "type": "string",
                    "enum": ["error", "warn", "skip"]
                },
                "delim_whitespace": boolean,
                "low_memory": boolean,
                "memory_map": boolean,
                "float_precision": {
                    "type": ["string", "null"],
                    "enum": ["high", "legacy", None]
                },
            },
        }
        if data_path.endswith(".tsv"):
            del schema["sep"]
            del schema["delimiter"]
            del schema["encoding"]
        schema.update(common)
    elif data_path.endswith(".pkl"):
        schema = {
            "type": "object",
            "properties": {
                "compression": compression,
                "storage_options": storage_options
            }
        }
    elif data_path.endswith(".xml"):
        schema = {
            "type": "object",
            "properties": {
                "xpath": {
                    "type": "string"
                },
                "namespaces": {
                    "type": ["object", "null"],
                    "propertyNames": {
                        "type": "string"
                    },
                    "additionalProperties": {
                        "type": "string"
                    }
                },
                "elems_only": boolean,
                "attrs_only": boolean,
                "names": {
                    "type": ["array", "null"],
                    "items": {
                        "type": "string"
                    }
                },
                "dtype": dtypes,
                "parse_dates": parse_dates,
                "encoding": encoding,
                "parser": {
                    "type": "string",
                    "enum": ["lxml", "etree"]
                },
                "stylesheet": {
                    "type": ["string", "null"]
                },
                "iterparse": {
                    "type": ["object", "null"],
                    "properties": {
                        "additionalProperties": {
                            "type": "array",
                            "items": {
                                "type": "string"
                            }
                        }
                    }
                },
                "compression": compression,
                "storage_options": storage_options,
                "dtype_backend": dtype_backend
            }
        }
    elif any(data_path.endswith(ext) for ext in [".xls", ".xlsx", ".xlsm", ".xlsb", ".xlt", ".xltx", ".xltm"]):
        schema = {
            "type": "object",
            "properties": {
                "sheet_name": {
                    "type": ["string", "integer", "null"],
                    "minimum": 0
                },
                "header": header,
                "names": {
                    "type": ["array", "null"],
                    "items": {
                        "type": "string"
                    }
                },
                "index_col": {
                    "oneOf": [
                        non_neg_int,
                        {
                            "type": "array",
                            "items": non_neg_int
                        },
                        null,
                    ]
                },
                "usecols": {
                    "oneOf": [
                        {
                            "type": "string"
                        },
                        non_neg_int,
                        null,
                        {
                            "type": "array",
                            "items": {
                                "type": "string"
                            }
                        },
                        {
                            "type": "array",
                            "items": non_neg_int
                        }
                    ]
                },
                "engine": {
                    "type": ["string", "null"],
                    "enum": ["xlrd", "openpyxl", "odf", "pyxlsb", None]
                },
                "engine_kwargs": {
                    "type": "object"
                }
            },
        }
        schema.update(common)
    else:
        raise ValueError(f"Data path {data_path}'s file type cannot be inferred.")
    args = make_json_compatible(args)
    schema["additionalProperties"] = False
    jsonschema.validate(instance=args, schema=schema)


def _validate_column_kwargs(data: pd.DataFrame, args: Dict[str, Any],
                            learning: bool = True, other_learning_args: Optional[Dict[str, Any]] = None):
    other_learning_args = make_dict(other_learning_args)
    learn_args = {
        k: v for k, v in other_learning_args.items()
        if k in ["unique_threshold", "force_min_category", "try_casting", "max_mixed_category"]
    }
    for col_name, col_args in args.items():
        col_args = deepcopy(col_args)
        col_data = data.loc[:, col_name]
        raw_dtype = col_args.get("raw_dtype")
        if not learning and raw_dtype is None:
            raise ValueError("The raw data type must be provided.")
        default_args = {}
        raw_dtype = learn_raw_dtype_for_transformer(
            data=col_data,
            raw_dtype=RawDType[raw_dtype] if raw_dtype is not None else None,
            args=default_args,
            provided_args=col_args,
            **learn_args
        )
        try_cast_type = raw_dtype if raw_dtype != RawDType.mixed else default_args.get("base_type", RawDType.numerical)
        successful = 0
        unsuccessful = 0
        for v in col_data:
            try:
                if try_cast_type == RawDType.numerical:
                    pd.to_numeric(v)
                elif try_cast_type == RawDType.datetime:
                    pd.to_datetime(v)
                elif try_cast_type == RawDType.timedelta:
                    pd.to_timedelta(v)
                successful += 1
            except Exception as e:
                unsuccessful += 1
        if try_cast_type.continuous:
            if raw_dtype != RawDType.mixed and unsuccessful > 0:
                raise e
            elif raw_dtype == RawDType.mixed:
                if unsuccessful == 0:
                    raise ValueError(f"This is a mixed type but the data is purely {try_cast_type.name}.")
                if successful == 0:
                    raise ValueError(f"This is a mixed type with base type {try_cast_type.name} but no value is "
                                     f"valid of this type provided in the data of {col_name}.")
        if "base_type" not in col_args and "base_type" in default_args:
            col_args["base_type"] = default_args["base_type"].name
        ColumnTransformer.registry[raw_dtype].validate_kwargs(col_args)
        if not learning:
            if "enforce_min" in col_args or "enforce_max" in col_args:
                raise ValueError("Enforcing minimum or maximum value should not appear in learned arguments. "
                                 "Instead, the learned min or max value will be given in the dict.")


@log_time("Validating arguments for parameter learner", "Finished validating learner arguments")
def validate_learn_kwargs(data: pd.DataFrame, args: Dict[str, Any]):
    """
    Check whether the arguments are valid to learn the arguments (to the method `learn_column_kwargs`).

    Parameters
    ----------
    data : pd.DataFrame
        The data to learn on.
    args : dict
        The arguments to the method `learn_column_kwargs`.

    Raises
    ------
    ValueError | jsonschema.ValidationError
        If the arguments are invalid.
    """
    column_schema = {
        "type": ["array", "null"],
        "items": {
            "type": "string",
            "enum": data.columns.tolist()
        },
        "uniqueItems": True
    }
    kwargs_schema = {
        "type": "object",
    }
    schema = {
        "type": "object",
        "properties": {
            "drop_columns": column_schema,
            "categorical_columns": column_schema,
            "numerical_columns": column_schema,
            "datetime_columns": column_schema,
            "timedelta_columns": column_schema,
            "mixed_columns": column_schema,
            "encoding_columns": {
                "type": "object",
                "properties": {
                    column: {
                        "type": "string",
                        "oneOf": [
                            {
                                "enum": ["country"]
                            },
                            {
                                "pattern": "\\.csv$"
                            }
                        ]
                    } for column in data.columns
                },
                "additionalProperties": False
            },
            "non_std_columns": column_schema,
            "unique_threshold": {
                "type": "number",
                "minimum": 0,
                "maximum": 1
            },
            "force_min_category": {
                "type": "integer",
                "minimum": 0
            },
            "try_casting": {
                "type": "boolean"
            },
            "max_mixed_category": {
                "type": "integer",
                "minimum": 1
            },
            "default_categorical_kwargs": kwargs_schema,
            "default_numerical_kwargs": kwargs_schema,
            "default_datetime_kwargs": kwargs_schema,
            "default_timedelta_kwargs": kwargs_schema,
            "default_mixed_kwargs": kwargs_schema,
            "default_non_std_kwargs": kwargs_schema,
            "label_threshold": {
                "type": "integer",
                "minimum": 0
            },
            "enforce_min": {
                "type": ["boolean", "null"]
            },
            "enforce_max": {
                "type": ["boolean", "null"]
            },
            "p_value_threshold": {
                "type": "number",
                "minimum": 0,
                "maximum": 1
            },
            "default_binary_norm_kwargs": kwargs_schema,
            "default_multiclass_norm_kwargs": kwargs_schema,
            "default_numerical_norm_kwargs": kwargs_schema,
            "column_kwargs": {
                "type": "object"
            }
        },
        "additionalProperties": False
    }
    jsonschema.validate(instance=args, schema=schema)
    logging.debug("Finished validating the basic schema skeleton.")

    column_groups = ["categorical", "numerical", "datetime", "timedelta", "mixed", "encoding", "non_std"]
    appeared_columns = set()
    for group in column_groups:
        for col in args.get(f"{group}_columns", []):
            if col in appeared_columns:
                raise ValueError(f"The same column named {col} is dual-typed, which is not allowed.")
            appeared_columns.add(col)
    for g, func in zip(
            ["numerical", "datetime", "timedelta"],
            [pd.to_numeric, pd.to_datetime, pd.to_timedelta]
    ):
        column_list = make_list(args.get(f"{g}_columns"))
        for c in column_list:
            if func(data.loc[:, c].dropna(), errors="coerce").isnull().sum() > 0:
                raise ValueError(f"Column \"{c}\" cannot be interpreted as {g}.")
    logging.debug("Finished validating column names and types.")

    for raw_dtype, col_class in ColumnTransformer.registry.items():
        if raw_dtype.name == "encoding":
            continue
        default_kwargs = args.get(f"default_{raw_dtype.name}_kwargs", {})
        col_class.validate_kwargs(default_kwargs)
    logging.debug("Finished validating column transformer default arguments.")

    for stype, s_class in StdColumnNormalizer.registry.items():
        if stype == SType.non_std:
            continue
        default_kwargs = args.get(f"default_{stype.name}_norm_kwargs", {})
        s_class.validate_kwargs(default_kwargs)
    logging.debug("Finished validating standard column normalizer default arguments.")

    _validate_column_kwargs(data, args.get("column_kwargs", {}))
    logging.debug("Finished validating arguments specific to each column.")


@log_time("Validating arguments for TableTransformer", "Finished validating arguments for TableTransformer")
def validate_data_kwargs(data: pd.DataFrame, args: Dict[str, Any]):
    """
    Check whether the arguments are valid to construction of TableTransformer.

    Parameters
    ----------
    data : pd.DataFrame
        The data to validate the data arguments on.
    args : dict
        The arguments to TableTransformer constructor.

    Raises
    ------
    ValueError | jsonschema.ValidationError
        If the arguments are invalid.
    """
    all_columns = {*data.columns}
    columns = all_columns - {*make_list(args.get("drop_columns"))}
    all_columns = [*all_columns]
    columns = [*columns]
    imbalance_columns = args.get("imbalance_columns", args.get("target_columns"))
    if imbalance_columns is None:
        imbalance_columns = []
    if isinstance(imbalance_columns, str):
        imbalance_columns = [imbalance_columns]
    schema = {
        "type": "object",
        "properties": {
            "drop_columns": {
                "type": ["array", "null"],
                "items": {"enum": all_columns},
                "uniqueItems": True
            },
            "dropna_columns": {
                "type": ["array", "null"],
                "items": {"enum": columns},
                "uniqueItems": True
            },
            "target_columns": {
                "oneOf": [
                    {"type": "string", "enum": columns},
                    {
                        "type": "array",
                        "items": {"enum": columns},
                        "uniqueItems": True
                    }
                ]
            },
            "column_kwargs": {
                "type": ["object", "null"],
                "properties": {
                    c: {} for c in columns
                },
                "required": columns,
                "additionalProperties": False
            },
            "important_columns": {
                "type": ["array", "null"],
                "items": {"enum": columns},
                "uniqueItems": True
            },
            "reversible_reducers": {
                "type": ["array", "null"],
                "items": {
                    "type": "array",
                    "prefixItems": [
                        {
                            "type": "string",
                            "enum": ["variance_threshold", "decomposition"]
                        },
                        {
                            "type": "integer",
                            "minimum": 1
                        },
                        {
                            "type": "object"
                        }
                    ],
                    "minItems": 3,
                    "maxItems": 3
                },
                "uniqueItems": True
            },
            "irreversible_reducers": {
                "type": ["array", "null"],
                "items": {
                    "type": "array",
                    "prefixItems": [
                        {
                            "type": "string",
                            "enum": ["lda", "manifold"]
                        },
                        {
                            "type": "integer",
                            "minimum": 1
                        },
                        {
                            "type": "object"
                        }
                    ],
                    "minItems": 3,
                    "maxItems": 3
                },
                "uniqueItems": True
            },
            "impute_columns": {
                "type": ["array", "null"],
                "items": {"enum": columns},
                "uniqueItems": True
            },
            "imputer_kwargs": {
                "type": ["object", "null"],
                "properties": {
                    "n_neighbors": {
                        "type": "integer",
                        "minimum": 1
                    },
                    "weights": {
                        "type": "string",
                        "enum": ["uniform", "distance"]
                    },
                    "metric": {
                        "type": "string",
                        "enum": ["nan_euclidean"]
                    }
                },
                "additionalProperties": False
            },
            "imbalance_columns": {
                "type": ["array", "null"],
                "items": {"enum": columns},
                "uniqueItems": True
            },
            "sampler_kwargs": {
                "type": ["object", "null"],
                "propertyNames": {
                    "enum": imbalance_columns
                },
                "required": imbalance_columns,
                "additionalProperties": False,
                "properties": {
                    "imb_algo": {
                        "type": "string",
                        "enum": [
                            "cluster_centroid", "condensed_nearest_neighbor", "edited_nearest_neighbor",
                            "repeated_edited_nearest_neighbors", "all_knn", "instance_hardness_threshold",
                            "near_miss", "neighborhood_cleaning_rule", "one_sided_selection",
                            "random_under_sampler", "tomek_links", "random_over_sampler", "smote", "smotenc",
                            "smoten", "adasyn", "borderline_smote", "kmeans_smote", "svm_smote", "smoteenn",
                            "smote_tomek"
                        ]
                    },
                    "imb_kwargs": {
                        "type": "object"
                    },
                },
                "allOf": [
                    {
                        "if": {
                            "properties": {
                                "imb_algo": {
                                    "const": "cluster_centroids"
                                }
                            }
                        },
                        "then": {
                            "properties": {
                                "imb_kwargs": {
                                    "type": "object",
                                    "properties": {
                                        "sampling_strategy": {
                                            "oneOf": [
                                                {
                                                    "type": "string",
                                                    "enum": [
                                                        "majority", "not minority", "not majority", "all", "auto"
                                                    ]
                                                },
                                                {
                                                    "type": "number",
                                                    "exclusiveMinimum": 0
                                                },
                                                {
                                                    "type": "object"
                                                }
                                            ]
                                        },
                                        "voting": {
                                            "type": "string",
                                            "enum": ["hard", "soft", "auto"]
                                        }
                                    },
                                    "additionalProperties": False
                                }
                            }
                        }
                    },
                    {
                        "if": {
                            "properties": {
                                "imb_algo": {
                                    "const": "condensed_nearest_neighbor"
                                }
                            }
                        },
                        "then": {
                            "properties": {
                                "imb_kwargs": {
                                    "type": "object",
                                    "properties": {
                                        "sampling_strategy": {
                                            "oneOf": [
                                                {
                                                    "type": "string",
                                                    "enum": [
                                                        "majority", "not minority", "not majority", "all", "auto"
                                                    ]
                                                },
                                                {
                                                    "type": "array",
                                                }
                                            ]
                                        },
                                        "n_neighbors": {
                                            "type": ["integer", "null"],
                                            "minimum": 1
                                        },
                                        "n_seeds_S": {
                                            "type": "integer",
                                            "minimum": 1
                                        },
                                    },
                                    "additionalProperties": False
                                }
                            }
                        }
                    },
                    {
                        "if": {
                            "properties": {
                                "imb_algo": {
                                    "const": "edited_nearest_neighbors"
                                }
                            }
                        },
                        "then": {
                            "properties": {
                                "imb_kwargs": {
                                    "type": "object",
                                    "properties": {
                                        "sampling_strategy": {
                                            "oneOf": [
                                                {
                                                    "type": "string",
                                                    "enum": [
                                                        "majority", "not minority", "not majority", "all", "auto"
                                                    ]
                                                },
                                                {
                                                    "type": "array",
                                                }
                                            ]
                                        },
                                        "n_neighbors": {
                                            "type": "integer",
                                            "minimum": 1
                                        },
                                        "kind_sel": {
                                            "type": "string",
                                            "enum": ["all", "mode"]
                                        },
                                    },
                                    "additionalProperties": False
                                }
                            }
                        }
                    },
                    {
                        "if": {
                            "properties": {
                                "imb_algo": {
                                    "const": "repeated_edited_nearest_neighbors"
                                }
                            }
                        },
                        "then": {
                            "properties": {
                                "imb_kwargs": {
                                    "type": "object",
                                    "properties": {
                                        "sampling_strategy": {
                                            "oneOf": [
                                                {
                                                    "type": "string",
                                                    "enum": [
                                                        "majority", "not minority", "not majority", "all", "auto"
                                                    ]
                                                },
                                                {
                                                    "type": "array",
                                                }
                                            ]
                                        },
                                        "n_neighbors": {
                                            "type": "integer",
                                            "minimum": 1
                                        },
                                        "max_iter": {
                                            "type": "integer",
                                            "minimum": 1
                                        },
                                        "kind_sel": {
                                            "type": "string",
                                            "enum": ["all", "mode"]
                                        }
                                    },
                                    "additionalProperties": False
                                }
                            }
                        }
                    },
                    {
                        "if": {
                            "properties": {
                                "imb_algo": {
                                    "const": "all_knn"
                                }
                            }
                        },
                        "then": {
                            "properties": {
                                "imb_kwargs": {
                                    "type": "object",
                                    "properties": {
                                        "sampling_strategy": {
                                            "oneOf": [
                                                {
                                                    "type": "string",
                                                    "enum": [
                                                        "majority", "not minority", "not majority", "all", "auto"
                                                    ]
                                                },
                                                {
                                                    "type": "array",
                                                }
                                            ]
                                        },
                                        "n_neighbors": {
                                            "type": "integer",
                                            "minimum": 1
                                        },
                                        "kind_sel": {
                                            "type": "string",
                                            "enum": ["all", "mode"]
                                        },
                                        "allow_minority": {
                                            "type": "boolean"
                                        }
                                    },
                                    "additionalProperties": False
                                }
                            }
                        }
                    },
                    {
                        "if": {
                            "properties": {
                                "imb_algo": {
                                    "const": "instance_hardness_threshold"
                                }
                            }
                        },
                        "then": {
                            "properties": {
                                "imb_kwargs": {
                                    "type": "object",
                                    "properties": {
                                        "sampling_strategy": {
                                            "oneOf": [
                                                {
                                                    "type": "string",
                                                    "enum": [
                                                        "majority", "not minority", "not majority", "all", "auto"
                                                    ]
                                                },
                                                {
                                                    "type": "number",
                                                    "exclusiveMinimum": 0
                                                },
                                                {
                                                    "type": "object",
                                                }
                                            ]
                                        },
                                        "cv": {
                                            "type": "integer",
                                            "minimum": 1
                                        },
                                    },
                                    "additionalProperties": False
                                }
                            }
                        }
                    },
                    {
                        "if": {
                            "properties": {
                                "imb_algo": {
                                    "const": "near_miss"
                                }
                            }
                        },
                        "then": {
                            "properties": {
                                "imb_kwargs": {
                                    "type": "object",
                                    "properties": {
                                        "sampling_strategy": {
                                            "oneOf": [
                                                {
                                                    "type": "string",
                                                    "enum": [
                                                        "majority", "not minority", "not majority", "all", "auto"
                                                    ]
                                                },
                                                {
                                                    "type": "number",
                                                    "exclusiveMinimum": 0
                                                },
                                                {
                                                    "type": "object",
                                                }
                                            ]
                                        },
                                        "n_neighbors": {
                                            "type": "integer",
                                            "minimum": 1
                                        },
                                        "n_neighbors_ver3": {
                                            "type": "integer",
                                            "minimum": 1
                                        },
                                    },
                                    "additionalProperties": False
                                }
                            }
                        }
                    },
                    {
                        "if": {
                            "properties": {
                                "imb_algo": {
                                    "const": "neighborhood_cleaning_rule"
                                }
                            }
                        },
                        "then": {
                            "properties": {
                                "imb_kwargs": {
                                    "type": "object",
                                    "properties": {
                                        "sampling_strategy": {
                                            "oneOf": [
                                                {
                                                    "type": "string",
                                                    "enum": [
                                                        "majority", "not minority", "not majority", "all", "auto"
                                                    ]
                                                },
                                                {
                                                    "type": "array",
                                                }
                                            ]
                                        },
                                        "n_neighbors": {
                                            "type": "integer",
                                            "minimum": 1
                                        },
                                        "kind_sel": {
                                            "type": "string",
                                            "enum": ["all", "mode"]
                                        },
                                        "threshold_cleaning": {
                                            "type": "number",
                                            "minimum": 0,
                                            "maximum": 1
                                        }
                                    },
                                    "additionalProperties": False
                                }
                            }
                        }
                    },
                    {
                        "if": {
                            "properties": {
                                "imb_algo": {
                                    "const": "one_sided_selection"
                                }
                            }
                        },
                        "then": {
                            "properties": {
                                "imb_kwargs": {
                                    "type": "object",
                                    "properties": {
                                        "sampling_strategy": {
                                            "oneOf": [
                                                {
                                                    "type": "string",
                                                    "enum": [
                                                        "majority", "not minority", "not majority", "all", "auto"
                                                    ]
                                                },
                                                {
                                                    "type": "array",
                                                }
                                            ]
                                        },
                                        "n_neighbors": {
                                            "type": ["integer", "null"],
                                            "minimum": 1
                                        },
                                        "n_seeds_S": {
                                            "type": "integer",
                                            "minimum": 1
                                        },
                                    },
                                    "additionalProperties": False
                                }
                            }
                        }
                    },
                    {
                        "if": {
                            "properties": {
                                "imb_algo": {
                                    "const": "random_under_sampler"
                                }
                            }
                        },
                        "then": {
                            "properties": {
                                "imb_kwargs": {
                                    "type": "object",
                                    "properties": {
                                        "sampling_strategy": {
                                            "oneOf": [
                                                {
                                                    "type": "string",
                                                    "enum": [
                                                        "majority", "not minority", "not majority", "all", "auto"
                                                    ]
                                                },
                                                {
                                                    "type": "number",
                                                    "exclusiveMinimum": 0
                                                },
                                                {
                                                    "type": "object",
                                                }
                                            ]
                                        },
                                        "replacement": {
                                            "type": "boolean",
                                        },
                                    },
                                    "additionalProperties": False
                                }
                            }
                        }
                    },
                    {
                        "if": {
                            "properties": {
                                "imb_algo": {
                                    "const": "tomek_links"
                                }
                            }
                        },
                        "then": {
                            "properties": {
                                "imb_kwargs": {
                                    "type": "object",
                                    "properties": {
                                        "sampling_strategy": {
                                            "oneOf": [
                                                {
                                                    "type": "string",
                                                    "enum": [
                                                        "majority", "not minority", "not majority", "all", "auto"
                                                    ]
                                                },
                                                {
                                                    "type": "array",
                                                }
                                            ]
                                        },
                                    },
                                    "additionalProperties": False
                                }
                            }
                        }
                    },
                    {
                        "if": {
                            "properties": {
                                "imb_algo": {
                                    "const": "random_over_sampler"
                                }
                            }
                        },
                        "then": {
                            "properties": {
                                "imb_kwargs": {
                                    "type": "object",
                                    "properties": {
                                        "sampling_strategy": {
                                            "oneOf": [
                                                {
                                                    "type": "string",
                                                    "enum": [
                                                        "majority", "not minority", "not majority", "all", "auto"
                                                    ]
                                                },
                                                {
                                                    "type": "number",
                                                    "exclusiveMinimum": 0
                                                },
                                                {
                                                    "type": "object",
                                                }
                                            ]
                                        },
                                        "shrinkage": {
                                            "oneOf": [
                                                {
                                                    "type": "null"
                                                },
                                                {
                                                    "type": "number",
                                                    "minimum": 0
                                                },
                                                {
                                                    "type": "object"
                                                }
                                            ]
                                        },
                                    },
                                    "additionalProperties": False
                                }
                            }
                        }
                    },
                    {
                        "if": {
                            "properties": {
                                "imb_algo": {
                                    "const": "smote"
                                }
                            }
                        },
                        "then": {
                            "properties": {
                                "imb_kwargs": {
                                    "type": "object",
                                    "properties": {
                                        "sampling_strategy": {
                                            "oneOf": [
                                                {
                                                    "type": "string",
                                                    "enum": [
                                                        "majority", "not minority", "not majority", "all", "auto"
                                                    ]
                                                },
                                                {
                                                    "type": "number",
                                                    "exclusiveMinimum": 0
                                                },
                                                {
                                                    "type": "object",
                                                }
                                            ]
                                        },
                                        "k_neighbors": {
                                            "type": "integer",
                                            "minimum": 1
                                        },
                                    },
                                    "additionalProperties": False
                                }
                            }
                        }
                    },
                    {
                        "if": {
                            "properties": {
                                "imb_algo": {
                                    "const": "smotenc"
                                }
                            }
                        },
                        "then": {
                            "properties": {
                                "imb_kwargs": {
                                    "type": "object",
                                    "properties": {
                                        "sampling_strategy": {
                                            "oneOf": [
                                                {
                                                    "type": "string",
                                                    "enum": [
                                                        "majority", "not minority", "not majority", "all", "auto"
                                                    ]
                                                },
                                                {
                                                    "type": "number",
                                                    "exclusiveMinimum": 0
                                                },
                                                {
                                                    "type": "object",
                                                }
                                            ]
                                        },
                                        "k_neighbors": {
                                            "type": "integer",
                                            "minimum": 1
                                        },
                                    },
                                    "categorical_features": {
                                        "oneOf": [
                                            {
                                                "type": "string",
                                                "enum": ["infer"]
                                            },
                                            {
                                                "type": "array",
                                                "oneOf": [
                                                    {"items": {"type": "number"}},
                                                    {"items": {"type": "boolean"}},
                                                    {"items": {"type": "string"}}
                                                ]

                                            }
                                        ]
                                    },
                                    "additionalProperties": False
                                }
                            }
                        }
                    },
                    {
                        "if": {
                            "properties": {
                                "imb_algo": {
                                    "const": "smoten"
                                }
                            }
                        },
                        "then": {
                            "properties": {
                                "imb_kwargs": {
                                    "type": "object",
                                    "properties": {
                                        "sampling_strategy": {
                                            "oneOf": [
                                                {
                                                    "type": "string",
                                                    "enum": [
                                                        "majority", "not minority", "not majority", "all", "auto"
                                                    ]
                                                },
                                                {
                                                    "type": "number",
                                                    "exclusiveMinimum": 0
                                                },
                                                {
                                                    "type": "object",
                                                }
                                            ]
                                        },
                                        "k_neighbors": {
                                            "type": "integer",
                                            "minimum": 1
                                        },
                                    },
                                    "additionalProperties": False
                                }
                            }
                        }
                    },
                    {
                        "if": {
                            "properties": {
                                "imb_algo": {
                                    "const": "adasyn"
                                }
                            }
                        },
                        "then": {
                            "properties": {
                                "imb_kwargs": {
                                    "type": "object",
                                    "properties": {
                                        "sampling_strategy": {
                                            "oneOf": [
                                                {
                                                    "type": "string",
                                                    "enum": [
                                                        "majority", "not minority", "not majority", "all", "auto"
                                                    ]
                                                },
                                                {
                                                    "type": "number",
                                                    "exclusiveMinimum": 0
                                                },
                                                {
                                                    "type": "object",
                                                }
                                            ]
                                        },
                                        "n_neighbors": {
                                            "type": "integer",
                                            "minimum": 1
                                        },
                                    },
                                    "additionalProperties": False
                                }
                            }
                        }
                    },
                    {
                        "if": {
                            "properties": {
                                "imb_algo": {
                                    "const": "borderline_smote"
                                }
                            }
                        },
                        "then": {
                            "properties": {
                                "imb_kwargs": {
                                    "type": "object",
                                    "properties": {
                                        "sampling_strategy": {
                                            "oneOf": [
                                                {
                                                    "type": "string",
                                                    "enum": [
                                                        "majority", "not minority", "not majority", "all", "auto"
                                                    ]
                                                },
                                                {
                                                    "type": "number",
                                                    "exclusiveMinimum": 0
                                                },
                                                {
                                                    "type": "object",
                                                }
                                            ]
                                        },
                                        "k_neighbors": {
                                            "type": "integer",
                                            "minimum": 1
                                        },
                                        "m_neighbors": {
                                            "type": "integer",
                                            "minimum": 1
                                        },
                                        "kind": {
                                            "type": "string",
                                            "enum": ["borderline-1", "borderline-2"]
                                        }
                                    },
                                    "additionalProperties": False
                                }
                            }
                        }
                    },
                    {
                        "if": {
                            "properties": {
                                "imb_algo": {
                                    "const": "kmeans_smote"
                                }
                            }
                        },
                        "then": {
                            "properties": {
                                "imb_kwargs": {
                                    "type": "object",
                                    "properties": {
                                        "sampling_strategy": {
                                            "oneOf": [
                                                {
                                                    "type": "string",
                                                    "enum": [
                                                        "majority", "not minority", "not majority", "all", "auto"
                                                    ]
                                                },
                                                {
                                                    "type": "number",
                                                    "exclusiveMinimum": 0
                                                },
                                                {
                                                    "type": "object",
                                                }
                                            ]
                                        },
                                        "k_neighbors": {
                                            "type": "integer",
                                            "minimum": 1
                                        },
                                        "kmeans_estimator": {
                                            "type": ["integer", "null"],
                                            "minimum": 1
                                        },
                                        "cluster_balance_threshold": {
                                            "oneOf": [
                                                {
                                                    "type": "string",
                                                    "enum": ["auto"]
                                                },
                                                {
                                                    "type": "number",
                                                    "minimum": 0,
                                                    "maximum": 1
                                                }
                                            ]
                                        },
                                        "density_exponent": {
                                            "oneOf": [
                                                {
                                                    "type": "string",
                                                    "enum": ["auto"]
                                                },
                                                {
                                                    "type": "number",
                                                    "exclusiveMinimum": 0,
                                                }
                                            ]
                                        }
                                    },
                                    "additionalProperties": False
                                }
                            }
                        }
                    },
                    {
                        "if": {
                            "properties": {
                                "imb_algo": {
                                    "const": "svm_smote"
                                }
                            }
                        },
                        "then": {
                            "properties": {
                                "imb_kwargs": {
                                    "type": "object",
                                    "properties": {
                                        "sampling_strategy": {
                                            "oneOf": [
                                                {
                                                    "type": "string",
                                                    "enum": [
                                                        "majority", "not minority", "not majority", "all", "auto"
                                                    ]
                                                },
                                                {
                                                    "type": "number",
                                                    "exclusiveMinimum": 0
                                                },
                                                {
                                                    "type": "object",
                                                }
                                            ]
                                        },
                                        "k_neighbors": {
                                            "type": "integer",
                                            "minimum": 1
                                        },
                                        "m_neighbors": {
                                            "type": "integer",
                                            "minimum": 1
                                        },
                                        "out_step": {
                                            "type": "number",
                                            "exclusiveMinimum": 0
                                        }
                                    },
                                    "additionalProperties": False
                                }
                            }
                        }
                    },
                    {
                        "if": {
                            "properties": {
                                "imb_algo": {
                                    "const": "smoteenn"
                                }
                            }
                        },
                        "then": {
                            "properties": {
                                "imb_kwargs": {
                                    "type": "object",
                                    "properties": {
                                        "sampling_strategy": {
                                            "oneOf": [
                                                {
                                                    "type": "string",
                                                    "enum": [
                                                        "majority", "not minority", "not majority", "all", "auto"
                                                    ]
                                                },
                                                {
                                                    "type": "number",
                                                    "exclusiveMinimum": 0
                                                },
                                                {
                                                    "type": "object",
                                                }
                                            ]
                                        },
                                    },
                                    "additionalProperties": False
                                }
                            }
                        }
                    },
                    {
                        "if": {
                            "properties": {
                                "imb_algo": {
                                    "const": "smote_tomek"
                                }
                            }
                        },
                        "then": {
                            "properties": {
                                "imb_kwargs": {
                                    "type": "object",
                                    "properties": {
                                        "sampling_strategy": {
                                            "oneOf": [
                                                {
                                                    "type": "string",
                                                    "enum": [
                                                        "majority", "not minority", "not majority", "all", "auto"
                                                    ]
                                                },
                                                {
                                                    "type": "number",
                                                    "exclusiveMinimum": 0
                                                },
                                                {
                                                    "type": "object",
                                                }
                                            ]
                                        },
                                    },
                                    "additionalProperties": False
                                }
                            }
                        }
                    },
                ],
            }
        },
        "additionalProperties": False
    }
    args = make_json_compatible(args)
    jsonschema.validate(instance=args, schema=schema)

    column_kwargs = args.get("column_kwargs", {})
    _validate_column_kwargs(data, column_kwargs, learning=False)

    reducers = args.get("reversible_reducers", []) + args.get("irreversible_reducers", [])
    max_dim = np.inf
    reducer_schema = {
        "variance_threshold": {
            "type": "object",
            "properties": {
                "threshold": {
                    "type": "number",
                    "minimum": 0
                }
            },
            "additionalProperties": False
        },
        "decomposition": {
            "type": "object",
            "properties": {
                "policy": {
                    "type": "string",
                    "enum": ["PCA", "KPCA", "IPCA", "SPCA", "MBSPCA", "SVD"]
                }
            },
            "allOf": [
                {
                    "if": {
                        "properties": {
                            "policy": {
                                "const": "PCA"
                            }
                        }
                    },
                    "then": {
                        "properties": {
                            "whiten": {
                                "type": "boolean"
                            },
                            "svd_solver": {
                                "type": "string",
                                "enum": ["auto", "full", "arpack", "randomized"]
                            },
                            "tol": {
                                "type": "number",
                                "minimum": 0
                            },
                            "iterated_power": {
                                "oneOf": [
                                    {
                                        "type": "string",
                                        "enum": ["auto"]
                                    },
                                    {
                                        "type": "integer",
                                        "minimum": 1
                                    }
                                ]
                            },
                            "n_oversamples": {
                                "type": "string",
                                "minimum": 1
                            },
                            "over_iteration_normalizer": {
                                "type": "string",
                                "enum": ["auto", "QR", "LU", "none"]
                            }
                        }
                    }
                },
                {
                    "if": {
                        "properties": {
                            "policy": {
                                "const": "KPCA"
                            }
                        }
                    },
                    "then": {
                        "properties": {
                            "kernel": {
                                "type": "string",
                                "enum": ["linear", "poly", "rbf", "sigmoid", "cosine", "precomputed"]
                            },
                            "degree": {
                                "type": "integer",
                                "minimum": 0
                            },
                            "gamma": {
                                "type": ["number", "null"]
                            },
                            "coef0": {
                                "type": "number"
                            },
                            "alpha": {
                                "type": "number"
                            },
                            "fit_inverse_transform": {
                                "type": "boolean"
                            },
                            "eigen_solver": {
                                "type": "string",
                                "enum": ["auto", "dense", "arpack", "randomized"]
                            },
                            "tol": {
                                "type": "number",
                                "minimum": 0
                            },
                            "max_iter": {
                                "type": ["integer", "null"],
                                "minimum": 1
                            },
                            "iterated_power": {
                                "oneOf": [
                                    {
                                        "type": "string",
                                        "enum": ["auto"]
                                    },
                                    {
                                        "type": "string",
                                        "minimum": 0
                                    }
                                ]
                            },
                            "remove_zero_eig": {
                                "type": "boolean"
                            },
                        }
                    }
                },
                {
                    "if": {
                        "properties": {
                            "policy": {
                                "const": "IPCA"
                            }
                        }
                    },
                    "then": {
                        "properties": {
                            "whiten": {
                                "type": "boolean"
                            },
                            "batch_size": {
                                "type": ["integer", "null"],
                                "minimum": 1
                            }
                        }
                    }
                },
                {
                    "if": {
                        "properties": {
                            "policy": {
                                "const": "SPCA"
                            }
                        }
                    },
                    "then": {
                        "properties": {
                            "alpha": {
                                "type": "number",
                                "minimum": 0
                            },
                            "ridge_alpha": {
                                "type": "number"
                            },
                            "max_iter": {
                                "type": "integer",
                                "minimum": 1
                            },
                            "tol": {
                                "type": "number",
                                "exclusiveMinimum": 0
                            },
                            "method": {
                                "type": "string",
                                "enum": ["lars", "cd"]
                            },
                        }
                    }
                },
                {
                    "if": {
                        "properties": {
                            "policy": {
                                "const": "MBSPCA"
                            }
                        }
                    },
                    "then": {
                        "properties": {
                            "alpha": {
                                "type": "number",
                                "minimum": 0
                            },
                            "ridge_alpha": {
                                "type": "number"
                            },
                            "n_iter": {
                                "type": "integer",
                                "minimum": 1
                            },
                            "max_iter": {
                                "type": "integer",
                                "minimum": 1
                            },
                            "batch_size": {
                                "type": "integer",
                                "minimum": 1
                            },
                            "shuffle": {
                                "type": "boolean"
                            },
                            "tol": {
                                "type": "number",
                                "exclusiveMinimum": 0
                            },
                            "method": {
                                "type": "string",
                                "enum": ["lars", "cd"]
                            },
                            "max_no_improvement": {
                                "type": ["integer", "null"],
                                "minimum": 10
                            }
                        }
                    }
                },
                {
                    "if": {
                        "properties": {
                            "policy": {
                                "const": "SVD"
                            }
                        }
                    },
                    "then": {
                        "properties": {
                            "algorithm": {
                                "type": "string",
                                "enum": ["arpack", "randomized"]
                            },
                            "n_iter": {
                                "type": "integer",
                                "minimum": 1
                            },
                            "n_oversamples": {
                                "type": "integer",
                                "minimum": 1
                            },
                            "power_iteration_normalizer": {
                                "type": "string",
                                "enum": ["auto", "QR", "LU", "none"]
                            },
                            "tol": {
                                "type": "number",
                                "minimum": 0
                            }
                        }
                    }
                }
            ],
        },
        "lda": {
            "type": "object",
            "properties": {
                "solver": {
                    "type": "string",
                    "enum": ["svd", "lsqr", "eigen"]
                },
                "shrinkage": {
                    "oneOf": [
                        {
                            "type": "string",
                            "enum": ["auto"]
                        },
                        {
                            "type": "number"
                        },
                        {
                            "type": "null"
                        }
                    ]
                },
                "priors": {
                    "oneOf": [
                        {
                            "type": "array",
                            "items": {
                                "type": "number"
                            }
                        },
                        {
                            "type": "null"
                        }
                    ]
                },
                "store_covariance": {
                    "type": "boolean"
                },
                "tol": {
                    "type": "number",
                    "exclusiveMinimum": 0
                },
            },
            "additionalProperties": False
        },
        "manifold": {
            "type": "object",
            "properties": {
                "policy": {
                    "type": "string",
                    "enum": ["ISO", "LLE"]
                }
            },
            "allOf": [
                {
                    "if": {
                        "properties": {
                            "policy": {
                                "const": "ISO"
                            }
                        }
                    },
                    "then": {
                        "properties": {
                            "n_neighbors": {
                                "type": "integer",
                                "minimum": 1
                            },
                            "eigen_solver": {
                                "type": "string",
                                "enum": ["auto", "arpack", "dense"]
                            },
                            "tol": {
                                "type": "number",
                                "minimum": 0
                            },
                            "max_iter": {
                                "type": ["integer", "null"],
                                "minimum": 1
                            },
                            "path_method": {
                                "type": "string",
                                "enum": ["auto", "FW", "D"]
                            },
                            "neighbors_algorithm": {
                                "type": "string",
                                "enum": ["auto", "ball_tree", "kd_tree", "brute"]
                            }
                        },
                    }
                },
                {
                    "if": {
                        "properties": {
                            "policy": {
                                "const": "LLE"
                            }
                        }
                    },
                    "then": {
                        "properties": {
                            "n_neighbors": {
                                "type": "integer",
                                "minimum": 1
                            },
                            "reg": {
                                "type": "number",
                                "minimum": 0
                            },
                            "eigen_solver": {
                                "type": "string",
                                "enum": ["auto", "arpack", "dense"]
                            },
                            "tol": {
                                "type": "number",
                                "minimum": 0
                            },
                            "max_iter": {
                                "type": "integer",
                                "minimum": 1
                            },
                            "method": {
                                "type": "string",
                                "enum": ["standard", "hessian", "modified", "ltsa"]
                            },
                            "hessian_tol": {
                                "type": "number",
                                "minimum": 0
                            },
                            "modified_tol": {
                                "type": "number",
                                "minimum": 0
                            },
                            "neighbors_algorithm": {
                                "type": "string",
                                "enum": ["auto", "ball_tree", "kd_tree", "brute"]
                            },
                        },
                    }
                }
            ],
            "additionalProperties": False
        }
    }
    for rd_type, dim, rd_kwargs in reducers:
        if dim > max_dim:
            raise ValueError("We cannot reduce the number of dimensions from a smaller dimension to a larger "
                             "dimension.")
        max_dim = dim
        jsonschema.validate(instance=rd_kwargs, schema=reducer_schema[rd_type])
