"""
Samplers that apply sampling algorithms.
They are based in [`imblearn`](https://imbalanced-learn.org/stable/over_sampling.html).
We currently accept methods in over-/under-sampling or combination of both.
"""

import enum
import math
from typing import Any, Dict, Optional, Tuple, Type, Union

import numpy as np
import pandas as pd
from imblearn.combine import SMOTEENN, SMOTETomek
from imblearn.over_sampling import ADASYN, BorderlineSMOTE, KMeansSMOTE, SVMSMOTE, RandomOverSampler, SMOTE, SMOTEN, \
    SMOTENC
from imblearn.under_sampling import AllKNN, ClusterCentroids, CondensedNearestNeighbour, EditedNearestNeighbours, \
    InstanceHardnessThreshold, NearMiss, NeighbourhoodCleaningRule, OneSidedSelection, RandomUnderSampler, \
    RepeatedEditedNearestNeighbours, TomekLinks
from imblearn.base import BaseSampler

from ...utils import make_dict, make_enum, _GlobalVariableInEnum


class BalancerAlgo(enum.Enum):
    """Sampling algorithms."""

    cluster_centroids = enum.auto()
    condensed_nearest_neighbor = enum.auto()
    edited_nearest_neighbors = enum.auto()
    repeated_edited_nearest_neighbors = enum.auto()
    all_knn = enum.auto()
    instance_hardness_threshold = enum.auto()
    near_miss = enum.auto()
    neighborhood_cleaning_rule = enum.auto()
    one_sided_selection = enum.auto()
    random_under_sampler = enum.auto()
    tomek_links = enum.auto()
    random_over_sampler = enum.auto()
    smote = enum.auto()
    smotenc = enum.auto()
    smoten = enum.auto()
    adasyn = enum.auto()
    borderline_smote = enum.auto()
    kmeans_smote = enum.auto()
    svm_smote = enum.auto()
    smoteenn = enum.auto()
    smote_tomek = enum.auto()

    _samplers: Dict["BalancerAlgo", Type[BaseSampler]] = _GlobalVariableInEnum({
        cluster_centroids: ClusterCentroids,
        condensed_nearest_neighbor: CondensedNearestNeighbour,
        edited_nearest_neighbors: EditedNearestNeighbours,
        repeated_edited_nearest_neighbors: RepeatedEditedNearestNeighbours,
        all_knn: AllKNN,
        instance_hardness_threshold: InstanceHardnessThreshold,
        near_miss: NearMiss,
        neighborhood_cleaning_rule: NeighbourhoodCleaningRule,
        one_sided_selection: OneSidedSelection,
        random_under_sampler: RandomUnderSampler,
        tomek_links: TomekLinks,
        random_over_sampler: RandomOverSampler,
        smote: SMOTE,
        smotenc: SMOTENC,
        smoten: SMOTEN,
        adasyn: ADASYN,
        borderline_smote: BorderlineSMOTE,
        kmeans_smote: KMeansSMOTE,
        svm_smote: SVMSMOTE,
        smoteenn: SMOTEENN,
        smote_tomek: SMOTETomek
    })

    @property
    def imbalance_sampler(self) -> Type[BaseSampler]:
        """The imbalance sampler."""
        try:
            return BalancerAlgo._samplers[self]
        except KeyError:
            return BalancerAlgo._samplers[self.value]

    @property
    def is_undersample(self) -> bool:
        """Whether this algorithm is undersampling method."""
        return self.value <= self.tomek_links.value

    @property
    def is_oversample(self) -> bool:
        """Whether this algorithm is oversampling method."""
        return self.tomek_links.value < self.value <= self.svm_smote.value

    @property
    def is_combined(self) -> bool:
        """Whether this algorithm is a combination of uner-and-oversampling method."""
        return self == self.smote_tomek or self == self.smoteenn


class Sampler:
    """A class that samples imbalance data in a balanced way."""
    def __init__(self,
                 imb_algo: Union[str, BalancerAlgo] = BalancerAlgo.smote,
                 imb_kwargs: Optional[Dict[str, Any]] = None):
        """
        Initialize a sampler instance.

        Parameters
        ----------
        imb_algo : BalancerAlgo, optional
            The imbalance handler algorithm type. Default is SMOTE.
        imb_kwargs : dict, optional
            The arguments to the sampler.
        """
        self.imb_algo: BalancerAlgo = make_enum(imb_algo, BalancerAlgo)
        imb_kwargs = make_dict(imb_kwargs)
        self.sampler: BaseSampler = imb_algo.imbalance_sampler(**imb_kwargs)

    def sample(self, data: pd.DataFrame, target: pd.Series) -> Tuple[pd.DataFrame, pd.Series]:
        """
        Sample the original data to reduce imbalance problem.

        Parameters
        ----------
        data : pd.DataFrame
            The data to sample from. It should be normalized (only numerical).
        target : pd.Series
            The target data. Should be the result of standardization.

        Returns
        -------
        pd.DataFrame
            The resampled features data.
        pd.Series
            The resampled target.
        """
        columns = data.columns
        name = target.name
        params = self.sampler.get_params()
        folds = 1
        if "k_neighbors" in params or "n_neighbors" in params:
            neighbors = params.get("k_neighbors", params.get("n_neighbors"))
            folds = math.ceil(neighbors / target.value_counts().min())
        data = pd.concat([data for _ in range(folds)])
        target = pd.concat([target for _ in range(folds)])
        data, target = self.sampler.fit_resample(data, target)
        data = pd.DataFrame(target, columns=columns)
        target = pd.Series(target, name=name)
        if folds > 1:
            selected_indices = np.random.choice(data.index, size=round(len(data) / folds), replace=False)
            data = data.iloc[selected_indices].reset_index(drop=True)
            target = target.iloc[selected_indices].reset_index(drop=True)
        return data, target
