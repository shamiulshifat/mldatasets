"""Learners that learn data types from input data."""

import logging
from typing import Any, Dict, List, Optional, Tuple, Union

import numpy as np
import pandas as pd

from .dtypes import ColumnName, RawDType
from ..utils import log, log_time, make_dict, make_enum, make_list

__all__ = ("learn_raw_dtype_for_transformer", "learn_raw_dtype_for_textualizer", "learn_forced_dtypes")


@log_time("Learning the raw data type of column", "Inferred raw data type of column",
          start_level=log.TRACE_LEVEL, end_level=logging.DEBUG, with_name=True)
def learn_raw_dtype_for_transformer(data: pd.Series,
                                    raw_dtype: Optional[RawDType] = None,
                                    unique_threshold: float = .95,
                                    force_min_category: int = 3,
                                    try_casting: bool = True,
                                    max_mixed_category: int = 5,
                                    args: Optional[Dict[str, Any]] = None,
                                    provided_args: Optional[Dict[str, Any]] = None) -> RawDType:
    """
    Learn the raw data type from the data given for transformation.

    Parameters
    ----------
    data : pd.Series
        The raw data in Series.
    raw_dtype : RawDType, optional
        If provided, this value will be used.
        Otherwise, we will learn a type.
    unique_threshold : float, optional
        From this argument on, we learn the data types for the columns not mentioned above.
        After removing N/A values in the column, if the number of unique non-continuous values divided by the
        number of rows hit this threshold, this column will be treated as non-standard. Default is 0.95.
    force_min_category : int, optional
        If the number of unique non-N/A values does not exceed this number, we will treat this column as categorical
        regardless of the data type. Default is 3.
    try_casting : bool, optional
        Sometimes the data provided is in `object` data type, but all content can be converted to some other data
        type (e.g. numerical, datetime), so learning from dtype of input DataFrame might be insufficient.
        By setting this argument on, we will try to do casting for all values.
        If succeeded for all items in the column except for N/As, we will use this succeeded data type.
        It also allows detection of mixed types.
        Default is True.
    max_mixed_category : int, optional
        If some value casting is successful but some are not, this column may be of mixed type.
        This value specifies how many failures (in terms of unique value) are allowed for this column to be a mixed
        type. Default is 5.
    args : dict, optional
        Default args obtained so far. This is mainly used for mixed types base-type inference.
    provided_args : dict, optional
        Arguments that are to be forced on this column dataset.
        This is mainly used for mixed types base-type inference.

    Returns
    -------
    RawDType
        The learned data type.
    """
    args = make_dict(args)
    provided_args = make_dict(provided_args)
    if raw_dtype is None:
        dtype, mixed = _learn_column_type(
            column=data,
            force_min_category=force_min_category,
            unique_threshold=unique_threshold,
            try_casting=try_casting,
            max_mixed_category=max_mixed_category
        )
        if mixed:
            raw_dtype = RawDType.mixed
            args["base_type"] = dtype
        else:
            raw_dtype = dtype
    elif raw_dtype == RawDType.mixed:
        if "base_type" not in provided_args:
            base_type, _ = _learn_column_type(
                column=data,
                force_min_category=np.inf,
                unique_threshold=np.inf,
                try_casting=True,
                max_mixed_category=np.inf
            )
            args["base_type"] = base_type
    return raw_dtype


def _learn_column_type(column: pd.Series,
                       force_min_category: int = 3,
                       unique_threshold: float = .95,
                       try_casting: bool = True,
                       max_mixed_category: int = 5,) -> Tuple[RawDType, bool]:
    notna_numbers = column.notna().sum()
    if notna_numbers == 0:
        return RawDType.categorical, False
    nunique = column.nunique()
    if nunique <= force_min_category:
        return RawDType.categorical, False
    dtype = str(column.dtype)
    if RawDType.numerical.is_valid_dtype(dtype):
        return RawDType.numerical, False
    if RawDType.datetime.is_valid_dtype(dtype):
        return RawDType.datetime, False
    if RawDType.timedelta.is_valid_dtype(dtype):
        return RawDType.timedelta, False
    if nunique / notna_numbers >= unique_threshold:
        return RawDType.non_std, False

    column = column.dropna().drop_duplicates()
    if try_casting:
        for raw_dtype in [RawDType.numerical, RawDType.datetime, RawDType.timedelta]:
            unsuccessful = 0
            successful = 0
            can_mix = True
            for v in column:
                try:
                    raw_dtype.cast(v)
                    successful += 1
                except Exception as e:
                    unsuccessful += 1
                    if unsuccessful > max_mixed_category:
                        can_mix = False
                        break
            if unsuccessful == 0:
                return raw_dtype, False
            if successful > 0 and can_mix:
                return raw_dtype, True
    return RawDType.categorical, False


@log_time("Learning the raw data type for textualizer of column", "Inferred raw data type of column",
          start_level=log.TRACE_LEVEL, end_level=logging.DEBUG, with_name=True)
def learn_raw_dtype_for_textualizer(data: pd.Series,
                                    raw_dtype: Optional[Union[str, RawDType]] = None,
                                    unique_threshold: float = .95,
                                    encoding_threshold: int = 200) -> RawDType:
    """
    Learn the raw data type of the column for textualization.

    Parameters
    ----------
    data : pd.Series
        The column data.
    raw_dtype : RawDType, optional
        The known raw dtype. If not provided, we will learn.
    unique_threshold : float
        After removing N/A values in the column, if the number of unique non-continuous values divided by the
        number of rows hit this threshold, this column will be treated as non-standard. Default is 0.95.
    encoding_threshold : int
        If the number of different categories (besides N/A) is greater or equal to this value,
        and we do not hit the unique threshold above, we will treat it as encoding. Default is 200.

    Returns
    -------
    RawDType
        The learned raw data type.
    """
    if raw_dtype is not None:
        return make_enum(raw_dtype, RawDType)
    else:
        dtype = str(data.dtype)
        if RawDType.numerical.is_valid_dtype(dtype):
            return RawDType.numerical
        if RawDType.datetime.is_valid_dtype(dtype):
            return RawDType.datetime
        if RawDType.timedelta.is_valid_dtype(dtype):
            return RawDType.timedelta
        num_items = pd.to_numeric(data, errors="coerce").notnull()
        dat_data = data.copy()
        dat_data[num_items] = np.nan
        dat_items = pd.to_datetime(dat_data, errors="coerce").notnull()
        tdel_data = dat_data.copy()
        tdel_data[dat_items] = np.nan
        tdel_items = pd.to_timedelta(tdel_data, errors="coerce").notnull()

        num_cnt = num_items.sum()
        dat_cnt = dat_items.sum()
        tdel_cnt = tdel_items.sum()
        cat_cnt = len(data) - num_cnt - dat_cnt - tdel_cnt - data.isnull().sum()
        if num_cnt > 0:
            if dat_cnt > 0 or tdel_cnt > 0 or cat_cnt > 0:
                return RawDType.mixed
            else:
                return RawDType.numerical
        elif dat_cnt > 0:
            if tdel_cnt > 0 or cat_cnt > 0:
                return RawDType.mixed
            else:
                return RawDType.datetime
        elif tdel_cnt > 0:
            if cat_cnt > 0:
                return RawDType.mixed
            else:
                return RawDType.timedelta
        else:
            nunique = data.nunique(dropna=True)
            if nunique > unique_threshold * len(data):
                return RawDType.non_std
            elif nunique >= encoding_threshold:
                return RawDType.encoding
            else:
                return RawDType.categorical


def learn_forced_dtypes(categorical_columns: Optional[List[ColumnName]] = None,
                        numerical_columns: Optional[List[ColumnName]] = None,
                        datetime_columns: Optional[List[ColumnName]] = None,
                        timedelta_columns: Optional[List[ColumnName]] = None,
                        mixed_columns: Optional[List[ColumnName]] = None,
                        encoding_columns: Optional[List[ColumnName]] = None,
                        non_std_columns: Optional[List[ColumnName]] = None,) -> Dict[ColumnName, RawDType]:
    """
    Learn dtypes that are forced by given lists per type.

    Parameters
    ----------
    categorical_columns : list[str], optional
        Names of categorical columns. This list need not be comprehensive.
        From this parameter to `non_std_columns`, the sets should be mutually exclusive.
        Columns not mentioned in this six arguments will learn the data type.
    numerical_columns : list[str], optional
        Names of numerical columns. This list need not be comprehensive.
    datetime_columns : list[str], optional
        Names of datetime columns. This list need not be comprehensive.
    timedelta_columns : list[str], optional
        Names of timedelta columns. This list need not be comprehensive.
    mixed_columns : list[str], optional
        Names of columns mixing either numerical, datetime, or timedelta (exactly one of them)
        with some special strings (each recognized as a category). This list need not be comprehensive.
    encoding_columns : dict[str, str], optional
        Columns that has some encodings describing its information and can be matched back by nearest neighbors.
        Such columns include countries, cities, companies, etc.
        This is a dict matching the column name to the information of encoding (which is a .csv file or a
        pre-defined encoding type).
    non_std_columns : list[str], optional
        Non-standard column names. Columns cannot be grouped into the above five types.
        For example, ID, name, email, etc.

    Returns
    -------
    dict
        The column-to-datatype dict for the foreced data types.
    """
    forced_dtypes = {}
    for dtype, col_list in zip(
            [RawDType.categorical, RawDType.numerical, RawDType.datetime, RawDType.timedelta,
             RawDType.mixed, RawDType.encoding, RawDType.non_std],
            [categorical_columns, numerical_columns, datetime_columns, timedelta_columns,
             mixed_columns, encoding_columns, non_std_columns]
    ):
        for col in make_list(col_list):
            forced_dtypes[col] = dtype
    return forced_dtypes
