"""Sampler to do training-by-sampling for CTGAN."""

import math
from typing import Iterator, Optional

import numpy as np
from torch.utils.data import DistributedSampler, Sampler

from .collator import TableCollator
from .dataset import PandasDataset
from ..dtypes import SType
from ..table import TableTransformer


def _learn_sampler(dataset: PandasDataset,
                   transformer: TableTransformer,
                   smoothing: float,
                   binary_frequency: float):
    span1, span2 = transformer.normalized_span_info
    span_info = span1 + span2

    discrete_st = []
    discrete_ed = []
    discrete_binary = []
    frequency = []
    cat_row_idx = []
    n_discrete = 0
    st = 0
    for width, stype in span_info:
        if stype == SType.non_std or stype == SType.numerical:
            st += width
        discrete_st.append(st)
        discrete_ed.append(st + width)
        if stype == SType.binary:
            if width != 1:
                raise RuntimeError("The span information for a binary cannot be width other than 1.")
            discrete_binary.append(True)
            n_class = 2
        else:
            discrete_binary.append(False)
            n_class = width
        frequency.append(np.zeros(n_class))
        st += width
        n_discrete += 1
        cat_row_idx.append([
            [] for _ in range(n_class)
        ])
    collator = TableCollator(transformer)
    for i in range(len(dataset)):
        normalized = collator.collate([dataset[i]]).numpy()[0]
        for di in range(n_discrete):
            st = discrete_st[di]
            ed = discrete_ed[di]
            if discrete_binary[di]:
                cat = normalized[st]
            else:
                cat = normalized[st:ed].argmax()
            frequency[di][cat] += 1
            cat_row_idx[di][cat].append(i)
    for di in range(n_discrete):
        frequency[di] = np.log(frequency[di] + smoothing)
        frequency[di] = frequency[di] / frequency[di].sum()
    discrete_frequency = [
        binary_frequency if x else 1 for x in discrete_binary
    ]
    discrete_frequency = np.array(discrete_frequency)
    return frequency, cat_row_idx, n_discrete, discrete_frequency


class ImbalanceSampler(Sampler[int]):
    """A sampler that does the training-by-sampling from CTGAN."""

    def __init__(self,
                 data_source: PandasDataset,
                 transformer: TableTransformer,
                 smoothing: float = 1,
                 binary_frequency: float = .3):
        """
        Initialize an imbalance sampler by log frequency sampling.

        Parameters
        ----------
        data_source : PandasDataset
            The dataset to sample on.
        transformer : TableTransformer
            The table transformer to normalize data.
        smoothing : float, optional
            The smooth value to add to the frequencies before log is applied. Default is 1.
        binary_frequency : float, optional
            There may be a large percentage of binary single normalized input data as isna indicator.
            We may give them a smaller frequency of being selected as the discrete standardized column to sample.
        """
        super().__init__(data_source)
        self._length = len(data_source)

        self._frequency, self._cat_row_idx, self._n_discrete, self._discrete_frequency = \
            _learn_sampler(data_source, transformer, smoothing, binary_frequency)

    def __iter__(self) -> Iterator[int]:
        for _ in range(self._length):
            di = np.random.choice(range(self._n_discrete), p=self._discrete_frequency)
            frequency = self._frequency[di]
            cat = np.random.choice(range(len(frequency)), p=frequency)
            yield np.random.choice(self._cat_row_idx[di][cat])


class DistributedImbalanceSampler(DistributedSampler[int]):
    """An ImbalanceSampler in distributed environment."""
    def __init__(self,
                 dataset: PandasDataset,
                 transformer: TableTransformer,
                 smoothing: float,
                 binary_frequency: float,
                 num_replicas: Optional[int] = None,
                 rank: Optional[int] = None,
                 seed: int = 0,
                 drop_last: bool = False):
        """
        Initialize a DistributedImbalanceSampler.
        All arguments come from either ImbalanceSampler or DistributedSampler.
        """
        super().__init__(
            dataset=dataset,
            num_replicas=num_replicas,
            rank=rank,
            seed=seed,
            drop_last=drop_last
        )
        self._sampler = ImbalanceSampler(
            data_source=dataset,
            transformer=transformer,
            smoothing=smoothing,
            binary_frequency=binary_frequency
        )

    def __iter__(self) -> Iterator[int]:
        indices = [*self._sampler]
        if not self.drop_last:
            # add extra samples to make it evenly divisible
            padding_size = self.total_size - len(indices)
            if padding_size <= len(indices):
                indices += indices[:padding_size]
            else:
                indices += (indices * math.ceil(padding_size / len(indices)))[:padding_size]
        else:
            # remove tail of data to make it evenly divisible.
            indices = indices[:self.total_size]
        assert len(indices) == self.total_size

        # subsample
        indices = indices[self.rank:self.total_size:self.num_replicas]
        assert len(indices) == self.num_samples

        return iter(indices)

