"""Collate function for data loader."""

from typing import List, Tuple, Union

import pandas as pd
import torch

from ..table import TableTransformer


class TableCollator:
    """A class that collates list of rows to tensor for PyTorch training, a table transformer"""
    def __init__(self,
                 transformer: TableTransformer):
        """
        Initialize a TableCollator for the collate function.

        Parameters
        ----------
        transformer : TableTransformer
            The fitted table transform.
        """
        self.transformer = transformer

    def collate(self, batch: List[pd.Series]) -> Union[torch.Tensor, Tuple[torch.Tensor, ...]]:
        """The `collate_fn` input to DataLoaders."""
        df = pd.DataFrame(index=range(len(batch)), columns=batch[0].index)
        for i, row in enumerate(batch):
            df.loc[i] = row
        transformed_df = self.transformer.transform(df)
        return torch.tensor(transformed_df.values, dtype=torch.float)
