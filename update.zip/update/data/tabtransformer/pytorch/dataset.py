"""Dataset for Py-Torch."""

import os
from typing import Collection, List, Tuple, Union

import pandas as pd
from torch.utils.data import Dataset

from ..table import TableTransformer


class PandasDataset(Dataset):
    """Dataset class for PyTorch constructed from pd.DataFrame."""
    def __init__(self,
                 data: Union[Union[str, pd.DataFrame], Collection[str]],
                 *,
                 use_memory: bool = True,
                 cache_dir: str = "./",
                 max_chunk_size: int = 500,
                 **kwargs):
        """
        Initialize a dataset for pd.DataFrame.

        Parameters
        ----------
        data : str or pd.DataFrame or list[str]

            - If the value is a DataFrame, this is the DataFrame.
            - If the value is a string, it will be loaded by
              [`TableTransformer.load_data`](/tabtransformer#tabtransformer.TableTransformer.load_data).
            - If this is a list, make sure all of the data share the same column structure.
              The full dataset is all rows in all items in the list. This is designed particularly for very large
              datasets.
        use_memory : bool, optional
            Whether to use memory to store the data. Default is True.
            If set False, we will transfer the data to the disk. This saves runtime memory but creates additional IO
            steps that takes time.
        cache_dir : str, optional
            Directory to cache the data. This is to save some runtime CPU and move the data to disk
            (if `use_memory` is set). Default path is the current path.
        max_chunk_size : int, optional
            Maximum number of rows per cached DataFrame. Suggested to be not too large due to IO timing.
            The default value is 500.
        **kwargs
            Other arguments to [`TableTransformer.load_data`](/tabtransformer#tabtransformer.TableTransformer.load_data)
            if triggered.
        """
        self.cache_dir = cache_dir
        self.max_chunk_size = max_chunk_size
        self._length = 0
        if use_memory:
            if isinstance(data, pd.DataFrame):
                self.data = data
            else:
                if isinstance(data, str):
                    result = [TableTransformer.load_data(data, **kwargs)]
                else:
                    result = [
                        TableTransformer.load_data(item, **kwargs)
                        for item in data
                    ]
                self.data = pd.concat(result)
            self._length = len(data)
        else:
            os.makedirs(cache_dir, exist_ok=True)
            if isinstance(data, pd.DataFrame):
                remained, group_idx = self._save_dataframe(data)
            else:
                if isinstance(data, str):
                    current = data
                    pending = []
                else:
                    current = data[0]
                    pending = data[1:]
                remained = pd.DataFrame()
                group_idx = 0
                while True:
                    this_file_data = TableTransformer.load_data(current, **kwargs)
                    this_file_data = pd.concat([remained, this_file_data])
                    remained, group_idx = self._save_dataframe(this_file_data, group_idx)
                    if len(pending) <= 0:
                        break
                    current = pending[0]
                    pending = pending[1:]
            remained.to_csv(os.path.join(self.cache_dir, f"data-{group_idx}.csv"), index=False)
            self._length = (group_idx - 1) * self.max_chunk_size + len(remained)
            self.data = None

    def _save_dataframe(self, df: pd.DataFrame, group_idx: int = 0) -> Tuple[pd.DataFrame, int]:
        st = 0
        while st + self.max_chunk_size <= len(df):
            extracted = df.iloc[st:st + self.max_chunk_size]
            extracted.to_csv(os.path.join(self.cache_dir, f"data-{group_idx}.csv"), index=False)
            group_idx += 1
            st += self.max_chunk_size
        return df.iloc[st:], group_idx

    def __getitem__(self, index: int) -> pd.Series:
        if self.data is not None:
            return self.data.iloc[index]
        group_idx = index // self.max_chunk_size
        df = pd.read_csv(os.path.join(self.cache_dir, f"data-{group_idx}.csv"))
        row_idx = index % self.max_chunk_size
        return df.iloc[row_idx]

    def __len__(self) -> int:
        return self._length
