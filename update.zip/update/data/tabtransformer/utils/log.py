"""Utility functions for logging."""

import logging
import time
from functools import wraps


TRACE_LEVEL = 5
"""Logging level for tracing, which is larger than `NOTSET` but smaller than `DEBUG`."""


def make_printable_lapse_time(start_time: float, end_time: float) -> str:
    """
    Make a printable string for the lapse time.

    Parameters
    ----------
    start_time : float
        The start time by `time.time()`.
    end_time : float
        The end time by `time.time()`.

    Return
    ------
    str
        The time difference as "X hours, Y minutes and Z seconds" string format.
    """
    diff_time = end_time - start_time
    hours = diff_time // 3600
    minutes = (diff_time % 3600) // 60
    seconds = diff_time % 60
    return f"{hours} hours, {minutes} minutes and {seconds:.9f} seconds"


def log_time(start_msg: str, end_msg: str, start_level: int = logging.DEBUG, end_level: int = logging.INFO,
             with_name: bool = False):
    """
    Log lapse time for functions.

    Parameters
    ----------
    start_msg : str
        The message to be logged at the start of execution.
    end_msg : str
        The message to be logged at the end of execution.
    start_level : int, optional
        Start message logging level. Default is DEBUG.
    end_level : int, optional
        End message logging level. Default is INFO.
    with_name : bool, optional
        Whether to log the name of the first argument (by x.name). Default is False.
    """
    def _inner(func):
        @wraps(func)
        def _func(*args, **kwargs):
            name = ""
            if with_name:
                value = None
                new_args, new_kwargs = args, kwargs.copy()
                if "cls" in new_kwargs:
                    del new_kwargs["cls"]
                if new_args and isinstance(new_args[0], type):
                    new_args = new_args[1:]
                if new_args:
                    value = new_args[0]
                elif new_kwargs:
                    value = next(iter(new_kwargs.values()), None)
                if value is not None:
                    name = value + " " if isinstance(value, str) else value.name + " "
            logging.log(start_level, f"{start_msg} {name}...")
            start_time = time.time()
            out = func(*args, **kwargs)
            end_time = time.time()
            logging.log(end_level, f"{end_msg} {name}in {make_printable_lapse_time(start_time, end_time)}.")
            return out
        return _func
    return _inner
