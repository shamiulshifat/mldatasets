"""Utility functions on IO format and `None`-handling."""

import numbers
from enum import Enum
from typing import Any, Dict, List, Optional, Type, Union

import numpy as np


def make_dict(item: Optional[Dict]) -> Dict:
    """
    Make a dict.

    Parameter
    ---------
    item : dict or None
        The item to construct dict from.
        If item is None, an empty dict is given.

    Return
    ------
    dict
        Constructed dict.
    """
    return {} if item is None else item


def make_list(item: Optional[List]) -> List:
    """
    Make a list.

    Parameter
    ---------
    item : list or None
        The item to construct list from.
        If item is None, an empty list is given.

    Return
    ------
    list
        Constructed list.
    """
    return [] if item is None else item


def make_enum(item: Union[str, Enum], enum_type: Type[Enum]) -> "Enum":
    """
    Make an enum.

    Parameter
    ---------
    item : str or Enum
        The item to construct enum from.
        If item is a string, the enum value with this name is returned.

    Return
    ------
    Enum
        Constructed enum.
    """
    if isinstance(item, str):
        return enum_type[item]
    if not isinstance(item, enum_type):
        raise ValueError(f"The num item {item} is not in thi enum type {enum_type}.")
    return item


def filter_dict(content: Dict[str, Any], prefix: str, remove_prefix: bool = True) -> Dict[str, Any]:
    """
    Filter a dictionary to maintain only keys with a specific prefix.

    Parameters
    ----------
    content : dict
        The original dict.
    prefix : str
        The prefix to maintain.
    remove_prefix : bool, optional
        Whether to remove the prefix in the output. We will remove by default.

    Return
    ------
    The filtered dict.
    """
    if remove_prefix:
        length = len(prefix)
    else:
        length = 0
    return {
        k[length:]: v for k, v in content.items()
        if str(k).startswith(prefix)
    }


def make_json_compatible(content: Any) -> Any:
    """
    Make any content to JSON-compatible format.

    Parameter
    ---------
    content
        The object to convert to JSON-compatible.

    Return
    ------
    Any
        The JSON-compatible object.
    """
    def make_serializable(item: Any) -> Any:
        if isinstance(item, dict):
            return {key: make_serializable(value) for key, value in item.items()}
        elif isinstance(item, (list, tuple, set)):
            return [make_serializable(value) for value in item]
        elif isinstance(item, (str, int, float, bool, None.__class__)):
            return item
        elif isinstance(item, Enum):
            return item.name
        elif isinstance(item, np.ndarray):
            return make_serializable(item.tolist())
        elif isinstance(item, numbers.Number):
            int_content = int(item)
            if int_content == item:
                return int(item)
            else:
                return float(item)
        else:
            return str(item)

    return make_serializable(content)
