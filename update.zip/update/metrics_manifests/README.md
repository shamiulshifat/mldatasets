This directory contains core metrics code and yaml manifests for metrics.
1. image: This contains core metrics codes, dockrfile and requirements.txt.
2. metrics_eventsource.yaml : This yaml script creates an api endpoint on kubernetes for argo metrics sensor so that ml fastapi sensor can trigger metrics job using this endpoint.
3. metrics_sensor.yaml: This yaml script works as argo sensor for metrics. When ml fastapi sends an http request to event source, then the event source passes the request to sensor and sensor begins actual metrics job.