import os
import asyncio
import pandas as pd
import warnings
import json
from sklearn.model_selection import train_test_split

# Local Imports
from metrics.preprocessing.preprocessing import MetricsDataPrep
from metrics.preprocessing.preprocessing_utils import (
    get_column_dtype,
    Timer,
    generate_summary_dataset,
    setup_temp,
    get_encoding,
)

# ML Imports
from metrics.src.metrics.utility.ml_classification import ClassificationMetrics
from metrics.src.metrics.utility.ml_regression import RegressionMetrics

# Statistical Imports
from metrics.src.metrics.utility.statistical_metrics import StatisticalMetrics

# Plotting Imports
from metrics.src.metrics.utility.plot_data import PlotMetrics

# Privacy Imports
from metrics.src.metrics.privacy.metrics import PrivacyMetrics
from metrics.src.metrics.privacy.metrics import PrivacyAttacks

# Report generation Import
from metrics.src.report_gen.conversion import report_conversion
from metrics.src.report_gen.report import generate_report


# Logging Imports
from metrics.src.utils.logs import log

logger = log(name="metrics", path="./logs/", file="ml_logs.logs")

warnings.filterwarnings("ignore")


def parser_json(json_file):
    """
    Parse a JSON file and returns 'general' and 'metrics' parameters.

    This function reads a JSON file, parses it into a Python object, and returns the values of 'general' and 'metrics' keys.

    Parameters:
    json_file (str): The path to the JSON file to parse.

    Returns:
    tuple: Returns a tuple containing the values of 'general' and 'metrics' keys from the JSON file.

    Raises:
    FileNotFoundError: If `json_file` does not exist.
    JSONDecodeError: If `json_file` does not contain valid JSON.
    KeyError: If 'general' and/or 'metrics' keys do not exist in the JSON file.

    Example:
    general, metrics = parser_json('config.json')
    """
    with open(json_file, "r") as j:
        params = json.loads(j.read())
    return params["general"], params["metrics"]


def encoding_conversion(original_data_path, synthetic_data_path, encoding):
    """
    Convert the encoding of two CSV files: original and synthetic data.

    This function reads original data and synthetic data CSV files using the provided encoding or automatically
    detects the encoding if 'auto' is provided, then saves the data back to CSV files with 'utf-8' encoding.

    Parameters:
    original_data_path (str): The path to the original data CSV file.
    synthetic_data_path (str): The path to the synthetic data CSV file.
    encoding (str): The encoding to use for reading the files.
                    'auto' will automatically detect the encoding.
                    'default' will use 'utf-8' encoding.

    Returns:
    None. The function saves the original and synthetic data to their respective paths with 'utf-8' encoding.

    Raises:
    FileNotFoundError: If either `original_data_path` or `synthetic_data_path` does not exist.
    UnicodeDecodeError: If `encoding` does not match the file's actual encoding.
    Exception: If there's an encoding error while reading the file.

    Example:
    encoding_conversion('original_data.csv', 'synthetic_data.csv', 'auto')
    """
    if encoding == "auto":
        encoding = get_encoding(original_data_path)
    elif encoding == "default":
        encoding = "utf-8"
    try:
        logger.info("Encoding used: {}".format(encoding))
        original_data = pd.read_csv(original_data_path, encoding=encoding)
        synthetic_data = pd.read_csv(synthetic_data_path, encoding=encoding)
    except UnicodeDecodeError:
        raise Exception("Encoding Error. Please check the encoding of the file.")
    original_data.to_csv(original_data_path, index=False, encoding="utf-8")
    synthetic_data.to_csv(synthetic_data_path, index=False, encoding="utf-8")


def data_split(dataset, seed, test_size=0.1):
    """
    Split a dataset into training and testing subsets.

    This function uses a random train/test split. The `random_state` parameter ensures reproducibility. The dataset is shuffled before splitting.

    Parameters:
    dataset (DataFrame): A pandas DataFrame to split.
    seed (int): The seed for the random number generator. Used for reproducibility.
    test_size (float, optional): The proportion of the dataset to include in the test split. Defaults to 0.1.

    Returns:
    tuple: A tuple containing the training dataset and testing dataset as pandas DataFrames.

    Raises:
    ValueError: If `test_size` is not a float between 0.0 and 1.0, or if `dataset` is not a pandas DataFrame.

    Example:
    train_dataset, test_dataset = data_split(dataset, seed=42, test_size=0.2)
    """
    logger.info("Splitting Training Dataset.")
    train_dataset, test_dataset = train_test_split(
        dataset, test_size=test_size, random_state=seed, shuffle=True
    )
    return train_dataset, test_dataset


def ml_classification(original_data, synthetic_data):
    """
    Apply multiple machine learning classification models to the original and synthetic datasets.

    This function computes performance metrics on both datasets using a set of classification models and logs the results.

    Parameters:
    original_data (DataFrame): The original dataset as a pandas DataFrame.
    synthetic_data (DataFrame): The synthetic dataset as a pandas DataFrame.

    Returns:
    tuple: A tuple containing dictionaries with the classification performance metrics of each model on the original data and the synthetic data.

    Raises:
    KeyError: If the dataframes don't have expected columns/features needed by `ClassificationMetrics.compute`.

    Example:
    original_ml_metrics, synthetic_ml_metrics = ml_classification(original_data, synthetic_data)
    """
    logger.info("Starting ML Classification.")
    classification_models = [
        "AdaBoostClassifier",
        "BaggingClassifier",
        "ExtraTreesClassifier",
        "RandomForestClassifier",
    ]
    metrics = ["accuracy_score", "precision_score", "recall_score", "roc_auc_score"]
    metrics_r = 3
    original_ml_metrics, synthetic_ml_metrics = ClassificationMetrics.compute(
        original_data, synthetic_data, classification_models, metrics, metrics_r
    )
    logger.info("ML Results on the original data (classification)")
    logger.info(original_ml_metrics)
    logger.info("\n")
    logger.info("ML Results on the synthetic data (classification)")
    logger.info(synthetic_ml_metrics)
    logger.info("\n")
    logger.info("ML Classification Completed")

    return original_ml_metrics, synthetic_ml_metrics


def ml_regression(original_data, synthetic_data):
    """
    Apply machine learning regression models to the original and synthetic datasets.

    This function computes performance metrics on both datasets using a set of regression models and logs the results.

    Parameters:
    original_data (DataFrame): The original dataset as a pandas DataFrame.
    synthetic_data (DataFrame): The synthetic dataset as a pandas DataFrame.

    Returns:
    tuple: A tuple containing dictionaries with the regression performance metrics of each model on the original data and the synthetic data.

    Raises:
    KeyError: If the dataframes don't have expected columns/features needed by `RegressionMetrics.compute`.

    Example:
    original_ml_metrics, synthetic_ml_metrics = ml_regression(original_data, synthetic_data)
    """
    logger.info("Starting ML Regression.")
    logger.info("Real")
    regression_ml_metrics = RegressionMetrics(original_data, synthetic_data)
    original_results, synthetic_results = regression_ml_metrics.compute()
    logger.info("ML Results on the original data (regression)")
    logger.info(original_results)
    logger.info("\n")
    logger.info("ML Results on the synthetic data (regression)")
    logger.info(synthetic_results)
    logger.info("\n")
    logger.info("ML Regression Completed")
    return original_results, synthetic_results


def data_plotting(real_data, fake_data, metadata, bivariate, multivariate):
    """
    Plot graphs for real and synthetic data.

    This function generates various plots such as univariate, bivariate, and multivariate for both the real and synthetic data.

    Parameters:
    real_data (DataFrame): The original dataset as a pandas DataFrame.
    fake_data (DataFrame): The synthetic dataset as a pandas DataFrame.
    metadata (dict): Metadata about the columns in the data.
    bivariate (list of tuple): List of tuples where each tuple contains a pair of columns for which bivariate plots are to be generated.
    multivariate (list of dicts): List of dictionaries where each dictionary defines the columns for which multivariate plots are to be generated.

    Returns:
    None. The function generates plots, stores them as jpeg files  and doesn't return any value.

    Example:
    data_plotting(real_data, fake_data, metadata, bivariate_pairs, multivariate_dicts)
    """
    logger.info("Starting Data Plotting.")
    plot_metrics = PlotMetrics(
        real_data=real_data,
        fake_data=fake_data,
        columns_metadata=metadata,
        bivariate_pairs=bivariate,
        multivariate_dicts=multivariate,
    )
    plot_metrics.plot_graphs()
    logger.info("Data Plotting Completed.")


def statistical_metrics_calculation(real_data, fake_data, categorical_cols, bivariate):
    """
    Compute statistical metrics for real and synthetic data.

    This function computes various statistical metrics such as univariate and bivariate statistics for both the real and synthetic data.

    Parameters:
    real_data (DataFrame): The original dataset as a pandas DataFrame.
    fake_data (DataFrame): The synthetic dataset as a pandas DataFrame.
    categorical_cols (list): A list of columns in the dataset that are categorical.
    bivariate (list of tuple): List of tuples where each tuple contains a pair of columns for which bivariate statistics are to be computed.

    Returns:
    None. The function computes statistical metrics, stores it as csv file and doesn't return any value.

    Example:
    statistical_metrics_calculation(real_data, fake_data, categorical_cols, bivariate_pairs)
    """
    logger.info("Starting Statistical Calculation.")
    stat_metrics = StatisticalMetrics(
        real_data=real_data,
        fake_data=fake_data,
        categorical_cols=categorical_cols,
        bivariate_pairs=bivariate,
    )
    stat_metrics.compute_metrics()
    logger.info("Statistical Calculation Completed.")


def privacy_metrics_calculation(real_data, fake_data, categorical_cols):
    """
    Compute privacy metrics for real and synthetic data.

    This function computes various privacy metrics such as DCR and NNDR.

    Parameters:
    real_data (DataFrame): The original dataset as a pandas DataFrame.
    fake_data (DataFrame): The synthetic dataset as a pandas DataFrame.
    categorical_cols (list): A list of columns in the dataset that are categorical.

    Returns:
    None. The function computes privacy metrics, stores it as yaml file  and doesn't return any value.

    Example:
    privacy_metrics_calculation(real_data, fake_data, categorical_cols)
    """
    logger.info("Starting Privacy Metrics Calculation.")
    real_train_data, real_test_data = train_test_split(
        real_data, test_size=0.1, random_state=42
    )
    privacy_metrics = PrivacyMetrics(
        original_train_dataset=real_train_data,
        original_test_dataset=real_test_data,
        synthetic_dataset=fake_data,
        categorical_cols=categorical_cols,
    )
    privacy_metrics.compute_metrics()
    logger.info("Privacy Metrics Calculation Completed.")


def privacy_attacks(real_data, syn_data, attack_params):
    """
    Perform privacy attacks on real and synthetic data.

    This function performs various privacy attacks such as singling out, linkabality and inference attacks.

    Parameters:
    real_data (DataFrame): The original dataset as a pandas DataFrame.
    syn_data (DataFrame): The synthetic dataset as a pandas DataFrame.
    attack_params (dict): Parameters for the privacy attacks.

    Returns:
    None. The function performs privacy attacks and doesn't return any value.

    Example:
    privacy_attacks(real_data, syn_data, attack_params)
    """
    logger.info("Starting Privacy Attacks.")
    real_train_data, real_test_data = train_test_split(
        real_data, test_size=0.1, random_state=42
    )
    privacy_attacks = PrivacyAttacks(
        original_train_dataset=real_train_data,
        original_test_dataset=real_test_data,
        synthetic_dataset=syn_data,
    )
    privacy_attacks.compute_results(attack_params)
    logger.info("Privacy Attacks Completed.")


def main(
    original_data_path,
    synthetic_data_path,
    target_list,
    user_cols_info,
    drop_columns,
    categorical_threshold,
    unique_percentage,
    bivariate_pairs,
    multivariate_dicts,
    privacy_params,
):
    """
    Main pipeline for evaluating synthetic data.

    This function loads the original and synthetic datasets, preprocesses the data,
    calculates machine learning and statistical metrics, plots data, calculates privacy metrics,
    executes privacy attacks and finally returns the summary.

    Parameters:
    original_data_path (str): The file path of the original dataset.
    synthetic_data_path (str): The file path of the synthetic dataset.
    target_list (list): A list of target variables for the ML models.
    user_cols_info (dict): User-provided information about the dataset columns.
    drop_columns (list): A list of columns to drop from the dataset.
    categorical_threshold (float): The threshold to use to determine whether a column is categorical.
    unique_percentage (float): The unique percentage threshold for dropping columns.
    bivariate_pairs (list of tuples): List of column pairs for bivariate analysis.
    multivariate_dicts (list of dicts): List of dictionaries for multivariate analysis.
    privacy_params (dict): Parameters for privacy attacks.

    Returns:
    classification_results (list): A list of results from ML classification models.
    regression_results (list): A list of results from ML regression models.
    summary_dataset1 (DataFrame): A summary of the synthetic dataset.
    summary_dataset2 (DataFrame): A summary DataFrame for both datasets.
    column_metadata (dict): Metadata information for each column in the datasets.
    col_modifications (list): List of columns with removed rows during preprocessing.

    Raises:
    ValueError: If any of the inputs are not in the expected format.
    FileNotFoundError: If the file paths are incorrect.

    Example:
    main(original_data_path, synthetic_data_path, target_list, user_cols_info, drop_columns,
        categorical_threshold, unique_percentage, bivariate_pairs, multivariate_dicts, privacy_params)
    """
    original_data = pd.read_csv(original_data_path)
    synthetic_data = pd.read_csv(synthetic_data_path)
    logger.info(
        "-----------------------Data Preprocessing Started--------------------------"
    )
    columns_dtype = get_column_dtype(
        original_data, user_cols_info, categorical_threshold
    )
    data_preprocessing = MetricsDataPrep(
        categorical=columns_dtype["categorical_columns"],
        continuous=columns_dtype["continuous_columns"],
        log=columns_dtype["log_columns"],
        mixed=columns_dtype["mixed_columns"],
        general=columns_dtype["general_columns"],
        integer=columns_dtype["integer_columns"],
        datetime=columns_dtype["datetime_columns"],
        drop_columns=drop_columns,
        categorical_threshold=categorical_threshold,
        unique_percentage=unique_percentage,
    )
    original_data, synthetic_data = data_preprocessing.general_preprocessing(
        original_data, synthetic_data
    )
    column_metadata = data_preprocessing.column_types
    logger.info(
        "-----------------------ML Metrics Calculation Started-----------------------------"
    )
    classification_results_real = []
    classification_results_fake = []
    classification_targets = []
    regression_results_real = []
    regression_results_fake = []
    regression_targets = []
    for target in target_list:
        if target in column_metadata["Categorical Cols"]:
            original_copy = original_data.copy()
            synthetic_copy = synthetic_data.copy()
            original_copy, synthetic_copy = data_preprocessing.ml_preprocessing(
                original_copy, synthetic_copy, target
            )
            temp_original, temp_synthetic = ml_classification(
                original_copy, synthetic_copy
            )
            classification_results_real.append(temp_original)
            classification_results_fake.append(temp_synthetic)
            classification_targets.append(target)
        else:
            original_copy = original_data.copy()
            synthetic_copy = synthetic_data.copy()
            original_copy, synthetic_copy = data_preprocessing.ml_preprocessing(
                original_copy, synthetic_copy, target
            )
            temp_original, temp_synthetic = ml_regression(original_copy, synthetic_copy)
            regression_results_real.append(temp_original)
            regression_results_fake.append(temp_synthetic)
            regression_targets.append(target)
    classification_results = [
        classification_results_real,
        classification_results_fake,
        classification_targets,
    ]
    regression_results = [
        regression_results_real,
        regression_results_fake,
        regression_targets,
    ]
    logger.info("-----------------------Plotting Data-----------------------------")
    original_data_plotting = original_data.copy()
    synthetic_data_plotting = synthetic_data.copy()
    data_plotting(
        original_data_plotting,
        synthetic_data_plotting,
        column_metadata,
        bivariate_pairs,
        multivariate_dicts,
    )
    logger.info(
        "-----------------------Statistical Metrics-----------------------------"
    )
    original_data_stat = original_data.copy()
    synthetic_data_stat = synthetic_data.copy()
    (
        original_data_stat,
        synthetic_data_stat,
    ) = data_preprocessing.statistical_preprocessing(
        original_data_stat, synthetic_data_stat
    )
    statistical_metrics_calculation(
        original_data_stat,
        synthetic_data_stat,
        column_metadata["Categorical Cols"],
        bivariate_pairs,
    )
    logger.info("-----------------------Privacy Metrics-----------------------------")
    original_data_stat = original_data.copy()
    synthetic_data_stat = synthetic_data.copy()
    privacy_metrics_calculation(
        original_data_stat, synthetic_data_stat, column_metadata["Categorical Cols"]
    )
    logger.info("-----------------------Privacy Attacks-----------------------------")
    if privacy_params is not None:
        original_data_stat = original_data.copy()
        synthetic_data_stat = synthetic_data.copy()
        privacy_attacks(original_data_stat, synthetic_data_stat, privacy_params)
    logger.info("-----------------------Summary-----------------------------")
    summary_dataset1 = generate_summary_dataset(
        synthetic_data, column_metadata["Categorical Cols"]
    )
    summary_dataset2 = pd.DataFrame()
    num_cat_cols = len(column_metadata["Categorical Cols"])
    num_num_cols = len(column_metadata["Numerical Cols"])
    summary_dataset2["Columns"] = [
        f"Categorical: {num_cat_cols}, Numerical: {num_num_cols}"
    ]
    summary_dataset2["Real dataset"] = [
        f"{original_data.shape[0]} rows, {original_data.shape[1]} columns"
    ]
    summary_dataset2["Synthetic dataset"] = [
        f"{synthetic_data.shape[0]} rows, {synthetic_data.shape[1]} columns"
    ]
    col_modifications = data_preprocessing.cols_with_removed_rows
    return (
        classification_results,
        regression_results,
        summary_dataset1,
        summary_dataset2,
        column_metadata,
        col_modifications,
    )


def metrics_core(args, html_to_pdf):
    """
    Core function to evaluate the synthetic data metrics.

    This function parses the input json file, performs encoding conversion, calculates timing
    metrics, and prepares a report summarizing all the metrics.

    Parameters:
    original_data_path (str): The file path of the original dataset.
    synthetic_data_path (str): The file path of the synthetic dataset.
    json_file_path (str): The file path of the json configuration file.
    html_to_pdf (bool): Boolean flag to indicate whether to convert HTML reports to PDF.

    Returns:
    None. A summary report is generated as a side effect.

    Raises:
    ValueError: If any of the inputs are not in the expected format.
    FileNotFoundError: If the file paths are incorrect.

    Example:
    metrics_core(original_data_path, synthetic_data_path, json_file_path, html_to_pdf)

    ********************
    NOTE: THIS FUNCTION IS USED BY THE DEPLOYMENT SCRIPT. IF ANY CHANGES ARE MADE TO THIS FUNCTION,
    INFORM THE DEPLOYMENT TEAM.
    ********************
    """
    general_args, metrics_args = parser_json(args["json_filepath"])
    encoding_conversion(
        args["raw_data_filepath"], args["synthetic_data_filepath"], general_args["encodings"]
    )
    original_data = pd.read_csv(args["raw_data_filepath"])
    with open(args["train_info_filepath"], "r") as f:
        train_info = json.load(f)
    with open(args["inference_info_filepath"], "r") as f:
        inference_info = json.load(f)

    pipeline_timing = {}
    pipeline_timing["Training"] = train_info
    pipeline_timing["Inference"] = inference_info

    # Process target string
    if len(metrics_args["target_string"]) != 0:
        target_list = metrics_args["target_string"].split(",")
        target_list_main = []
        for i in target_list:
            if i[0] == " ":
                if i[-1] == " ":
                    target_list_main.append(i[1:-1])
                else:
                    target_list_main.append(i[1:])
            else:
                if i[-1] == " ":
                    target_list_main.append(i[:-1])
                else:
                    target_list_main.append(i)
    else:
        target_list_main = []
        original_data_columns = original_data.columns
        target_list_main.append(original_data_columns[0])
        target_list_main.append(original_data_columns[-1])

    if not os.path.exists("./metrics/src/metrics/temp"):
        setup_temp("./metrics/src/metrics/temp")

    metrics_time = Timer("Metrics")
    metrics_time.start()
    (
        classification_r,
        regression_r,
        summary1,
        summary2,
        col_metadata,
        col_modifications,
    ) = main(
        args["raw_data_filepath"],
        args["synthetic_data_filepath"],
        target_list_main,
        general_args["columns_usecase"]["synthetic_columns"]["column_dtypes"],
        general_args["columns_usecase"]["drop_columns"],
        general_args["categorical_threshold"],
        general_args["unique_percentage"],
        metrics_args["bivariate_pairs"],
        metrics_args["multivariate_dicts"],
        metrics_args["privacy"],
    )
    metrics_time.stop()
    metrics_time_info = {}
    (
        metrics_time_info["Hr"],
        metrics_time_info["Mins"],
        metrics_time_info["Secs"],
    ) = metrics_time.get_time()
    pipeline_timing["Metrics"] = metrics_time_info
    if len(col_metadata["Categorical Cols"]) > 0:
        cat_cols = True
    else:
        cat_cols = False
    if len(metrics_args["bivariate_pairs"]) > 0:
        bivariate_plots = True
    else:
        bivariate_plots = False
    if len(metrics_args["multivariate_dicts"]) > 0:
        multivariate_plots = True
    else:
        multivariate_plots = False
    generate_report(
        classification_r,
        regression_r,
        summary1,
        summary2,
        col_modifications,
        cat_cols,
        pipeline_timing,
        bivariate_plots,
        multivariate_plots,
    )
    if html_to_pdf:
        asyncio.get_event_loop().run_until_complete(report_conversion())
