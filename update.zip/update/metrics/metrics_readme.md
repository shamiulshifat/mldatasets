# Metrics ReadME

```
--> metrics                                 [Main source code for metrics and report generation]
    --> preprocessing                       [Required preprocessing steps for the metrics code]
        --> preprocessing.py                [Contains the `MetricsDataPrep` class with preprocessing steps]
        --> preprocessing_utils.py          [Utility functions for preprocessing]
    --> src                                 [Core source code for various metrics and datapane report]
        --> metrics                         [Source code for statistical, machine learning, and privacy metrics]
            --> privacy                     [Privacy metrics (DCR, NNDR) and privacy attacks]
                --> anonymeter              [Source code for privacy attacks. Refer to [Anonymeter repository](https://github.com/statice/anonymeter)]
                --> metrics.py              [Calculation of DCR and NNDR metrics; contains `PrivacyAttacks` class which leverages code from `anonymeter` directory]
            --> utility                     [Source code for statistical and ML metrics]
                --> ml_classification.py    [ML classification metrics and models]
                --> ml_regression.py        [ML regression metrics and models]
                --> plot_data.py            [Plotting methods for univariate, bivariate, and multivariate data]
                --> statistical_metrics.py  [Code for calculating statistical metrics]
        --> report_gen                      [Datapane report generation]
            --> conversion.py               [Converts HTML report to PDF format]
            --> report.py                   [Generates the datapane report]
        --> utils                           [Utility functions for metrics and reporting]
            --> logs.py                     [Logger module]
    --> metrics_main.py                     [Main script to run the metrics code and produce a report]

Notes:
1. DCR & NNDR Code Modification: Before modifying the DCR and NNDR code, familiarize yourself with NUMBA documentation. NUMBA is vital for performance, speeding up the metrics significantly. Ensure you adhere to its specific rules to avoid errors.
2. Plot Storage: Plots from plot_data.py are stored at metrics/src/metrics/temp/temp-graphs/ temporarily. They are accessed by report.py for inclusion in the report. The folder is auto-generated and deleted post execution.
```
