# a function  to create and save logs in the log files
def log(name, path, file):
    import logging
    import os

    """[Create a log file to record the experiment's logs]
    
    Arguments:
        name {string} -- name of logger instance
        path {string} -- path to the directory
        file {string} -- file name
    
    Returns:
        [obj] -- [logger that record logs]
    """

    # check if the file exist
    log_file = os.path.join(path, file)
    if not os.path.exists(path):
        os.makedirs(path)

    if not os.path.isfile(log_file):
        open(log_file, "w+").close()

    console_logging_format = "%(levelname)s: %(asctime)s: %(message)s"
    file_logging_format = "%(levelname)s: %(asctime)s: %(message)s"

    # configure logger
    logging.basicConfig(level=logging.INFO, format=console_logging_format)
    logger = logging.getLogger(name)
    logger.propagate = False

    # create a file handler for output file
    file_handler = logging.FileHandler(log_file)
    # create a console handler
    console_handler = logging.StreamHandler()

    # set the logging level for log file
    file_handler.setLevel(logging.INFO)
    # set the logging level for console
    console_handler.setLevel(logging.INFO)

    # create a logging format for the file handler
    file_formatter = logging.Formatter(file_logging_format)
    # create a logging format for the console ehandler
    console_formatter = logging.Formatter(console_logging_format)
    console_handler.setFormatter(console_formatter)

    if not logger.handlers:
        # add the handlers to the logger
        logger.addHandler(file_handler)
        logger.addHandler(console_handler)

    return logger
