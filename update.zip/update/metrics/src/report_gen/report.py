import pandas as pd
import datapane as dp
from datetime import date
import os
import shutil
from PIL import Image
from bs4 import BeautifulSoup as bs
import yaml
from bs4 import BeautifulSoup


# # Helper funtions
current_overflow = """
html{
  overflow:auto !important;
  height:100%
}
"""

new_overflow = """
html{
  overflow:visible !important;
  height:100%
}
"""


def change_overflow(filepath):
    with open(filepath, "r") as f:
        html = f.read()
    soup = BeautifulSoup(html)
    if current_overflow in soup.prettify():
        soup = soup.prettify().replace(current_overflow, new_overflow)
        print("Success")
    with open(filepath, "w") as f:
        f.write(str(soup))


def ml_metrics_ratio(real, fake):
    ratio = pd.DataFrame()
    ratio.index = real.index
    for i in real.columns:
        if i != "Models":
            temp = []
            for j in range(len(real[i])):
                temp.append(fake[i].iloc[j] / real[i].iloc[j])
            ratio[i] = temp
        else:
            temp = []
            for j in real[i]:
                temp.append(j)
            ratio[i] = temp
    return ratio


def reset_temp(folder):
    """
    Resets the temp folder.
    """
    shutil.rmtree(folder)
    main_dir = ["temp-dataset", "temp-graphs"]
    temp_graphs = [
        "temp-graphs/temp-correlation-original",
        "temp-graphs/temp-univariate-original",
        "temp-graphs/temp-bivariate_graphs",
        "temp-graphs/temp-multivariate_graphs",
    ]
    os.mkdir(folder)
    for i in main_dir:
        os.mkdir(os.path.join(folder, i))
    for i in temp_graphs:
        os.mkdir(os.path.join(folder, i))
    return "Done"


def remove_data_pane(filepath):
    html = open("Report-Main.html")
    main = bs(html, "html.parser")
    # Remove the data pane from the html file
    soup = main.find(
        "div", {"style": "position: fixed; bottom: 0; width: 100%; z-index: 3;"}
    )
    soup.decompose()
    # Save the new html file
    with open("Report-Main.html", "w") as f:
        f.write(str(main))


def combine_dataframes(dataframes):
    """
    Combines two dataframes into one.
    """
    df = dataframes[0]
    for i in range(1, len(dataframes)):
        if "P Value" in dataframes[i].columns:
            dataframes[i].drop("P Value", axis=1, inplace=True)
        df = pd.merge(df, dataframes[i])
    for i in df.columns:
        if i != "Features":
            df[i] = df[i].round(3)
    return df


def add_padding(image, padding=1000):
    """
    Adds padding to the image.
    """
    width, height = image.size
    new_im = Image.new("RGB", (width + 2 * padding, height), (255, 255, 255))
    new_im.paste(image, (padding, 0))
    return new_im


def style_values_ks(v, props=""):
    """Banding for the KS test"""
    if isinstance(v, float):
        if pd.isna(v):
            return "color:grey;"
        elif v > 0.5:
            return "color:red;"
        elif v > 0.2 and v <= 0.5:
            return "color:orange;"
        elif v > 0.05 and v <= 0.2:
            return "color:lightgreen;"
        else:
            return "color:darkgreen;"
    else:
        return props


def style_values_kld(v, props=""):
    """Banding for KL Divergence"""
    if isinstance(v, float):
        if pd.isna(v):
            return "color:grey;"
        elif v > 0.5:
            return "color:red;"
        elif v > 0.1 and v <= 0.5:
            return "color:orange;"
        else:
            return "color:green;"
    else:
        return props


def style_values_cs(v, props=""):
    """Banding for the Chi-Square test"""
    if isinstance(v, float):
        if pd.isna(v):
            return "color:grey;"
        elif (1 - v) > 0.35:
            return "color:red;"
        elif (1 - v) > 0.2 and (1 - v) <= 0.35:
            return "color:orange;"
        elif (1 - v) > 0.1 and (1 - v) <= 0.2:
            return "color:lightgreen;"
        else:
            return "color:darkgreen;"
    else:
        return props


def style_values_wd(v, props=""):
    """Banding for  distance"""
    if isinstance(v, float):
        if pd.isna(v):
            return "color:grey;"
        if v > 1.0:
            return "color:red;"
        elif v > 0.5 and v <= 1.0:
            return "color:orange;"
        elif v > 0.1 and v <= 0.5:
            return "color:lightgreen;"
        else:
            return "color:darkgreen;"
    else:
        return props


def style_values_jsd(v, props=""):
    """Banding for Jensen-Shannon Divergence"""
    if isinstance(v, float):
        if pd.isna(v):
            return "color:grey;"
        if v > 0.35:
            return "color:red;"
        elif v > 0.2 and v <= 0.35:
            return "color:orange;"
        elif v > 0.05 and v <= 0.2:
            return "color:lightgreen;"
        else:
            return "color:darkgreen;"
    else:
        return props


def style_value_mlratio(v, props=""):
    """Banding for the ML metrics"""
    if isinstance(v, float):
        if v > 0.85:
            return "color:darkgreen;"
        elif v > 0.7 and v <= 0.85:
            return "color:green;"
        elif v > 0.6 and v <= 0.7:
            return "color:orange;"
        else:
            return "color:red;"
    else:
        return props


def block_ml_summary_gen(dataset_ratio, decimal_places=4):
    mean_acc = round(dataset_ratio["Accuracy Score"].mean(), decimal_places)
    mean_prec = round(dataset_ratio["Precision Score"].mean(), decimal_places)
    mean_recall = round(dataset_ratio["Recall Score"].mean(), decimal_places)
    mean_roc = round(dataset_ratio["ROC AUC Score"].mean(), decimal_places)
    mean_all = round(
        (mean_acc + mean_prec + mean_recall + mean_roc) / 4, decimal_places
    )
    block_ml_summary = [
        dp.BigNumber(heading="Overall ML Performance Mean", value=mean_all),
        dp.Group(
            dp.BigNumber(heading="Accuracy Mean", value=mean_acc),
            dp.BigNumber(heading="Precision Score Mean", value=mean_prec),
            dp.BigNumber(heading="Recall Score Mean", value=mean_recall),
            dp.BigNumber(heading="ROC AUC Score Mean", value=mean_roc),
            columns=4,
        ),
    ]
    return block_ml_summary


class ReportGeneration:
    def __init__(self, cat_data):
        self.today = date.today()
        self.cat_data = cat_data

    def block_intro_gen(self, timings):
        training_time = (
            "Training time: Hrs "
            + str(timings["Training"]["Hr"])
            + ", Mins "
            + str(timings["Training"]["Mins"])
            + ", Secs "
            + str(int(timings["Training"]["Secs"]))
        )
        inference_time = (
            "Inference time: Hrs "
            + str(timings["Inference"]["Hr"])
            + ", Mins "
            + str(timings["Inference"]["Mins"])
            + ", Secs "
            + str(int(timings["Inference"]["Secs"]))
        )
        metrics_time = (
            "Metrics time: Hrs "
            + str(timings["Metrics"]["Hr"])
            + ", Mins "
            + str(timings["Metrics"]["Mins"])
            + ", Secs "
            + str(int(timings["Metrics"]["Secs"]))
        )
        self.block_intro = [
            dp.Text("# Report: Synthetic Data"),
            dp.Text(str(self.today)),
            dp.Text(training_time),
            dp.Text(inference_time),
            dp.Text(metrics_time),
        ]

    def block_data_summary(self, summary1, summary2, col_modifications):
        if col_modifications != {}:
            col_modifications_df = pd.DataFrame(columns=["Column", "Modifications"])
            for k, v in col_modifications.items():
                modifications = f"{v[1]-v[0]} out of {v[1]} ({round((v[1]-v[0])/v[1]*100, 2)}%) unique values were removed"
                col_modifications_df = col_modifications_df.append(
                    {"Column": k, "Modifications": modifications}, ignore_index=True
                )
            modifications_info = [dp.Table(col_modifications_df)]
        else:
            modifications_info = []
        self.block_data_summary = [
            dp.Text("# Data Summary"),
            dp.Table(summary1),
            dp.Table(summary2),
        ]
        self.block_data_summary = self.block_data_summary + modifications_info

    def block_ml_classification_gen(
        self, classification_r, classification_ratios, classification_ratio_styled
    ):
        self.block_ml_classification = [dp.Text("## ML Classification Metrics")]
        for i in range(len(classification_r[2])):
            summary = block_ml_summary_gen(classification_ratios[i])
            block = [
                dp.Text("### Target: " + classification_r[2][i]),
                dp.Text("### Performance comparison"),
                dp.Table(classification_ratio_styled[i]),
                dp.Text("### Real Data"),
                dp.Table(classification_r[0][i]),
                dp.Text("### Synthetic Data"),
                dp.Table(classification_r[1][i]),
            ]
            block = block[:2] + summary + block[2:]
            self.block_ml_classification.extend(block)

    def block_ml_regression_gen(self, regression_r):
        self.block_ml_regression = [dp.Text("## ML Regression Metrics")]
        for i in range(len(regression_r[2])):
            block = [
                dp.Text("### Target: " + regression_r[2][i]),
                dp.Text("### Real Data"),
                dp.Table(regression_r[0][i]),
                dp.Text("### Synthetic Data"),
                dp.Table(regression_r[1][i]),
            ]
            self.block_ml_regression.extend(block)

    def utility_gen(self):
        self.block_utility = [
            dp.Text("# Utility Metrics"),
        ]

    def block_stat_init_gen(self):
        self.block_stat_init = [
            dp.Text("## Statistical Metrics"),
        ]

    def block_stat_num_gen(self, dataset_num):
        self.block_stat_num = [dp.Text("### All Columns"), dataset_num]

    def block_stat_cat_gen(self, dataset_cat):
        self.block_stat_cat = [
            dp.Text("### Categorical Columns"),
            dp.Table(dataset_cat),
        ]

    def block_biv_metrics_gen(self, metrics):
        if metrics is not None:
            self.block_biv_metrics = [dp.Text("## Bivariate Metrics")]
            self.block_biv_metrics.append(dp.Table(metrics))
        else:
            self.block_biv_metrics = []

    def block_privacy_attack_gen(self, privacy_attacks):
        privacy_attack_block = []
        for attack in privacy_attacks.keys():
            if attack == "singling_out_univariate":
                attack_info = []
                attack_info.append(dp.Text("### Singling Out Univariate"))
                attack_info.append(
                    dp.Text(
                        "Privacy Risk:" + str(privacy_attacks[attack]["privacy_risk"])
                    )
                )
                attack_info.append(
                    dp.Text(
                        "Confidence interval: -"
                        + str(privacy_attacks[attack]["ci1"])
                        + ", +"
                        + str(privacy_attacks[attack]["ci2"])
                    )
                )
                privacy_attack_block.extend(attack_info)
            if attack == "singling_out_multivariate":
                attack_info = []
                attack_info.append(dp.Text("### Singling Out Multivariate"))
                for groups in privacy_attacks[attack]["privacy_risk"].keys():
                    attack_info.append(dp.Text("*Number of neighbors*: " + str(groups)))
                    attack_info.append(
                        dp.Text(
                            "Privacy Risk:"
                            + str(privacy_attacks[attack]["privacy_risk"][groups])
                        )
                    )
                    attack_info.append(
                        dp.Text(
                            "Confidence interval: -"
                            + str(privacy_attacks[attack]["ci1"][groups])
                            + ", +"
                            + str(privacy_attacks[attack]["ci2"][groups])
                        )
                    )
                privacy_attack_block.extend(attack_info)
            if attack == "linkability":
                attack_info = []
                attack_info.append(dp.Text("### Linkability"))
                for groups in privacy_attacks[attack]["privacy_risk"].keys():
                    attack_info.append(dp.Text("*Number of neighbors*: " + str(groups)))
                    attack_info.append(
                        dp.Text(
                            "Privacy Risk:"
                            + str(privacy_attacks[attack]["privacy_risk"][groups])
                        )
                    )
                    attack_info.append(
                        dp.Text(
                            "Confidence interval: -"
                            + str(privacy_attacks[attack]["ci1"][groups])
                            + ", +"
                            + str(privacy_attacks[attack]["ci2"][groups])
                        )
                    )
                privacy_attack_block.extend(attack_info)
            if attack == "inference":
                attack_info = []
                attack_info.append(dp.Text("### Inference"))
                inference_results = pd.DataFrame(privacy_attacks[attack])
                # Reorder columns
                inference_results = inference_results[
                    ["columns", "privacy_risk", "ci1", "ci2"]
                ]
                attack_info.append(dp.Table(inference_results))
                privacy_attack_block.extend(attack_info)
        return privacy_attack_block

    def block_privacy_gen(self, privacy_metrics, privacy_attacks, graph):
        self.block_privacy = [
            dp.Text("# Privacy Metrics"),
            dp.Group(
                dp.BigNumber(
                    heading="DCR of Test-Train",
                    value=privacy_metrics["Data"]["DCR Test-Train"],
                ),
                dp.BigNumber(
                    heading="DCR of Synthetic-Train",
                    value=privacy_metrics["Data"]["DCR Synthetic-Train"],
                ),
                columns=2,
            ),
            dp.BigNumber(
                heading="DCR difference between Test-Train & Synthetic-Train",
                value=privacy_metrics["Data"]["DCR Synthetic-Train"]
                - privacy_metrics["Data"]["DCR Test-Train"],
            ),
            dp.Group(
                dp.Media(
                    file=graph,
                    name="",
                    caption="Distance to Closest Record: Number of Records vs Distance Plot",
                ),
                columns=1,
            ),
            dp.Group(
                dp.BigNumber(
                    heading="NNDR of Test-Train",
                    value=privacy_metrics["Data"]["NNDR Test-Train"],
                ),
                dp.BigNumber(
                    heading="NNDR of Synthetic-Train",
                    value=privacy_metrics["Data"]["NNDR Synthetic-Train"],
                ),
                columns=2,
            ),
            dp.BigNumber(
                heading="NNDR difference between Test-Train & Synthetic-Train",
                value=privacy_metrics["Data"]["NNDR Synthetic-Train"]
                - privacy_metrics["Data"]["NNDR Test-Train"],
            ),
        ]
        if privacy_attacks is not None:
            privacy_attack_block = [dp.Text("# Privacy Attack")]
            privacy_attack_block.extend(self.block_privacy_attack_gen(privacy_attacks))
            self.block_privacy.extend(privacy_attack_block)

    def block_corr_graphs_gen(self, images, add_diff=True):
        self.block_corr_graphs = [dp.Text("## Correlation Graphs")]
        plots = []
        if add_diff:
            plots.append(dp.Media(file=images[0], caption="Correlation Matrix Real"))
            plots.append(dp.Media(file=images[1], caption="Correlation Matrix Fake"))
            plots.append(dp.Media(file=images[2], caption="Correlation Matrix (Diff)"))
        else:
            plots.append(dp.Media(file=images[0], caption="Correlation Matrix Real"))
            plots.append(dp.Media(file=images[1], caption="Correlation Matrix Fake"))
        self.block_corr_graphs.append(dp.Group(blocks=plots, columns=2))

    def block_corr_graphs_gen_table(self, images, add_diff=True):
        self.block_corr_graphs_tables = [dp.Text("## Correlation Matrix")]
        plots = []
        if add_diff:
            plots.append(dp.Media(file=images[3], caption="Correlation Matrix (Diff)"))
        else:
            plots.append(dp.Media(file=images[3], caption="Correlation Matrix"))
        self.block_corr_graphs_tables.append(dp.Group(blocks=plots, columns=1))

    def block_univ_graphs_gen(self, images):
        self.block_univ_graphs = [dp.Text("## Univariate Graphs")]
        plots = []
        for i in images:
            plots.append(dp.Media(i))
        self.block_univ_graphs.append(dp.Group(blocks=plots, columns=3))

    def block_biv_graphs_gen(self, images):
        if len(images) > 0:
            self.block_biv_graphs = [dp.Text("## Bivariate Graphs")]
            plots = []
            for i in images:
                plots.append(dp.Media(i))
            self.block_biv_graphs.append(dp.Group(blocks=plots, columns=2))
        else:
            self.block_biv_graphs = []

    def block_multiv_graphs_gen(self, images):
        if len(images) > 0:
            self.block_multiv_graphs = [dp.Text("## Multivariate Graphs")]
            plots = []
            for i in images:
                plots.append(dp.Media(i))
            self.block_multiv_graphs.append(dp.Group(blocks=plots, columns=1))
        else:
            self.block_multiv_graphs = []

    def generate_report(self, save_path, classification, regression):
        if classification and regression:
            if self.cat_data:
                self.report = (
                    self.block_intro
                    + self.block_data_summary
                    + self.block_utility
                    + self.block_univ_graphs
                    + self.block_biv_graphs
                    + self.block_multiv_graphs
                    + self.block_corr_graphs
                    + self.block_corr_graphs_tables
                    + self.block_stat_init
                    + self.block_stat_cat
                    + self.block_stat_num
                    + self.block_biv_metrics
                    + self.block_ml_classification
                    + self.block_ml_regression
                    + self.block_privacy
                )
            else:
                self.report = (
                    self.block_intro
                    + self.block_data_summary
                    + self.block_utility
                    + self.block_univ_graphs
                    + self.block_biv_graphs
                    + self.block_multiv_graphs
                    + self.block_corr_graphs
                    + self.block_corr_graphs_tables
                    + self.block_stat_init
                    + self.block_stat_num
                    + self.block_biv_metrics
                    + self.block_ml_classification
                    + self.block_ml_regression
                    + self.block_privacy
                )
        elif classification:
            if self.cat_data:
                self.report = (
                    self.block_intro
                    + self.block_data_summary
                    + self.block_utility
                    + self.block_univ_graphs
                    + self.block_biv_graphs
                    + self.block_multiv_graphs
                    + self.block_corr_graphs
                    + self.block_corr_graphs_tables
                    + self.block_stat_init
                    + self.block_stat_cat
                    + self.block_stat_num
                    + self.block_biv_metrics
                    + self.block_ml_classification
                    + self.block_privacy
                )
            else:
                self.report = (
                    self.block_intro
                    + self.block_data_summary
                    + self.block_utility
                    + self.block_univ_graphs
                    + self.block_biv_graphs
                    + self.block_multiv_graphs
                    + self.block_corr_graphs
                    + self.block_corr_graphs_tables
                    + self.block_stat_init
                    + self.block_stat_num
                    + self.block_biv_metrics
                    + self.block_ml_classification
                    + self.block_privacy
                )
        elif regression:
            if self.cat_data:
                self.report = (
                    self.block_intro
                    + self.block_data_summary
                    + self.block_utility
                    + self.block_univ_graphs
                    + self.block_biv_graphs
                    + self.block_multiv_graphs
                    + self.block_corr_graphs
                    + self.block_corr_graphs_tables
                    + self.block_stat_init
                    + self.block_stat_cat
                    + self.block_stat_num
                    + self.block_biv_metrics
                    + self.block_ml_regression
                    + self.block_privacy
                )
            else:
                self.report = (
                    self.block_intro
                    + self.block_data_summary
                    + self.block_utility
                    + self.block_univ_graphs
                    + self.block_biv_graphs
                    + self.block_multiv_graphs
                    + self.block_corr_graphs
                    + self.block_corr_graphs_tables
                    + self.block_stat_init
                    + self.block_stat_num
                    + self.block_biv_metrics
                    + self.block_ml_regression
                    + self.block_privacy
                )
        dp.Report(blocks=self.report).save(save_path)


def generate_report(
    classification_results,
    regression_results,
    dataset_summary1,
    dataset_summary2,
    col_modifications,
    cat_data,
    pipeline_timing,
    bivariate_plots,
    multivariate_plots,
):
    """
    Generates a report based on the provided data and saves it as an HTML file.

    Parameters:
    - classification_results: Classification results data.
    - regression_results: Regression results data.
    - dataset_summary1: Summary data 1.
    - dataset_summary2: Summary data 2.
    - col_modifications: Dictionary of column modifications.
    - cat_data (bool): Indicates whether the data is categorical or not.
    - pipeline_timing: Timing data for the pipeline.
    - bivariate_plots (bool): Indicates whether to include bivariate plots or not.
    - multivariate_plots (bool): Indicates whether to include multivariate plots or not.
    """
    privacy_results = yaml.load(
        open("./metrics/src/metrics/temp/privacy.yaml"), Loader=yaml.FullLoader
    )
    try:
        privacy_attack = yaml.load(
            open("./metrics/src/metrics/temp/attacks.yaml"), Loader=yaml.FullLoader
        )
    except:
        privacy_attack = None
    # Read the graphs
    correlation_graphs = (
        "./metrics/src/metrics/temp/temp-graphs/temp-correlation-original"
    )
    univariate_graphs = "./metrics/src/metrics/temp/temp-graphs/temp-univariate-original"
    if bivariate_plots:
        bivariate_graphs = "./metrics/src/metrics/temp/temp-graphs/temp-bivariate_graphs"
        bivariate_correlations = pd.read_csv(
            "./metrics/src/metrics/temp/temp-dataset/bivariate_metrics.csv"
        )
    else:
        bivariate_correlations = None
    if multivariate_plots:
        multivariate_graphs = (
            "./metrics/src/metrics/temp/temp-graphs/temp-multivariate_graphs"
        )
    privacy_graph_path = "./metrics/src/metrics/temp/dcr.png"
    privacy_graph_padded_path = "./metrics/src/metrics/temp/dcr-padded.png"
    # Privacy graph
    privacy_graph = add_padding(Image.open(privacy_graph_path), 500)
    privacy_graph.save(privacy_graph_padded_path)

    # Correlation graphs
    cor_images = []
    for i in sorted(os.listdir(correlation_graphs)):
        if i.endswith(".png"):
            cor_images.append(os.path.join(correlation_graphs, i))
    cor_images.sort()

    # Univariate graphs
    uni_images = []
    for i in os.listdir(univariate_graphs):
        if i.endswith(".png"):
            uni_images.append(os.path.join(univariate_graphs, i))

    # Bivariate graphs
    b_images = []
    if bivariate_plots:
        for i in os.listdir(bivariate_graphs):
            if i.endswith(".png"):
                b_images.append(os.path.join(bivariate_graphs, i))

    m_images = []
    if multivariate_plots:
        for i in os.listdir(multivariate_graphs):
            if i.endswith(".png"):
                m_images.append(os.path.join(multivariate_graphs, i))

    # # Combined dataframes
    if cat_data:
        dataset_cs = pd.read_csv("./metrics/src/metrics/temp/temp-dataset/cs_metric.csv")
        dataset_cat = dataset_cs.style.applymap(style_values_cs, props="")
        dataset_cat = dataset_cat.set_table_styles(
            [
                {"selector": "", "props": [("border", "2px solid black")]},
                {"selector": "td", "props": [("border", "1px solid gray")]},
                {"selector": "th", "props": [("border", "1px solid gray")]},
            ]
        )
    dataset_jsd = pd.read_csv("./metrics/src/metrics/temp/temp-dataset/jsd_metric.csv")
    dataset_wd = pd.read_csv("./metrics/src/metrics/temp/temp-dataset/wd_metric.csv")

    dataset_num = combine_dataframes([dataset_jsd, dataset_wd])
    # Table visualisation of Numerical data
    slice1_n = ["Wasserstein Distance"]
    slice2_n = ["Jensen Shannon Distance"]
    dataset_num = dataset_num.style.applymap(style_values_wd, props="", subset=slice1_n)
    dataset_num = dataset_num.applymap(style_values_jsd, props="", subset=slice2_n)
    dataset_num = dataset_num.set_table_styles(
        [
            {"selector": "", "props": [("border", "2px solid black")]},
            {"selector": "td", "props": [("border", "1px solid gray")]},
            {"selector": "th", "props": [("border", "1px solid gray")]},
        ]
    )

    # Table visualisation for ML Metrics
    if len(classification_results[2]) > 0:
        classification_ratio = []
        classification_ratio_styled = []
        for i in range(len(classification_results[2])):
            dataset_ratio = ml_metrics_ratio(
                classification_results[0][i], classification_results[1][i]
            )
            classification_ratio.append(dataset_ratio)
            dataset_ratio_styled = dataset_ratio.style.applymap(
                style_value_mlratio, props=""
            ).set_table_styles(
                [
                    {"selector": "", "props": [("border", "2px solid black")]},
                    {"selector": "td", "props": [("border", "1px solid gray")]},
                    {"selector": "th", "props": [("border", "1px solid gray")]},
                ]
            )
            classification_ratio_styled.append(dataset_ratio_styled)
    report = ReportGeneration(cat_data)
    report.block_intro_gen(pipeline_timing)
    report.block_data_summary(dataset_summary1, dataset_summary2, col_modifications)
    report.utility_gen()
    classification, regression = False, False
    if len(classification_results[2]) > 0:
        report.block_ml_classification_gen(
            classification_results, classification_ratio, classification_ratio_styled
        )
        classification = True
    if len(regression_results[2]) > 0:
        report.block_ml_regression_gen(regression_results)
        regression = True
    report.block_stat_init_gen()
    report.block_stat_num_gen(dataset_num)
    if cat_data:
        report.block_stat_cat_gen(dataset_cat)
    report.block_privacy_gen(privacy_results, privacy_attack, privacy_graph_padded_path)
    report.block_corr_graphs_gen(cor_images, False)
    report.block_corr_graphs_gen_table(cor_images, False)
    report.block_univ_graphs_gen(uni_images)
    report.block_biv_graphs_gen(b_images)
    report.block_biv_metrics_gen(bivariate_correlations)
    report.block_multiv_graphs_gen(m_images)
    report.generate_report("Report-Main.html", classification, regression)
    remove_data_pane("Report-Main.html")
    change_overflow("Report-Main.html")
    reset_temp("./metrics/src/metrics/temp")
