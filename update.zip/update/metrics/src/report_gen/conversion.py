import os
import asyncio
from pyppeteer import launch
from websockets import client


async def report_conversion():
    """
    Converts a local HTML report to a PDF document using the headless mode of a Chromium browser.

    This function uses the pyppeteer library, which is a Python port of the Puppeteer JavaScript library, 
    to control a headless Chromium browser. The browser is launched with several options for improved performance 
    and security in a server environment, and to disable unnecessary features. The function navigates to the local HTML 
    file specified, and saves it as a PDF.

    This function must be called from an asyncio event loop, as it is an asynchronous function.

    Parameters
    ----------
    None

    Returns
    -------
    None

    Raises
    ------
    pyppeteer.errors.BrowserError
        If an error occurs while launching the browser.
    pyppeteer.errors.PageError
        If an error occurs while navigating to the HTML file or generating the PDF.

    Notes
    -----
    - This function assumes that the HTML file to be converted is named 'Report-Main.html' and is located in 
    the current working directory.
    - The output PDF is saved as 'Report-Main.pdf' in the current working directory.
    """
    browser = await launch(
        options={
            "headless": True,
            "args": [
                "--no-sandbox",
                "--start-maximized",
                "--disable-setuid-sandbox",
                "--disable-dev-shm-usage",
                "--disable-accelerated-2d-canvas",
                "--no-first-run",
                "--no-zygote",
                "--single-process",
                "--disable-gpu",
                "--start-maximized",
                "--autoplay-policy=user-gesture-required",
                "--disable-background-networking",
                "--disable-background-timer-throttling",
                "--disable-backgrounding-occluded-windows",
                "--disable-breakpad",
                "--disable-client-side-phishing-detection",
                "--disable-component-update",
                "--disable-default-apps",
                "--disable-dev-shm-usage",
                "--disable-domain-reliability",
                "--disable-extensions",
                "--disable-features=AudioServiceOutOfProcess",
                "--disable-hang-monitor",
                "--disable-ipc-flooding-protection",
                "--disable-notifications",
                "--disable-offer-store-unmasked-wallet-cards",
                "--disable-popup-blocking",
                "--disable-print-preview",
                "--disable-prompt-on-repost",
                "--disable-renderer-backgrounding",
                "--disable-setuid-sandbox",
                "--disable-speech-api",
                "--disable-sync",
                "--hide-scrollbars",
                "--ignore-gpu-blacklist",
                "--metrics-recording-only",
                "--mute-audio",
                "--no-default-browser-check",
                "--no-first-run",
                "--no-pings",
                "--no-sandbox",
                "--no-zygote",
                "--password-store=basic",
                "--use-gl=swiftshader",
                "--use-mock-keychain",
            ],
        },
    )
    page = await browser.newPage()
    current_dir = os.getcwd()
    await page.goto(f"file://{current_dir}/Report-Main.html")
    # await page.screenshot({"path": "sample.png"})
    await page.pdf({"path": "Report-Main.pdf", "scale": 0.8})
    await browser.close()
