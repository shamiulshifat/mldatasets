import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn import manifold
import os
from PIL import Image

SAVE_LOCATION = "./metrics/src/metrics/temp/temp-graphs/"


class PlotMetrics:
    def __init__(
        self,
        real_data: pd.DataFrame,
        fake_data: pd.DataFrame,
        columns_metadata: dict,
        bivariate_pairs: list = [],
        multivariate_dicts: list = [],
    ) -> None:
        self.real_data = real_data
        self.fake_data = fake_data
        self.columns_metadata = columns_metadata
        self.bivariate_pairs = bivariate_pairs
        self.multivariate_dicts = multivariate_dicts
        self.categorical_cols = columns_metadata["Categorical Cols"]
        self.datetime_cols = columns_metadata["Datetime Cols"].keys()

    def plot_datetime(self, real, fake, column, filepath, fig_num):
        real_datetime = pd.DataFrame()
        fake_datetime = pd.DataFrame()
        real_datetime["ordinal"] = real
        fake_datetime["ordinal"] = fake
        range_min_start = min(real_datetime.ordinal.min(), fake_datetime.ordinal.min())
        range_max_end = max(real_datetime.ordinal.max(), fake_datetime.ordinal.max())
        step = (range_max_end + 1 - range_min_start) / 15
        # date_str = "%d.%m.%y %H:%M:%S"
        x_ticks = np.arange(range_min_start, range_max_end + 1, step)
        plt.figure(fig_num + 10, figsize=(16, 16))
        binrange = (range_min_start, range_max_end)
        range_bin_width = np.arange(
            range_min_start, range_max_end, (range_max_end - range_min_start) / 20
        )
        plot1 = sns.distplot(
            [real_datetime["ordinal"]],
            hist=True,
            bins=range_bin_width,
            color="cornflowerblue",
            hist_kws={"edgecolor": "black", "alpha": 0.4, "range": binrange},
            kde_kws={"linewidth": 2},
        )
        plot2 = sns.distplot(
            [fake_datetime["ordinal"]],
            hist=True,
            bins=range_bin_width,
            color="darkorange",
            hist_kws={"edgecolor": "black", "alpha": 0.4, "range": binrange},
            kde_kws={"linewidth": 2},
        )
        plt.legend(["real", "fake"])
        plt.xlabel(column)
        plot1.set_xticks(x_ticks)
        xlabels_dt = [pd.to_datetime(x, utc=True, unit="ns") for x in x_ticks]
        xlabels = [f"{i.day}.{i.month}.{i.year}" for i in xlabels_dt]
        print(xlabels)
        plot1.set_xticklabels(xlabels, rotation=90)
        plt.xlabel(column)
        plt.savefig(filepath, dpi=100)
        plt.clf()

        """Plotting univariate distributions for real and fake data"""

    def plot_distribution(self) -> None:
        sns.set(font_scale=2.0)
        for count, column in enumerate(self.real_data.columns):
            if column in self.datetime_cols:
                print(f"{count}: Ploting datetime object {column}")
                try:
                    self.plot_datetime(
                        self.real_data[column],
                        self.fake_data[column],
                        column,
                        f"{SAVE_LOCATION}temp-univariate-original/{count}.png",
                        count,
                    )
                except:
                    print(f"Error in plotting {column}")
            elif column not in self.categorical_cols:
                plt.figure(count + 10, figsize=(16, 16))
                binrange = (
                    min(min(self.real_data[column]), min(self.fake_data[column])),
                    max(max(self.real_data[column]), max(self.fake_data[column])),
                )
                range_bin_width = np.arange(
                    binrange[0], binrange[1], (binrange[1] - binrange[0]) / 20
                )
                sns.distplot(
                    [
                        self.real_data[column],
                    ],
                    hist=True,
                    color="cornflowerblue",
                    bins=range_bin_width,
                    hist_kws={"edgecolor": "black", "alpha": 0.4, "range": binrange},
                    kde_kws={"linewidth": 2},
                )
                sns.distplot(
                    [
                        self.fake_data[column],
                    ],
                    hist=True,
                    color="darkorange",
                    bins=range_bin_width,
                    hist_kws={"edgecolor": "gray", "alpha": 0.4, "range": binrange},
                    kde_kws={"linewidth": 2},
                )
                plt.legend(["real", "fake"])
                plt.xlabel(column)
                plt.savefig(
                    f"{SAVE_LOCATION}temp-univariate-original/{count}.png",
                    dpi=100,
                )
                plt.clf()
                print(f"{count}: {column}")
            else:
                unique_vals = self.real_data[column].unique()
                unique_vals_syn = self.fake_data[column].unique()
                real_y = self.real_data[column].value_counts()
                fake_y = self.fake_data[column].value_counts()
                if list(unique_vals) != list(unique_vals_syn):
                    data_y = pd.concat([real_y, fake_y], axis=1)
                    data_y = data_y.fillna(0)
                    data_y.columns = ["Real", "Fake"]
                    data_y.sort_index(inplace=True)
                    real_y = data_y["Real"]
                    fake_y = data_y["Fake"]
                    unique_vals = data_y.index
                X = np.arange(len(unique_vals))
                plt.figure(count + 10, figsize=(16, 16))
                if isinstance(unique_vals[0], str):
                    for i in unique_vals:
                        if len(i) > 1:
                            plt.tick_params(axis="x", rotation=90),
                axes1 = plt.bar(
                    X,
                    real_y / real_y.sum(),
                    color="cornflowerblue",
                    alpha=0.4,
                    edgecolor="gray",
                    width=0.4,
                    tick_label=unique_vals,
                )
                axes2 = plt.bar(
                    X + 0.40,
                    fake_y / fake_y.sum(),
                    color="darkorange",
                    alpha=0.4,
                    edgecolor="gray",
                    width=0.4,
                    tick_label=unique_vals,
                )
                plt.legend([axes1, axes2], ["Real", "Fake"])
                plt.xlabel(column)
                plt.ylabel("Values")
                plt.savefig(
                    f"{SAVE_LOCATION}temp-univariate-original/{count}.png",
                    dpi=100,
                )
                plt.clf()
                print(f"{count}: {column}")

    def plot_correlation_matrix(self) -> None:
        sns.set(font_scale=1.0)
        plt.figure(1, figsize=(16, 16))
        real_copy = self.real_data.copy()
        fake_copy = self.fake_data.copy()
        # Convert non numeric columns to categorical columns
        for i, column in enumerate(real_copy.columns):
            if real_copy[column].dtype == "object":
                real_copy[column] = real_copy[column].astype("category")
                real_copy[column] = real_copy[column].cat.codes
                fake_copy[column] = fake_copy[column].astype("category")
                fake_copy[column] = fake_copy[column].cat.codes
            elif real_copy[column].dtype == "datetime64[ns]":
                real_copy[column] = real_copy[column].astype("int64")
                fake_copy[column] = fake_copy[column].astype("int64")
        sns.heatmap(real_copy.corr(), cmap="Purples")
        plt.savefig(f"{SAVE_LOCATION}temp-correlation-original/1.png", dpi=100)
        plt.figure(2, figsize=(16, 16))
        sns.heatmap(fake_copy.corr(), cmap="Purples")
        plt.savefig(f"{SAVE_LOCATION}temp-correlation-original/2.png", dpi=100)
        plt.figure(3, figsize=(16, 16))
        corr_values = abs(real_copy.corr() - fake_copy.corr())
        sns.heatmap(corr_values, cmap="Purples")
        plt.savefig(f"{SAVE_LOCATION}temp-correlation-original/3.png", dpi=100)
        plt.clf()
        # corr matrix as df save fig
        corr_real = real_copy.corr()
        corr_real = corr_real.round(3)
        corr_fake = fake_copy.corr()
        corr_fake = corr_fake.round(3)
        # Get the list of column names
        cols = corr_real.columns.tolist()
        corr_real.insert(0, "Corr_Values", cols)
        corr_fake.insert(0, "Corr_Values", cols)
        fig, axs = plt.subplots(2, 1, figsize=(6, 8))
        # print(corr_real)
        for ax, df, title in zip(
            axs,
            [corr_real, corr_fake],
            ["Correlation-Real Dataset", "Correlation-Synthetic Dataset"],
        ):
            ax.axis("off")
            ax.axis("tight")
            if title == "Correlation-Real Dataset":
                bbox = [0, 0, 1, 0.9]
            else:
                bbox = [0, 0.1, 1, 0.9]
            table = ax.table(
                cellText=df.values,
                colLabels=df.columns,
                loc="center",
                bbox=bbox,
                cellLoc="center",
            )
            table.auto_set_font_size(False)
            table.set_fontsize(3)
            for cell in table.get_celld().values():
                cell.set_edgecolor("black")
                cell.set_linewidth(0.3)
            # table.auto_set_column_widths(min_column_width=1.0)
            table.auto_set_column_width(col=list(range(len(corr_real.columns))))
            ax.set_title(title)
            ax.xaxis.label.set_visible(False)
            ax.yaxis.label.set_visible(False)
        # adjust spacing between subplots
        plt.subplots_adjust(hspace=0.2)
        # save the plot as a PNG file
        plt.savefig(
            f"{SAVE_LOCATION}temp-correlation-original/4.png",
            dpi=300,
            bbox_inches="tight",
        )

    # Bivariate plots
    # Categorical Categorical Plots
    def _cor_plot(self, df, column_pair, save_path, color, title=None):
        x = df[column_pair[0]]
        y = df[column_pair[1]]
        data = []
        label = []
        for i in x.value_counts().index:
            sub_data = []
            for j in y.value_counts().index:
                label.append([i, j])
                # Number of rows where grade is i and sub_grade is j
                sub_data.append(
                    df[(df[column_pair[0]] == i) & (df[column_pair[1]] == j)].shape[0]
                )
            data.append(sub_data)
        data = np.array(data)
        heatmaps = sns.heatmap(
            data,
            xticklabels=y.value_counts().index,
            yticklabels=x.value_counts().index,
            cmap=color,
        )
        heatmaps.set_title(title)
        # SAVE THE PLOT
        plt.savefig(save_path, dpi=150)
        plt.clf()

    def categorical_categorical_plots(self, column_pair_list, plot_dir):
        df1 = self.real_data.copy()
        df2 = self.fake_data.copy()
        for column_pair in column_pair_list:
            self._cor_plot(
                df1,
                column_pair,
                plot_dir + column_pair[0] + "-" + column_pair[1] + "_1.png",
                "BuGn_r",
                "Original",
            )
            self._cor_plot(
                df2,
                column_pair,
                plot_dir + column_pair[0] + "-" + column_pair[1] + "_2.png",
                "BuPu_r",
                "Synthetic",
            )
            # Join the plots
            # Read plot 1
            plot1 = Image.open(
                plot_dir + column_pair[0] + "-" + column_pair[1] + "_1.png"
            )
            # Read plot 2
            plot2 = Image.open(
                plot_dir + column_pair[0] + "-" + column_pair[1] + "_2.png"
            )
            # Join the plots
            plot1 = np.array(plot1)
            plot2 = np.array(plot2)
            plot = np.concatenate((plot1, plot2), axis=1)
            plot = Image.fromarray(plot)
            plot.save(plot_dir + column_pair[0] + "-" + column_pair[1] + ".png")
            # Delete the plots
            os.remove(plot_dir + column_pair[0] + "-" + column_pair[1] + "_1.png")
            os.remove(plot_dir + column_pair[0] + "-" + column_pair[1] + "_2.png")

    # Categorical Continuous Plots
    def categorical_continuous_plots(self, column_pair_list, plot_dir):
        df1 = self.real_data.copy()
        df2 = self.fake_data.copy()
        df1["source"] = "Original"
        df2["source"] = "Synthetic"
        df = pd.concat([df1, df2])
        for column_pair in column_pair_list:
            sns.boxplot(
                x=column_pair[0],
                y=column_pair[1],
                hue="source",
                data=df,
                palette="Set3",
            )
            plt.savefig(
                plot_dir + column_pair[0] + "-" + column_pair[1] + ".png", dpi=150
            )
            plt.clf()

    # Continuous Continuous Plots
    def continuous_continuous_plots(self, column_pair_list, plot_dir):
        df1 = self.real_data.copy()
        df2 = self.fake_data.copy()
        df1["source"] = "Original"
        df2["source"] = "Synthetic"
        combined_dataset = pd.concat([df1, df2], axis=0)
        combined_dataset = combined_dataset.reset_index(drop=True)
        for column_pair in column_pair_list:
            sns.jointplot(
                x=column_pair[0],
                y=column_pair[1],
                data=combined_dataset,
                hue="source",
                kind="kde",
            )
            # Save the plot
            plt.savefig(
                plot_dir + column_pair[0] + "-" + column_pair[1] + ".png", dpi=150
            )
            plt.clf()

    # Multivariate Plots
    def _initialise_tsne(self, parameters):
        tsne = manifold.TSNE(
            n_components=parameters["n_components"],
            init="random",
            random_state=42,
            perplexity=parameters["perplexity"],
            learning_rate="auto",
            n_iter=parameters["n_iter"],
        )
        return tsne

    def multivariate_plot(self, column_dict, plot_dir):
        df1 = self.real_data.copy()
        df2 = self.fake_data.copy()
        # Preprocessing
        real_x = df1[column_dict["X"]].copy(deep=True)
        real_y = df1[column_dict["Y"]].copy(deep=True)

        synthetic_x = df2[column_dict["X"]].copy(deep=True)
        synthetic_y = df2[column_dict["Y"]].copy(deep=True)

        for col in column_dict["X"]:
            if col in self.categorical_cols:
                real_x[col] = real_x[col].astype("category").cat.codes
                synthetic_x[col] = synthetic_x[col].astype("category").cat.codes

        # Set up TSNE
        tsne_parameters = {"n_components": 2, "perplexity": 10, "n_iter": 300}
        real_tsne = self._initialise_tsne(tsne_parameters)
        real_z = real_tsne.fit_transform(real_x)

        synthetic_tsne = self._initialise_tsne(tsne_parameters)
        synthetic_z = synthetic_tsne.fit_transform(synthetic_x)

        # Set up plots
        tsne_real_df = pd.DataFrame()
        tsne_real_df["y"] = real_y
        tsne_real_df["comp-1"] = real_z[:, 0]
        tsne_real_df["comp-2"] = real_z[:, 1]

        tsne_synthetic_df = pd.DataFrame()
        tsne_synthetic_df["y"] = synthetic_y
        tsne_synthetic_df["comp-1"] = synthetic_z[:, 0]
        tsne_synthetic_df["comp-2"] = synthetic_z[:, 1]

        # Plot
        sns.scatterplot(
            x="comp-1", y="comp-2", hue=tsne_real_df.y.tolist(), data=tsne_real_df
        ).set(title="Original Dataset")
        plt.savefig(plot_dir + "original_dataset.png", dpi=150)
        plt.clf()

        sns.scatterplot(
            x="comp-1",
            y="comp-2",
            hue=tsne_synthetic_df.y.tolist(),
            data=tsne_synthetic_df,
        ).set(title="Synthetic Dataset")
        plt.savefig(plot_dir + "synthetic_dataset.png", dpi=150)
        plt.clf()

        # Combine plots
        plot1 = Image.open(plot_dir + "original_dataset.png")
        plot2 = Image.open(plot_dir + "synthetic_dataset.png")
        plot1 = np.array(plot1)
        plot2 = np.array(plot2)
        plot = np.concatenate((plot1, plot2), axis=1)
        plot = Image.fromarray(plot)
        save_loc = ""
        for i in column_dict["X"]:
            save_loc = save_loc + i + "-"
        save_loc = save_loc + "vs-" + column_dict["Y"] + ".png"
        plot.save(plot_dir + save_loc)
        os.remove(plot_dir + "original_dataset.png")
        os.remove(plot_dir + "synthetic_dataset.png")

    def plot_graphs(self):
        self.plot_correlation_matrix()
        self.plot_distribution()
        if len(self.bivariate_pairs) > 0:
            cat_cat_pairs = []
            cat_cont_pairs = []
            cont_cont_pairs = []
            for pair in self.bivariate_pairs:
                if (
                    pair[0] in self.columns_metadata["Categorical Cols"]
                    and pair[1] in self.columns_metadata["Categorical Cols"]
                ):
                    cat_cat_pairs.append(pair)
                elif (
                    pair[0] in self.columns_metadata["Categorical Cols"]
                    and pair[1] in self.columns_metadata["Numerical Cols"]
                ):
                    cat_cont_pairs.append(pair)
                elif (
                    pair[0] in self.columns_metadata["Numerical Cols"]
                    and pair[1] in self.columns_metadata["Categorical Cols"]
                ):
                    pair_reorder = [pair[1], pair[0]]
                    cat_cont_pairs.append(pair_reorder)
                elif (
                    pair[0] in self.columns_metadata["Numerical Cols"]
                    and pair[1] in self.columns_metadata["Numerical Cols"]
                ):
                    cont_cont_pairs.append(pair)
                else:
                    print("Invalid pair")
            if len(cat_cat_pairs) > 0:
                self.categorical_categorical_plots(
                    cat_cat_pairs, SAVE_LOCATION + "temp-bivariate_graphs/"
                )
            if len(cat_cont_pairs) > 0:
                self.categorical_continuous_plots(
                    cat_cont_pairs, SAVE_LOCATION + "temp-bivariate_graphs/"
                )
            if len(cont_cont_pairs) > 0:
                self.continuous_continuous_plots(
                    cont_cont_pairs, SAVE_LOCATION + "temp-bivariate_graphs/"
                )
        if len(self.multivariate_dicts) > 0:
            for dict in self.multivariate_dicts:
                self.multivariate_plot(
                    dict, SAVE_LOCATION + "temp-multivariate_graphs/"
                )
