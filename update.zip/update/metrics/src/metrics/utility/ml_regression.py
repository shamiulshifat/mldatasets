import pandas as pd
from sklearn.metrics import mean_absolute_percentage_error
from sklearn.linear_model import LinearRegression


class RegressionMetrics:
    """
    A class to compute and summarize regression metrics for a linear regression model on original and synthetic data.

    Methods
    -------
    __init__(self, original_data_preprocessed: dict, synthetic_data_preprocessed: dict):
        Initializes the RegressionMetrics class.
    compute(self):
        Computes the Mean Absolute Percentage Error (MAPE) on the original and synthetic data and returns the results.
    """
    def __init__(
        self, original_data_preprocessed: dict, synthetic_data_preprocessed: dict
    ) -> None:
        """
        Initializes the RegressionMetrics class.

        This method initializes the class and sets the original and synthetic preprocessed data as attributes.

        Parameters
        ----------
        original_data_preprocessed : dict
            The preprocessed original data. This should be a dictionary with keys 'X_train', 'y_train', 'X_test', and 'y_test'.
        synthetic_data_preprocessed : dict
            The preprocessed synthetic data. This should be a dictionary with keys 'X_train', 'y_train', 'X_test', and 'y_test'.
        """
        self.original_data_preprocessed = original_data_preprocessed
        self.synthetic_data_preprocessed = synthetic_data_preprocessed

    def compute(self):
        """
        Compute the Mean Absolute Percentage Error (MAPE) on the original and synthetic data and return the results.

        This method computes the MAPE of a linear regression model trained on the original and synthetic data.

        Returns
        -------
        pandas.DataFrame, pandas.DataFrame
            Two pandas DataFrames with the computed MAPE for the original and synthetic data, respectively.
        """
        # Regression model
        # Original data
        model_original_data = LinearRegression(n_jobs=-1)
        model_original_data.fit(
            self.original_data_preprocessed["X_train"],
            self.original_data_preprocessed["y_train"],
        )
        y_pred_original_data = model_original_data.predict(
            self.original_data_preprocessed["X_test"]
        )
        mape_original_data = mean_absolute_percentage_error(
            self.original_data_preprocessed["y_test"], y_pred_original_data
        )
        results_original_data = ["Linear Regression", mape_original_data]
        regression_summar_original_data = pd.DataFrame(results_original_data).T
        regression_summar_original_data.columns = ["Model", "MAPE"]
        regression_summar_original_data.set_index("Model", inplace=True)
        # Synthetic data
        model_synthetic_data = LinearRegression(n_jobs=-1)
        model_synthetic_data.fit(
            self.synthetic_data_preprocessed["X_train"],
            self.synthetic_data_preprocessed["y_train"],
        )
        y_pred_synthetic_data = model_synthetic_data.predict(
            self.synthetic_data_preprocessed["X_test"]
        )
        mape_synthetic_data = mean_absolute_percentage_error(
            self.synthetic_data_preprocessed["y_test"], y_pred_synthetic_data
        )
        results_synthetic_data = ["Linear Regression", mape_synthetic_data]
        regression_summar_synthetic_data = pd.DataFrame(results_synthetic_data).T
        regression_summar_synthetic_data.columns = ["Model", "MAPE"]
        return regression_summar_original_data, regression_summar_synthetic_data
