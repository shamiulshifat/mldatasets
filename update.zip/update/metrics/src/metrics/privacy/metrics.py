import numba as nb
import numpy as np
from typing import List
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
import yaml
import matplotlib.pyplot as plt
import seaborn as sns

from ...utils.logs import log
from metrics.src.metrics.privacy.anonymeter.evaluators import SinglingOutEvaluator
from metrics.src.metrics.privacy.anonymeter.evaluators import LinkabilityEvaluator
from metrics.src.metrics.privacy.anonymeter.evaluators import InferenceEvaluator

logger = log(name="privacy-metrics", path="./logs/", file="ml_logs.logs")


SAVE_LOCATION_RESULTS1 = "./metrics/src/metrics/temp/privacy.yaml"
SAVE_LOCATION_RESULTS2 = "./metrics/src/metrics/temp/attacks.yaml"
SAVE_LOCATION_CORRECT_QUERIES = "./metrics/src/metrics/temp/correct_queries.yaml"
SAVE_LOCATION_GRAPHS = "./metrics/src/metrics/temp/dcr.png"
SAVE_LOCATION_DF1 = "./closest_values1.csv"
SAVE_LOCATION_DF2 = "./closest_values2.csv"


@nb.njit(fastmath=True, parallel=True)
def eucl_opt(A, B):
    assert A.shape[1] == B.shape[1]
    C = np.empty((A.shape[0], B.shape[0]), A.dtype)
    I_BLK = 32
    J_BLK = 32

    # workaround to get the right datatype for acc
    init_val_arr = np.zeros(1, A.dtype)
    init_val = init_val_arr[0]

    # Blocking and partial unrolling
    # Beneficial if the second dimension is large -> computationally bound problem
    #
    for ii in nb.prange(A.shape[0] // I_BLK):
        for jj in range(B.shape[0] // J_BLK):
            for i in range(I_BLK // 4):
                for j in range(J_BLK // 2):
                    acc_0 = init_val
                    acc_1 = init_val
                    acc_2 = init_val
                    acc_3 = init_val
                    acc_4 = init_val
                    acc_5 = init_val
                    acc_6 = init_val
                    acc_7 = init_val
                    for k in range(A.shape[1]):
                        acc_0 += (
                            A[ii * I_BLK + i * 4 + 0, k] - B[jj * J_BLK + j * 2 + 0, k]
                        ) ** 2
                        acc_1 += (
                            A[ii * I_BLK + i * 4 + 0, k] - B[jj * J_BLK + j * 2 + 1, k]
                        ) ** 2
                        acc_2 += (
                            A[ii * I_BLK + i * 4 + 1, k] - B[jj * J_BLK + j * 2 + 0, k]
                        ) ** 2
                        acc_3 += (
                            A[ii * I_BLK + i * 4 + 1, k] - B[jj * J_BLK + j * 2 + 1, k]
                        ) ** 2
                        acc_4 += (
                            A[ii * I_BLK + i * 4 + 2, k] - B[jj * J_BLK + j * 2 + 0, k]
                        ) ** 2
                        acc_5 += (
                            A[ii * I_BLK + i * 4 + 2, k] - B[jj * J_BLK + j * 2 + 1, k]
                        ) ** 2
                        acc_6 += (
                            A[ii * I_BLK + i * 4 + 3, k] - B[jj * J_BLK + j * 2 + 0, k]
                        ) ** 2
                        acc_7 += (
                            A[ii * I_BLK + i * 4 + 3, k] - B[jj * J_BLK + j * 2 + 1, k]
                        ) ** 2
                    C[ii * I_BLK + i * 4 + 0, jj * J_BLK + j * 2 + 0] = np.sqrt(acc_0)
                    C[ii * I_BLK + i * 4 + 0, jj * J_BLK + j * 2 + 1] = np.sqrt(acc_1)
                    C[ii * I_BLK + i * 4 + 1, jj * J_BLK + j * 2 + 0] = np.sqrt(acc_2)
                    C[ii * I_BLK + i * 4 + 1, jj * J_BLK + j * 2 + 1] = np.sqrt(acc_3)
                    C[ii * I_BLK + i * 4 + 2, jj * J_BLK + j * 2 + 0] = np.sqrt(acc_4)
                    C[ii * I_BLK + i * 4 + 2, jj * J_BLK + j * 2 + 1] = np.sqrt(acc_5)
                    C[ii * I_BLK + i * 4 + 3, jj * J_BLK + j * 2 + 0] = np.sqrt(acc_6)
                    C[ii * I_BLK + i * 4 + 3, jj * J_BLK + j * 2 + 1] = np.sqrt(acc_7)
        # Remainder j
        for i in range(I_BLK):
            for j in range((B.shape[0] // J_BLK) * J_BLK, B.shape[0]):
                acc_0 = init_val
                for k in range(A.shape[1]):
                    acc_0 += (A[ii * I_BLK + i, k] - B[j, k]) ** 2
                C[ii * I_BLK + i, j] = np.sqrt(acc_0)

    # Remainder i
    for i in range((A.shape[0] // I_BLK) * I_BLK, A.shape[0]):
        for j in range(B.shape[0]):
            acc_0 = init_val
            for k in range(A.shape[1]):
                acc_0 += (A[i, k] - B[j, k]) ** 2
            C[i, j] = np.sqrt(acc_0)

    return C


@nb.njit()
def min_second_min(vectorA):
    first_min = np.Inf
    second_min = np.Inf
    first_min_idx = -1
    second_min_idx = -1
    for i in range(vectorA.shape[0]):
        if vectorA[i] < first_min:
            second_min = first_min
            first_min = vectorA[i]
            second_min_idx = first_min_idx
            first_min_idx = i
        elif vectorA[i] < second_min:
            second_min = vectorA[i]
            second_min_idx = i
    return first_min, second_min, first_min_idx, second_min_idx


# Original
@nb.njit(fastmath=True, parallel=True)
def dcr_and_nndr_numba(dataset1, dataset2, row_split):
    """
    This function calculates the mean closest distance and the ratio of the 
    first closest distance to the second closest one between two datasets.

    It is decorated with the numba.njit decorator for just-in-time (JIT) 
    compilation to enhance performance. The decorator parameters indicate 
    that this function should use 'fastmath' for potentially faster but less 
    precise math calculations, and 'parallel' to enable automatic parallelization 
    (multi-threading).

    Parameters
    ----------
    dataset1 : ndarray
        The first dataset, represented as a 2D numpy array.
    dataset2 : ndarray
        The second dataset, represented as a 2D numpy array.
    row_split : int
        The number of rows to process at a time. This helps manage memory 
        usage when dealing with large datasets.

    Raises
    ------
    AssertionError
        If either dataset is empty.

    Returns
    -------
    dcr : float
        The mean of the closest distances from points in dataset2 to points 
        in dataset1.
    nndr : float
        The mean of the ratios of the first nearest neighbor distance to 
        the second nearest neighbor distance for each point in dataset2 
        with respect to dataset1.
    dist_total : ndarray
        An array containing the closest distances from each point in dataset2 
        to points in dataset1.
    first_min_index : ndarray
        An array containing the index of the closest point in dataset1 for each 
        point in dataset2.
    """
    assert len(dataset2) > 0, "Synthetic dataset cannot be empty"
    assert len(dataset1) > 0, "Real dataset cannot be empty"
    nomalise_factor = np.sqrt(dataset1.shape[1])
    dist_final = np.zeros(len(dataset2) // row_split)
    ratio_final = np.zeros(len(dataset2) // row_split)
    rem = len(dataset2) % row_split
    dist = np.zeros(row_split)
    ratio = np.zeros(row_split)
    fmin_index = np.zeros(row_split)
    dist_total = np.zeros(len(dataset2))
    first_min_index = np.zeros(len(dataset2))
    splits = len(dataset2) // row_split
    splits += 1
    for ii in nb.prange(splits):
        c_dist = eucl_opt(dataset2[ii * row_split : (ii + 1) * row_split, :], dataset1)
        # Normalize the distances
        c_dist = c_dist / nomalise_factor
        for jj in range(c_dist.shape[0]):
            c_dist_temp = c_dist[jj, :]
            first_min, second_min, fmin_idx, _ = min_second_min(c_dist_temp)
            fmin_index[jj] = fmin_idx
            dist[jj] = first_min
            ratio[jj] = first_min / second_min
        if ii == splits - 1:
            dist_total[ii * row_split : ii * row_split + rem] = dist[:rem]
            first_min_index[ii * row_split : ii * row_split + rem] = fmin_index[:rem]
            dist_final[ii] = np.mean(dist[:rem])
            ratio_final[ii] = np.mean(ratio[:rem])
        else:
            dist_total[ii * row_split : (ii + 1) * row_split] = dist
            first_min_index[ii * row_split : (ii + 1) * row_split] = fmin_index
            dist_final[ii] = np.mean(dist)
            ratio_final[ii] = np.mean(ratio)
    #dcr = np.mean(dist_final) #original
    #nndr = np.mean(ratio_final) #original
    #added by shifat for temp fiz on div/0
    if len(dist_final) !=0:
        dcr = np.mean(dist_final)
    else:
        dcr=0
    if len(ratio_final) !=0:
        nndr = np.mean(ratio_final)
    else:
        nndr=0
    return dcr, nndr, dist_total, first_min_index


class PrivacyMetrics:
    """
    This class helps to compute certain privacy metrics for datasets.
    It normalizes numeric columns, preprocesses categorical columns, 
    and computes the Distance to Closest Record (DCR) and Nearest 
    Neighbor Distance Ratio (NNDR) metrics.
    """
    def __init__(
        self,
        original_train_dataset: pd.DataFrame,
        original_test_dataset: pd.DataFrame,
        synthetic_dataset: pd.DataFrame,
        categorical_cols: List[str] = None,
    ) -> None:
        """
        Initializes the PrivacyMetrics object with the training, 
        testing, and synthetic datasets.

        Parameters
        ----------
        original_train_dataset : pd.DataFrame
            The original training dataset.
        original_test_dataset : pd.DataFrame
            The original testing dataset.
        synthetic_dataset : pd.DataFrame
            The synthetic dataset generated from the training dataset.
        categorical_cols : List[str], optional
            A list of column names that are categorical. If not provided, 
            all columns are considered to be numeric.

        Returns
        -------
        None
        """
        self.original_train_dataset_archieved = original_train_dataset.copy()
        self.original_test_dataset_archieved = original_test_dataset.copy()
        self.synthetic_dataset_archieved = synthetic_dataset.copy()
        self.original_train_dataset = original_train_dataset
        self.original_test_dataset = original_test_dataset
        self.synthetic_dataset = synthetic_dataset
        self.categorical_cols = categorical_cols
        if self.categorical_cols != None or self.categorical_cols != []:
            self._preprocess_categorical_columns()
        self._normalize_columns()

    def _normalize_columns(self):
        """
        Normalizes all numeric columns in the datasets to a 0-1 range using 
        MinMaxScaler. The scaling factors are derived from the combined original 
        training and testing datasets. This ensures that the same scaling is 
        applied to all datasets.

        Returns
        -------
        None
        """
        original_data = pd.concat(
            [self.original_train_dataset, self.original_test_dataset], axis=0
        )
        for column in self.original_train_dataset_archieved.columns:
            scaler = MinMaxScaler(feature_range=(0, 1))
            scaler.fit(original_data[column].values.reshape(-1, 1))
            self.original_train_dataset[column] = scaler.transform(
                self.original_train_dataset[column].values.reshape(-1, 1)
            )
            self.original_test_dataset[column] = scaler.transform(
                self.original_test_dataset[column].values.reshape(-1, 1)
            )
            self.synthetic_dataset[column] = scaler.transform(
                self.synthetic_dataset[column].values.reshape(-1, 1)
            )
        # Convert to numpy ndarray
        self.original_train_dataset = self.original_train_dataset.to_numpy()
        self.original_test_dataset = self.original_test_dataset.to_numpy()
        self.synthetic_dataset = self.synthetic_dataset.to_numpy()
        logger.info("Data normalization completed")

    """Utility function to replace categorical values with their index"""

    def _preprocess_categorical_columns(self) -> None:
        """
        Replaces all categorical values in the dataset with their respective 
        category codes (i.e., integer indices). The pandas category data type 
        is used to convert the categorical columns to integer codes.

        Returns
        -------
        None
        """
        for column in self.categorical_cols:
            series_train = self.original_train_dataset.loc[:, column].astype("category")
            self.original_train_dataset[column] = series_train.cat.codes
            series_test = self.original_test_dataset.loc[:, column].astype("category")
            self.original_test_dataset[column] = series_test.cat.codes
            series_syn = self.synthetic_dataset.loc[:, column].astype("category")
            self.synthetic_dataset[column] = series_syn.cat.codes

    def get_closest_values(self, index_list, values, df1, df2):
        # Synthetic data or Test data = df1
        # Train data = df2
        """
        Retrieves the records from df1 and df2 that correspond to the 
        indices in index_list. Also sorts the values and returns a DataFrame.

        Parameters
        ----------
        index_list : ndarray
            The indices of the closest records.
        values : ndarray
            The corresponding distances of the closest records.
        df1 : pd.DataFrame
            The first DataFrame, typically the synthetic or test dataset.
        df2 : pd.DataFrame
            The second DataFrame, typically the original training dataset.

        Returns
        -------
        pd.DataFrame
            A DataFrame that contains the closest records from df1 and df2.
        """
        closest_values = []
        for i in range(index_list.shape[0]):
            closest_values.append([df1.iloc[i], df2.iloc[int(index_list[i])]])
        closest_values = np.array(closest_values)
        sorted_index = np.argsort(values)
        sorted_closest_values = closest_values[sorted_index]
        closest_df = []
        for i in sorted_closest_values:
            closest_df.append(i[0])
            closest_df.append(i[1])
        closest_df = pd.DataFrame(closest_df, columns=df2.columns)
        return closest_df

    def compute_metrics(self) -> None:
        """
        Computes the DCR and NNDR metrics between the training, testing, 
        and synthetic datasets. The results are logged, and histograms of 
        the distances are saved to a file.

        Returns
        -------
        None
        """
        x1 = np.random.rand(20, 2)
        x2 = np.random.rand(20, 2)
        _, _, _, _ = dcr_and_nndr_numba(
            x1, x2, 10
        )  # Code to compile jit for the first time
        # Calucalting DCR and NNDR between train and test dataset where the train data is treated as the synthetic dataset
        if len(self.original_train_dataset) < 1000:
            r_split1 = len(self.original_test_dataset)
        else:
            r_split1 = 1000
        dcr1, nndr1, dist1, dist_index1 = dcr_and_nndr_numba(
            self.original_train_dataset, self.original_test_dataset, r_split1
        )
        # zero_count1 = np.count_nonzero(dist1 == 0) # for debugging
        # logger.info(f"Debugging value-zero count of Test-Train: {zero_count1}")
        closest_values_df1 = self.get_closest_values(
            dist_index1,
            dist1,
            self.original_test_dataset_archieved,
            self.original_train_dataset_archieved,
        )
        closest_values_df1.to_csv(SAVE_LOCATION_DF1, index=False)
        # Calculating DCR and NNDR between synthetic and test dataset
        if len(self.synthetic_dataset) < 1000:
            r_split2 = len(self.synthetic_dataset)
        else:
            r_split2 = 1000
        dcr2, nndr2, dist2, dist_index2 = dcr_and_nndr_numba(
            self.original_train_dataset, self.synthetic_dataset, r_split2
        )
        # zero_count2 = np.count_nonzero(dist2 == 0) # for debugging
        # logger.info(f"Debugging value-zero count of Synthetic-Train: {zero_count2}")
        closest_values_df2 = self.get_closest_values(
            dist_index2,
            dist2,
            self.synthetic_dataset_archieved,
            self.original_train_dataset_archieved,
        )
        closest_values_df2.to_csv(SAVE_LOCATION_DF2, index=False)

        logger.info(f"DCR (Test-Train): {dcr1}")
        logger.info(f"NNDR (Test-Train): {nndr1}")

        logger.info(f"DCR (Synthetic-Train): {dcr2}")
        logger.info(f"NNDR (Synthetic-Train): {nndr2}")
        # Plotting the 2 histograms as subplots
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(20, 10))
        ax1.hist(dist1, bins=100, color="blue", alpha=0.5)
        ax1.set_xlabel("Distance", fontsize=20)
        ax1.set_ylabel("Number of Records", fontsize=20)
        ax1.set_title("DCR-Test & train dataset", fontsize=20)
        ax2.hist(dist2, bins=100, color="orange", alpha=0.5)
        ax2.set_xlabel("Distance", fontsize=20)
        ax2.set_ylabel("Number of Records", fontsize=20)
        ax2.set_title("DCR-Synthetic & train dataset", fontsize=20)
        plt.savefig(SAVE_LOCATION_GRAPHS)

        data = {
            "Data": {
                "DCR Test-Train": float(dcr1),
                "NNDR Test-Train": float(nndr1),
                "DCR Synthetic-Train": float(dcr2),
                "NNDR Synthetic-Train": float(nndr2),
            }
        }
        with open(SAVE_LOCATION_RESULTS1, "w") as outfile:
            yaml.dump(data, outfile, default_flow_style=False)


class PrivacyAttacks:
    def __init__(
        self, original_train_dataset, original_test_dataset, synthetic_dataset
    ) -> None:
        self.original_train_dataset = original_train_dataset
        self.original_test_dataset = original_test_dataset
        self.synthetic_dataset = synthetic_dataset

    def singling_out_univariate(self, num_loops=10):
        # Univariate Singling Out Attack
        train_data = self.original_train_dataset.copy()
        test_data = self.original_test_dataset.copy()
        synthetic_data = self.synthetic_dataset.copy()

        n_attacks = int(
            0.8
            * (min(train_data.shape[0], test_data.shape[0], synthetic_data.shape[0]))
        )
        logger.info(f"Number of attacks: {n_attacks}")
        # n_attacks = 5 # for debugging
        privacy_risk = []
        ci1 = []
        ci2 = []
        correct_queries = []
        for i in range(num_loops):
            evaluator_uni = SinglingOutEvaluator(
                ori=train_data,
                syn=synthetic_data,
                control=test_data,
                n_attacks=n_attacks,
            )
            evaluator_uni.evaluate("univariate")
            risk = evaluator_uni.risk()
            if risk.value != 0:
                privacy_risk.append(risk.value)
                ci1.append(risk.ci[0])
                ci2.append(risk.ci[1])
                correct_queries.extend(evaluator_uni.queries())
        self.singling_out_univariate_correct_queries = correct_queries
        self.singling_out_univariate_results = {
            "privacy_risk": float(np.mean(privacy_risk)),
            "ci1": float(np.mean(ci1)),
            "ci2": float(np.mean(ci2)),
        }
        logger.info(
            f"Singling Out Univariate Results: {self.singling_out_univariate_results}"
        )

    def singling_out_multivariate(self, num_cols, num_loops=10):
        # Multivariate Singling Out Attack
        train_data = self.original_train_dataset.copy()
        test_data = self.original_test_dataset.copy()
        synthetic_data = self.synthetic_dataset.copy()

        # n_attacks = int(0.8*(min(train_data.shape[0], test_data.shape[0], synthetic_data.shape[0])))
        n_attacks = 200
        # n_attacks = 5
        correct_queries = {}
        privacy_risk = {}
        ci1 = {}
        ci2 = {}
        for i in num_cols:
            temp_privacy_risk = []
            temp_ci1 = []
            temp_ci2 = []
            temp_correct_queries = []
            for j in range(num_loops):
                evaluator_multi = SinglingOutEvaluator(
                    ori=train_data,
                    syn=synthetic_data,
                    control=test_data,
                    n_attacks=n_attacks,
                    n_cols=i,
                )
                evaluator_multi.evaluate("multivariate")
                risk = evaluator_multi.risk()
                if risk.value != 0:
                    temp_privacy_risk.append(risk.value)
                    temp_ci1.append(risk.ci[0])
                    temp_ci2.append(risk.ci[1])
                    temp_correct_queries.extend(evaluator_multi.queries())
            correct_queries[i] = temp_correct_queries
            privacy_risk[i] = float(np.mean(temp_privacy_risk))
            ci1[i] = float(np.mean(temp_ci1))
            ci2[i] = float(np.mean(temp_ci2))
        self.singling_out_multivariate_correct_queries = correct_queries
        self.singling_out_multivariate_results = {
            "privacy_risk": privacy_risk,
            "ci1": ci1,
            "ci2": ci2,
        }
        logger.info(
            f"Singling Out Multivariate Results: {self.singling_out_multivariate_results}"
        )

    def linkability(self, num_neighbours, auxi_cols=[], num_loops=10):
        # Linkability Attack
        if auxi_cols == []:
            auxi_cols = [None, None]
            # Randomly split the columns into 2 groups
            auxi_cols[0] = np.random.choice(
                self.original_train_dataset.columns,
                int(len(self.original_train_dataset.columns) / 2),
                replace=False,
            )
            auxi_cols[1] = np.setdiff1d(
                self.original_train_dataset.columns, auxi_cols[0]
            )
            auxi_cols = [list(auxi_cols[0]), list(auxi_cols[1])]
        train_data = self.original_train_dataset.copy()
        test_data = self.original_test_dataset.copy()
        synthetic_data = self.synthetic_dataset.copy()

        n_attacks = int(
            0.8
            * (min(train_data.shape[0], test_data.shape[0], synthetic_data.shape[0]))
        )
        # n_attacks = 5
        privacy_risk = {}
        ci1 = {}
        ci2 = {}
        # Set the keys to the number of neighbours and values to empty lists
        for i in num_neighbours:
            privacy_risk[i] = []
            ci1[i] = []
            ci2[i] = []
        for i in range(num_loops):
            evaluator_link = LinkabilityEvaluator(
                ori=train_data,
                syn=synthetic_data,
                control=test_data,
                n_attacks=n_attacks,
                aux_cols=auxi_cols,
                n_neighbors=num_neighbours[0],
            )
            evaluator_link.evaluate(n_jobs=-1)
            for j in num_neighbours:
                risk = evaluator_link.risk(n_neighbors=j)
                privacy_risk[j].append(risk.value)
                ci1[j].append(risk.ci[0])
                ci2[j].append(risk.ci[1])
        for i in num_neighbours:
            privacy_risk[i] = float(np.mean(privacy_risk[i]))
            ci1[i] = float(np.mean(ci1[i]))
            ci2[i] = float(np.mean(ci2[i]))
        self.linkability_results = {
            "privacy_risk": privacy_risk,
            "ci1": ci1,
            "ci2": ci2,
        }
        logger.info(f"Linkability Results: {self.linkability_results}")

    def inference(self, num_loops=10):
        # Inference Attack
        train_data = self.original_train_dataset.copy()
        test_data = self.original_test_dataset.copy()
        synthetic_data = self.synthetic_dataset.copy()

        n_attacks = int(
            0.8
            * (min(train_data.shape[0], test_data.shape[0], synthetic_data.shape[0]))
        )
        # n_attacks = 5
        columns = train_data.columns
        privacy_risk = np.zeros(len(columns))
        ci1 = np.zeros(len(columns))
        ci2 = np.zeros(len(columns))
        for i in range(num_loops):
            privacy_risk_temp = []
            ci_1_temp = []
            ci_2_temp = []
            for secret in columns:
                aux_cols = [col for col in columns if col != secret]
                evaluator_inf = InferenceEvaluator(
                    ori=train_data,
                    syn=synthetic_data,
                    control=test_data,
                    aux_cols=aux_cols,
                    secret=secret,
                    n_attacks=n_attacks,
                )
                evaluator_inf.evaluate(n_jobs=-1)
                risk = evaluator_inf.risk()
                privacy_risk_temp.append(risk.value)
                ci_1_temp.append(risk.ci[0])
                ci_2_temp.append(risk.ci[1])
            privacy_risk += np.array(privacy_risk_temp)
            ci1 += np.array(ci_1_temp)
            ci2 += np.array(ci_2_temp)
        privacy_risk = privacy_risk / num_loops
        ci1 = ci1 / num_loops
        ci2 = ci2 / num_loops
        # Convert the numpy arrays to lists
        privacy_risk = privacy_risk.tolist()
        ci1 = ci1.tolist()
        ci2 = ci2.tolist()
        columns = list(columns)
        self.inference_results = {
            "privacy_risk": privacy_risk,
            "ci1": ci1,
            "ci2": ci2,
            "columns": columns,
        }
        logger.info(f"Inference Results: {self.inference_results}")

    def curate_results(self, attack_parameters):
        # Curate the results
        results = {}
        if attack_parameters["singling_out_univariate"] == True:
            results["singling_out_univariate"] = self.singling_out_univariate_results
        if attack_parameters["singling_out_multivariate"] == True:
            results[
                "singling_out_multivariate"
            ] = self.singling_out_multivariate_results
        if attack_parameters["linkability"] == True:
            results["linkability"] = self.linkability_results
        if attack_parameters["inference"] == True:
            results["inference"] = self.inference_results
        logger.info(results)
        if results != {}:
            logger.info("Saving results")
            with open(SAVE_LOCATION_RESULTS2, "w") as outfile:
                yaml.dump(results, outfile, default_flow_style=False)

    def save_correct_queries(self):
        # Save the correct queries
        correct_queries = {}
        correct_queries[
            "singling_out_univariate"
        ] = self.singling_out_univariate_correct_queries
        correct_queries[
            "singling_out_multivariate"
        ] = self.singling_out_multivariate_correct_queries
        # logger.info(correct_queries)
        with open(SAVE_LOCATION_CORRECT_QUERIES, "w") as outfile:
            yaml.dump(correct_queries, outfile, default_flow_style=False)

    def compute_results(self, attack_parameters):
        # Linkability
        if attack_parameters["linkability"] == True:
            self.linkability(
                num_neighbours=attack_parameters["linkability_params"][
                    "num_neighbours"
                ],
                auxi_cols=attack_parameters["linkability_params"]["auxi_cols"],
                num_loops=attack_parameters["linkability_params"]["num_loops"],
            )
        # Singling Out Univariate
        if attack_parameters["singling_out_univariate"] == True:
            self.singling_out_univariate(
                num_loops=attack_parameters["singling_out_univariate_params"][
                    "num_loops"
                ]
            )
        # Singling Out Multivariate
        if attack_parameters["singling_out_multivariate"] == True:
            self.singling_out_multivariate(
                num_cols=attack_parameters["singling_out_multivariate_params"][
                    "num_cols"
                ],
                num_loops=attack_parameters["singling_out_multivariate_params"][
                    "num_loops"
                ],
            )
        # Inference
        if attack_parameters["inference"] == True:
            self.inference(num_loops=attack_parameters["inference_params"]["num_loops"])
        # Curate the results
        self.curate_results(attack_parameters)
