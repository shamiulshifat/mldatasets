import numpy as np
import pandas as pd
from sklearn.preprocessing import OneHotEncoder, StandardScaler, LabelEncoder
from sklearn.compose import ColumnTransformer
from sklearn.model_selection import train_test_split


class MetricsDataPrep(object):
    """
    A class to handle preprocessing steps for various metrics calculations.

    ...

    Attributes
    ----------
    categorical_columns : list
        A list of names of the categorical columns in the dataset.
    continuous_columns : list
        A list of names of the continuous columns in the dataset.
    log_columns : list
        A list of names of the columns in the dataset that need log transformation.
    mixed_columns : dict
        A dictionary of column names (keys) and corresponding information (values) that contain both categorical and continuous data.
    general_columns : list
        A list of names of the columns that are to be treated as general columns. These columns are encoded using label encoding if
        they are categorical, and are modeled by a single Gaussian distribution if they are continuous by the synthetic data generator.
    integer_columns : list
        A list of names of the integer columns in the dataset.
    datetime_columns : dict
        A dictionary of column names (keys) and corresponding datetime formats (values).
    drop_columns : list
        A list of names of the columns to be dropped from the dataset.
    categorical_threshold : int
        The maximum number of unique values a categorical column can have.
    unique_percentage : float, default=0.9
        The maximum ratio of unique values to total rows a column can have before being dropped.

    Methods
    -------
    drop_cols(df: pd.DataFrame) -> pd.DataFrame:
        Removes the columns specified in self.drop_columns from the dataframe df and updates the attribute lists accordingly.

    generate_columns_types():
        Generates a dictionary of column types, which is useful for further preprocessing steps.

    remove_large_categorical_columns(df: pd.DataFrame, threshold: int=50, unique_percentage: float=0.9) -> pd.DataFrame:
        Removes categorical columns with too many unique values from df. If unique_counts / total_rows > unique_percentage, the column is dropped.
        Otherwise the column is modified depending on the number of unique values it has. If the number of unique values is greater than threshold,
        only the top threshold values are kept and the rest are dropped.

    prep_datetime(original: pd.DataFrame, synthetic: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
        Converts the datetime columns to integers in both original and synthetic dataframes.

    general_preprocessing(original: pd.DataFrame, synthetic: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
        Performs general preprocessing steps including dropping columns, removing large categorical columns, preparing datetime columns, and generating column types.

    statistical_binning(original: pd.DataFrame, synthetic: pd.DataFrame, divisions: int=10) -> Tuple[pd.DataFrame, pd.DataFrame]:
        Applies statistical binning on numerical and datetime columns of the original and synthetic dataframes.

    statistical_encoding(original: pd.DataFrame, synthetic: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
        Performs label encoding on all columns of the original and synthetic dataframes.

    statistical_preprocessing(original: pd.DataFrame, synthetic: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
        Performs statistical binning and encoding on the original and synthetic dataframes.

    ml_encoding(original: pd.DataFrame, synthetic: pd.DataFrame, categorical_columns: List, numerical_columns: List) -> Tuple[pd.DataFrame, pd.DataFrame]:
        Applies one-hot encoding to the categorical columns and standard scaling to the numerical columns of the original and synthetic dataframes.

    ml_date_split(df1_x: pd.DataFrame, df1_y: pd.DataFrame, df2_x: pd.DataFrame, df2_y: pd.DataFrame) -> Tuple[Dict, Dict]:
        Splits the provided dataframes into training and testing datasets.

    ml_preprocessing(original: pd.DataFrame, synthetic: pd.DataFrame, target: str) -> Tuple[Dict, Dict]:
        Prepares the original and synthetic dataframes for machine learning, including encoding, scaling, and splitting the data.
    """

    def __init__(
        self,
        categorical: list,
        continuous: list,
        log: list,
        mixed: dict,
        general: list,
        integer: list,
        datetime: dict,
        drop_columns: list,
        categorical_threshold: int,
        unique_percentage: float = 0.9,
    ):
        self.categorical_columns = categorical
        self.continuous_columns = continuous
        self.log_columns = log
        self.mixed_columns = mixed
        self.general_columns = general
        self.integer_columns = integer
        self.datetime_columns = datetime
        self.drop_columns = drop_columns
        self.categorical_threshold = categorical_threshold
        self.unique_percentage = unique_percentage

    def drop_cols(self, df):
        """
        *************
        NOTE: THIS FUNCTION IS ALSO PRESENT IN THE CODE MODULE. IF YOU MAKE ANY CHANGES HERE, PLEASE MAKE SURE TO REFLECT THEM THERE AS WELL.
        *************
        """
        # Check if the columns to be dropped are present in the other lists
        for column in self.drop_columns:
            if column in self.categorical_columns:
                self.categorical_columns.remove(column)
            if column in self.continuous_columns:
                self.continuous_columns.remove(column)
            if column in self.log_columns:
                self.log_columns.remove(column)
            if column in self.mixed_columns.keys():
                del self.mixed_columns[column]
            if column in self.general_columns:
                self.general_columns.remove(column)
            if column in self.integer_columns:
                self.integer_columns.remove(column)
            if column in self.datetime_columns.keys():
                del self.datetime_columns[column]

        # Drop the columns
        df.drop(self.drop_columns, axis=1, inplace=True)
        return df

    def generate_columns_types(self):
        self.column_types = dict()
        self.column_types["Categorical Cols"] = []
        self.column_types["Integer Cols"] = []
        self.column_types["Numerical Cols"] = []
        self.column_types["Datetime Cols"] = {}

        self.column_types["Categorical Cols"].extend(self.categorical_columns)
        self.column_types["Integer Cols"].extend(self.integer_columns)
        self.column_types["Numerical Cols"].extend(self.continuous_columns)
        for cols in self.mixed_columns.keys():
            self.column_types["Numerical Cols"].append(cols)
        self.column_types["Datetime Cols"] = self.datetime_columns

    def remove_large_categorical_columns(self, df, threshold=50, unique_percentage=0.9):
        """
        *************
        NOTE: THIS FUNCTION IS ALSO PRESENT IN THE CODE MODULE. IF YOU MAKE ANY CHANGES HERE, PLEASE MAKE SURE TO REFLECT THEM THERE AS WELL.
        *************
        """
        removed_categorical_cols = []
        self.cols_with_removed_rows = {}
        for col in self.categorical_columns:
            unique_counts = df[col].nunique()
            if unique_counts > threshold and col not in self.general_columns:
                if unique_counts / df.shape[0] > unique_percentage:
                    removed_categorical_cols.append(col)
                    df.drop(col, inplace=True, axis=1)
                else:
                    # Remove rows that have unique values with low frequency and keep the top {threshold} values
                    top_values = df[col].value_counts().index[:threshold]
                    df = df[df[col].isin(top_values)]
                    self.cols_with_removed_rows[col] = [len(top_values), unique_counts]
        self.categorical_columns = list(
            set(self.categorical_columns) - set(removed_categorical_cols)
        )
        return df

    def prep_datetime(self, original, synthetic):
        """
        *************
        NOTE: THIS FUNCTION IS ALSO PRESENT IN THE CODE MODULE. IF YOU MAKE ANY CHANGES HERE, PLEASE MAKE SURE TO REFLECT THEM THERE AS WELL.
        *************
        """
        for col, format in self.datetime_columns.items():
            original[col] = pd.to_datetime(original[col], format=format)
            original[col] = original[col].astype(int)
            synthetic[col] = pd.to_datetime(synthetic[col], format=format)
            synthetic[col] = synthetic[col].astype(int)
        return original, synthetic

    def general_preprocessing(self, original, synthetic):
        original = self.drop_cols(original)
        original = self.remove_large_categorical_columns(
            original,
            threshold=self.categorical_threshold,
            unique_percentage=self.unique_percentage,
        )
        original, synthetic = self.prep_datetime(original, synthetic)
        self.generate_columns_types()
        return original, synthetic

    # Used for stat preprocessing
    def statistical_binning(self, original, synthetic, divisions=10):
        bin_columns = self.column_types["Numerical Cols"] + list(
            self.column_types["Datetime Cols"].keys()
        )
        for column in bin_columns:
            bin_min_max = (
                min(min(original[column]), min(synthetic[column])),
                max(max(original[column]), max(synthetic[column])),
            )
            steps = (bin_min_max[1] - bin_min_max[0]) / divisions
            bins = [bin_min_max[0] + steps * i for i in range(divisions + 1)]
            original[column] = pd.cut(original[column], bins=bins, include_lowest=True)
            synthetic[column] = pd.cut(
                synthetic[column], bins=bins, include_lowest=True
            )
        return original, synthetic

    def statistical_encoding(self, original, synthetic):
        for column in original.columns:
            # Label encoding
            le = LabelEncoder()
            col_data = pd.concat([original[column], synthetic[column]], axis=0)
            le.fit(col_data)
            original[column] = le.transform(original[column])
            synthetic[column] = le.transform(synthetic[column])
        return original, synthetic

    def statistical_preprocessing(self, original, synthetic):
        original, synthetic = self.statistical_binning(original, synthetic)
        original, synthetic = self.statistical_encoding(original, synthetic)
        return original, synthetic

    # Used for ML preprocessing
    def ml_encoding(self, original, synthetic, categorical_columns, numerical_columns):
        categorical_preprocessor = OneHotEncoder(handle_unknown="ignore")
        numerical_preprocessor = StandardScaler()
        if len(categorical_columns) != 0:
            categorical_cols_index = [
                original.columns.get_loc(col) for col in categorical_columns
            ]
        else:
            categorical_cols_index = []
        if len(numerical_columns) != 0:
            numerical_cols_index = [
                original.columns.get_loc(col) for col in numerical_columns
            ]
        else:
            numerical_cols_index = []
        preprocessor = ColumnTransformer(
            [
                ("one-hot-encoder", categorical_preprocessor, categorical_cols_index),
                ("standard-scaler", numerical_preprocessor, numerical_cols_index),
            ]
        )
        original = preprocessor.fit_transform(original)
        synthetic = preprocessor.transform(synthetic)
        return original, synthetic

    def ml_date_split(self, df1_x, df1_y, df2_x, df2_y):
        df1_x_train, x_test, df1_y_train, y_test = train_test_split(
            df1_x, df1_y, random_state=42, test_size=0.1
        )
        df1_data = {
            "X_train": df1_x_train,
            "X_test": x_test,
            "y_train": df1_y_train,
            "y_test": y_test,
        }
        df2_data = {
            "X_train": df2_x,
            "X_test": x_test,
            "y_train": df2_y,
            "y_test": y_test,
        }
        return df1_data, df2_data

    def ml_preprocessing(self, original, synthetic, target):
        original_x = original.drop(target, axis=1)
        original_y = original[target]
        synthetic_x = synthetic.drop(target, axis=1)
        synthetic_y = synthetic[target]
        if target in self.column_types["Categorical Cols"]:
            categorical_columns = [
                col for col in self.column_types["Categorical Cols"] if col != target
            ]
            numerical_columns = self.column_types["Numerical Cols"]
        elif target in self.column_types["Numerical Cols"]:
            categorical_columns = self.column_types["Categorical Cols"]
            numerical_columns = [
                col for col in self.column_types["Numerical Cols"] if col != target
            ]
        else:
            raise ValueError("Target column not found in dataset")
        original_x, synthetic_x = self.ml_encoding(
            original_x, synthetic_x, categorical_columns, numerical_columns
        )
        if target in self.column_types["Categorical Cols"]:
            # Label encoding
            le = LabelEncoder()
            le.fit(original_y)
            original_y = le.transform(original_y)
            synthetic_y = le.transform(synthetic_y)
        elif target in self.column_types["Numerical Cols"]:
            # Standard scaling
            ss = StandardScaler()
            ss.fit(original_y.values.reshape(-1, 1))
            original_y = ss.transform(original_y.values.reshape(-1, 1))
            synthetic_y = ss.transform(synthetic_y.values.reshape(-1, 1))
        original_data, synthetic_data = self.ml_date_split(
            original_x, original_y, synthetic_x, synthetic_y
        )
        return original_data, synthetic_data
