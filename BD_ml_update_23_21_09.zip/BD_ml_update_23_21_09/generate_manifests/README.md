This directory contains:
1. report_gen directory: This is responsoble for making an automated workflow sequence as train > generate > metrics all together one by one sequentially.
2. YAML files: These are the manifests for Argo generate sensors to deploy Betterdata's inference model.

## File Description:
1. gen_eventsource.yaml : This script create an webhook that connect with argo generate sensor. So it exposes anapi endpoint which we use on ML fastapi server to trigger a generate workflow.
2. gen_sensor_gpu.yaml : This is he sensor script for Argo generate workflow for gpu based deployment.
3. gen_sensor.yaml : This is he sensor script for Argo generate workflow.