This directory contains:
1. image directory: This directory contains main train codes, dockerfile and requirements.txt.
2. YAML files: These are the manifests for Argotrain sensors to deploy Betterdata's train model.

## File Description:
1. train_eventsource.yaml : This script create an webhook that connect with argo train sensor. So it exposes anapi endpoint which we use on ML fastapi server to trigger a train workflow.
2. train_sensor_gpu.yaml : This is the sensor script for Argo train workflow for gpu based deployment.
3. train_sensor.yaml : This is the sensor script for Argo train workflow.
4. train_sensor_priority.yaml : This is the sensor script for Argo train workflow but it will be treaed as priority on argo to be deployed as early as possible than other pending jobs.
5. train_sensor_priority_gpu.yaml : This is the sensor script for Argo train workflow for gpu but it will be treated as priority on argo to be deployed as early as possible than other pending jobs.
6. train_eventsource_priority.yaml : This script create an webhook that connect with argo train priority sensor. So it exposes an api endpoint which we use on ML fastapi server to trigger a priority train workflow.