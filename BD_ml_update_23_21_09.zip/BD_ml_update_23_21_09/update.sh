#!/bin/bash
docker image build -t ml_engine_v2:232109 .
docker tag ml_engine_v2:232109 localhost:5000/ml_engine_v2:232109
docker push localhost:5000/ml_engine_v2:232109
microk8s kubectl apply -f ./train_manifests/train_sensor.yaml -n argo --validate=false
microk8s kubectl apply -f ./generate_manifests/gen_sensor.yaml -n argo --validate=false
microk8s kubectl apply -f ./metrics_manifests/metrics_sensor.yaml -n argo --validate=false