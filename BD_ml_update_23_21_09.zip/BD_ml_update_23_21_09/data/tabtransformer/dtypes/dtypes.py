"""Data types definition."""

import enum
import numbers
from datetime import datetime, timedelta
from typing import Any, Union

import pandas as pd

_datetime = datetime
_timedelta = timedelta


class RawDType(enum.Enum):
    """Raw data types in a tabular DataFrame."""

    non_std = enum.auto()
    """
    Non-standard types. These will never be converted fully to numerical data without information loss.
    They typically include highly unique values such as IDs, names, emails, etc.
    """
    categorical = enum.auto()
    """Categorical types, including binary and multi-class, 
    and categorical values represented as non-string format (e.g. numbers)."""
    numerical = enum.auto()
    """Numerical types, including int and float."""
    datetime = enum.auto()
    """Date-time types."""
    timedelta = enum.auto()
    """Time-delta types."""
    mixed = enum.auto()
    """Mixture of some of the other types, excluding `encoding` and `non_std`."""
    encoding = enum.auto()
    """Encoding data type, to fetch data by matching some public information in a dataset."""

    @property
    def base_value(self) -> Union[int, str, _datetime, _timedelta]:
        """
        Base value of the data type.

        - If this is numerical, the base value is 0.
        - If this is datetime, the base value is base unix time, 1970-01-01 00:00:00.
        - If this is timedelta, the base value is 0s.
        - All other types will have base value as an empty string.
        """
        if self == RawDType.numerical:
            return 0
        elif self == RawDType.datetime:
            return datetime(1970, 1, 1)
        elif self == RawDType.timedelta:
            return timedelta(0)
        return ""

    @property
    def base_type(self) -> type:
        """
        The smallest comprehensive default Python type that this RawDType accepts.

        - If this is numerical, the base type is `numbers.Number`.
        - If this is datetime, the base type is `datetime.datetime`.
        - If this is timedelta, the base type is `datetime.timedelta`.
        - Otherwise, we accept `str` (but not necessarily so).
        """
        if self == RawDType.numerical:
            return numbers.Number
        elif self == RawDType.datetime:
            return datetime
        elif self == RawDType.timedelta:
            return timedelta
        return str

    def is_valid_dtype(self, dtype: str) -> bool:
        """
        Check if a pandas dtype is a valid representation for the current raw data type.

        Parameters
        ----------
        dtype : str
            The result of `.dtype` of `pd.Series` converted to a string.

        Returns
        -------
        bool
            True if the pandas dtype is a valid representation for the current raw data type.
        """
        dtype = dtype.lower()
        if self == RawDType.categorical:
            return dtype in {"categorical", "str", "object", "boolean"}
        elif self == RawDType.numerical:
            return any(dtype.startswith(x) for x in ["int", "float", "double", "uint"])
        elif self == RawDType.datetime:
            return dtype.startswith("datetime") or dtype.startswith("<M8")
        elif self == RawDType.timedelta:
            return dtype.startswith("timedelta") or dtype.startswith("<m8")
        return True

    @property
    def default_dtype(self) -> str:
        """
        Default pandas data type for each of the raw types.

        - Default type for numerical is `float64`.
        - Default type for datetime is `datetime64[ns]`.
        - Default type for timedelta is `timedelta64[ns]`.
        - Default type for encoding is `str`.
        - Default type for all other types is `object`.
        """
        if self == RawDType.numerical:
            return "float64"
        elif self == RawDType.datetime:
            return "datetime64[ns]"
        elif self == RawDType.timedelta:
            return "timedelta64[ns]"
        elif self == RawDType.encoding:
            return "str"
        return "object"

    @property
    def continuous(self) -> bool:
        """Whether this raw data type is continuous (that is, whether it is numerical, datetime, or timedelta)."""
        return self in {RawDType.numerical, RawDType.datetime, RawDType.timedelta}

    def cast(self, value: str) -> Any:
        """
        Cast a string value to the type.
        We will mainly rely on pandas default convertors (
        [`to_numeric`](https://pandas.pydata.org/docs/reference/api/pandas.to_numeric.html),
        [`to_datetime`](https://pandas.pydata.org/docs/reference/api/pandas.to_datetime.html), and
        [`to_timedelta`](https://pandas.pydata.org/docs/reference/api/pandas.to_timedelta.html))
        without additional arguments to do the type-casting.
        For non-continuous types, we will maintain the input as it is.

        Parameters
        ----------
        value : str
            The value to convert.

        Returns
        -------
        Any
            The converted data.
        """
        if self == RawDType.numerical:
            return pd.to_numeric(value)
        if self == RawDType.datetime:
            return pd.to_datetime(value)
        if self == RawDType.timedelta:
            return pd.to_timedelta(value)
        return value


class SType(enum.Enum):
    """
    Standardized data types.
    By "standard" we mean that the data type is a commonly seen data type for ML.
    """

    non_std = enum.auto()
    """
    Non-standard types. These will never be converted to numerical data. They typically come from the part that 
    cannot be standardized from non-standard `RawDType`.
    """
    binary = enum.auto()
    """Binary standardized type. At most two values are present in this standardized column."""
    multiclass = enum.auto()
    """Multiclass type. This standardized column is treated as multi-class categorical."""
    numerical = enum.auto()
    """Numerical type. This standardized column in treated as continuous numerical value."""

    @property
    def pd_dtype(self) -> str:
        """Corresponding pandas data type."""
        if self == SType.numerical:
            return "float64"
        return "object"


class ColumnName(str):
    """Column name data types, by default it is string."""
