"""
Tabular data transformation pipeline.

[code](https://github.com/betterdataai/data) |
[guide](https://www.notion.so/betterdataai/Documentation-e1bcc76662ef41d6a39071e92739f79d)
"""

import logging

from .column import ColumnTransformer
from .table import TableTextualizer, TableTransformer
from .utils import initialize_pool, log


__all__ = (
    "ColumnTransformer",
    "TableTransformer",
    "TableTextualizer",
    "initialize_pool",
)


logging.addLevelName(log.TRACE_LEVEL, "TRACE")
