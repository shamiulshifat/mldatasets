"""Miscellaneous utility functions that are not grouped."""

import enum
from typing import Any, Collection, Dict, Union


def register(base: Dict[Union[str, enum.Enum], Any], name: Union[str, enum.Enum]):
    """
    Register a class or function to a dictionary.

    Parameters
    ----------
    base : dict[str/enum, cls/func]
        The base dictionary to register the class or function at.
    name : str/enum
        The key to save this class or function to.
    """
    def _decorator(value: Any):
        base[name] = value
        return value
    return _decorator


def find_special_category(base_value: str, all_values: Collection[str]) -> str:
    """
    Find a special category that is not present in the dataset.

    Parameters
    ----------
    base_value : str
        The special category if it does not appear in the dataset.
    all_values : Collection[str]
        The dataset of all categories.

    Return
    ------
    str
        The special category.
        If `base_value` is found in `all_values`, the result is `base_value` concatenated with some integer.
    """
    special_value = base_value
    all_values = {*all_values}
    if special_value in all_values:
        base = 0
        while f"{special_value}{base}" in all_values:
            base += 1
        special_value = f"{special_value}{base}"
    return special_value


class _GlobalVariableInEnum:
    def __init__(self, value: Any):
        self._value = value

    def __get__(self, *args, **kwargs):
        return self._value
