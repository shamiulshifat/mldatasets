"""Utility functions for multi-processing."""

import logging
import multiprocessing as mp
from functools import partial
from typing import Any, Callable, Dict, Iterable, List, Literal, Optional, Union


_pool: Optional[mp.Pool] = None


def _func_wrapper(*args, func: Callable, **kwargs) -> Any:
    try:
        return func(*args, **kwargs)
    except BaseException as e:
        logging.error(e)
        return None


def initialize_pool(n_processes: int = 10):
    """
    Initialize pool for multiprocessing.

    Parameters
    ----------
    n_processes : int
        Number of processes to run in parallel. Default is 10.
    """
    global _pool
    _pool = mp.Pool(processes=n_processes)


def iterate_over_list(func: Callable,
                      *iterable: Iterable,
                      kwargs_iterable: Optional[Iterable] = None,
                      sequential_allowed: bool = True,
                      auto_init: Optional[int] = None,
                      chunk_size: int = 1,
                      return_format: Literal["none", "list", "dict"] = "list",
                      return_dict_keys: Union[int, str, Iterable] = 0,
                      **global_kwargs) -> Optional[Union[Dict, List]]:
    """
    Iterate over a list by multiprocessing.

    Parameters
    ----------
    func : Callable
        The function to apply to each item in the list.
    *iterable : Iterable, optional
        The lists to iterate over.
    kwargs_iterable : Iterable, optional
        The list of dict of additional key-word arguments.
    sequential_allowed : bool
        Whether to throw error if pool is not yet initialized.
    auto_init : int, optional
        If provided, we will automatically initialize a pool with this number of processes if it is not yet initialized.
    chunk_size : int
        The number of items to process in each process.
    return_format : "none", or "list", or "dict"
        The return format of the result.
        If "none", we do not return anything.
        If "list", a list where items are the results of the `func` will be returned.
        If "dict", a list where values are the results of the `func` will be returned.
    return_dict_keys : int, or str, or Iterable
        The keys to return if return_format is "dict".
        If int is given, the value at the corresponding iterable is used. For example, calling with
        `iterate_over_list(func, keys, values, return_format="dict", return_dict_keys=0)` will return a dict with keys
        coming from `keys`.
        If str is given, the value with this key at kwargs_iterable is used.
        If Iterable is used, this iterable itself provide the keys.
    **global_kwargs
        Arguments that is not changing and given to all calls of func in the list.

    Return
    ------
    None, or list, or dict
        The mapped result constructed, depending on the return_format.

    Raise
    -----
    RuntimeError
        If sequential is not allowed and pool is not initialized.
    """
    if auto_init is not None:
        initialize_pool(auto_init)
    if not sequential_allowed and _pool is None:
        raise RuntimeError("Pool is not initialized.")
    func = partial(func, **global_kwargs)
    if kwargs_iterable is None:
        if len(iterable) > 0:
            kwargs_iterable = [{} for _ in iterable[0]]
        else:
            kwargs_iterable = []
    args_iterable = [
        (args, kwargs) for args, kwargs in
        zip(zip(*iterable), kwargs_iterable)
    ]
    key_iterable = return_dict_keys
    if return_format == "dict":
        if isinstance(return_dict_keys, int):
            key_iterable = iterable[return_dict_keys]
        elif isinstance(return_dict_keys, str):
            key_iterable = [item[return_dict_keys] for item in kwargs_iterable]
    if _pool is None:
        results = []
        for args, kwargs in args_iterable:
            results.append(func(*args, **kwargs))
    else:
        func = partial(_func_wrapper, func=func)
        results = _pool.imap(func, args_iterable, chunksize=chunk_size)
        results = [*results]
    if return_format == "none":
        return None
    if return_format == "list":
        return results
    if return_format == "dict":
        dict_result = {}
        for k, v in zip(key_iterable, results):
            dict_result[k] = v
        return dict_result
    raise NotImplementedError(f"Return format {return_format} is not recognized.")


def iterate_over_dict(func: Callable,
                      dictionary: Dict[str, Any],
                      sequential_allowed: bool = False,
                      auto_init: Optional[int] = 10,
                      chunk_size: int = 1,
                      func_take_key: bool = False,
                      input_format: Literal["single", "args", "kwargs"] = "single",
                      return_format: Literal["none", "list", "dict"] = "list",
                      return_dict_keys: Optional[Union[int, str, Iterable]] = None,
                      **global_kwargs) -> Optional[Union[Dict, List]]:
    """
    Iterate over a list by multiprocessing.

    Parameters
    ----------
    func : Callable
        The function to apply to each item in the list.
    dictionary : dict
        The dictionary to iterate over.
    sequential_allowed : bool
        Whether to throw error if pool is not yet initialized.
    auto_init : int, optional
        If provided, we will automatically initialize a pool with this number of processes if it is not yet initialized.
    chunk_size : int
        The number of items to process in each process.
    func_take_key : bool
        Whether the function takes in the key.
        If set True, key is given as the first argument to func.
    input_format : "single", or "args", or "kwargs"
        The way of interpreting dictionary values.
        If "single", the value itself is used as input to `func`.
        If "args", the value is the argument tuple to `func`.
        If "kwargs", the value is key-word arguments to `func`.
    return_format : "none", or "list", or "dict"
        The return format of the result.
        If "none", we do not return anything.
        If "list", a list where items are the results of the `func` will be returned.
        If "dict", a list where values are the results of the `func` will be returned.
    return_dict_keys : int, or str, or Iterable, optional
        The keys to return if return_format is "dict".
        If int is given, the value at the corresponding iterable is used. For example, calling with
        `iterate_over_list(func, keys, values, return_format="dict", return_dict_keys=0)` will return a dict with keys
        coming from `keys`.
        If str is given, the value with this key at kwargs_iterable is used.
        If Iterable is used, this iterable itself provide the keys.
        If not provided, the keys from input dictionary is used.
    **global_kwargs
        Arguments that is not changing and given to all calls of func in the list.

    Return
    ------
    None, or list, or dict
        The mapped result constructed, depending on the return_format.

    Raise
    -----
    RuntimeError
        If sequential is not allowed and pool is not initialized.
    """
    if return_dict_keys is None:
        return_dict_keys = dictionary.keys()
    elif isinstance(return_dict_keys, int):
        if input_format != "args":
            raise ValueError(f"Integer return dict keys cannot be used on input format {input_format}.")
        return_dict_keys = [v[return_dict_keys] for v in dictionary.values()]
    iterate_wrapper = partial(iterate_over_list, func, sequential_allowed=sequential_allowed, chunk_size=chunk_size,
                              return_format=return_format, return_dict_keys=return_dict_keys,
                              **global_kwargs)
    if input_format == "single":
        if func_take_key:
            return iterate_wrapper(dictionary.keys(), dictionary.values())
        else:
            return iterate_wrapper(dictionary.values())
    elif input_format == "args":
        values = map(list, zip(*dictionary.values()))
        if func_take_key:
            return iterate_wrapper(dictionary.keys(), *values)
        else:
            return iterate_wrapper(*values)
    elif input_format == "kwargs":
        if func_take_key:
            return iterate_wrapper(dictionary.keys(), kwargs_iterable=dictionary.values())
        else:
            return iterate_wrapper(kwargs_iterable=dictionary.values())

