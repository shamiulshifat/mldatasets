"""Data loader for Py-Torch."""

from typing import Collection, Optional, Union

import pandas as pd
from torch.utils.data import DataLoader, DistributedSampler, RandomSampler, SequentialSampler

from .collator import TableCollator
from .dataset import PandasDataset
from .sampler import DistributedImbalanceSampler, ImbalanceSampler
from ..table import TableTransformer


class TableDataLoader(DataLoader):
    """
    Data loader designed for this data pipeline, essentially inherited from
    [`DataLoader`](https://pytorch.org/docs/stable/data.html#torch.utils.data.DataLoader).
    """
    def __init__(self,
                 data: Union[Union[str, pd.DataFrame], Collection[str]],
                 transformer: TableTransformer,
                 collator: Optional[TableCollator] = None,
                 shuffle: bool = True,
                 distributed: bool = False,
                 imbalance: bool = True,
                 **kwargs):
        """
        Initialize a dataloader for the table data.
        Arguments are inherited from
        [`PandasDataset`](/tabtransformer/pytorch/dataset#tabtransformer.pytorch.dataset.PandasDataset),
        [`DataLoader`](https://pytorch.org/docs/stable/data.html#torch.utils.data.DataLoader),
        [`ImbalanceSampler`](/tabtransformer/pytorch/sampler#tabtransformer.pytorch.sampler.ImbalanceSampler), and
        [`TableCollator`](/tabtransformer/pytorch/collator#tabtransformer.pytorch.collator.TableCollator).

        Other Parameters
        ----------------
        collator : TableCollator, optional
            If not provided, will use TableCollator(transformer).
        distributed : bool
            Whether the training is done on distributed environment.
            We will construct a sampler accordingly.
        imbalance : bool
            Whether to use imbalance sampler for log frequencies in each categorical column.
        """
        if collator is None:
            collator = TableCollator(transformer)
        dataloader_kwarg_names = {
            "batch_size", "batch_sampler", "num_workers",
            "pin_memory", "drop_last", "timeout", "worker_init_fn", "multiprocessing_context",
            "generator", "prefetch_factor", "persistent_workers", "pin_memory_device"
        }
        sampler_kwarg_names = {"smoothing", "binary_frequency"}
        dataset_kwargs = {
            k: v for k, v in kwargs.items()
            if k not in dataloader_kwarg_names | sampler_kwarg_names
        }
        loader_kwargs = {
            k: v for k, v in kwargs.items()
            if k in dataloader_kwarg_names
        }
        sampler_kwargs = {
            k: v for k, v in kwargs.items()
            if k in sampler_kwarg_names
        }
        dataset = PandasDataset(data, **dataset_kwargs)

        if imbalance:
            if distributed:
                sampler = DistributedImbalanceSampler(
                    dataset,
                    transformer=transformer,
                    **sampler_kwargs,
                    drop_last=loader_kwargs.get("drop_last", False)
                )
            else:
                sampler = ImbalanceSampler(
                    dataset,
                    transformer=transformer,
                    **sampler_kwargs,
                )
        else:
            if distributed:
                sampler = DistributedSampler(
                    dataset,
                    shuffle=shuffle,
                    drop_last=loader_kwargs.get("drop_last", False)
                )
            else:
                if shuffle:
                    sampler = RandomSampler(
                        dataset,
                        generator=loader_kwargs.get("generator")
                    )
                else:
                    sampler = SequentialSampler(dataset)
        super().__init__(
            dataset=dataset,
            collate_fn=collator.collate,
            sampler=sampler,
            **loader_kwargs
        )
