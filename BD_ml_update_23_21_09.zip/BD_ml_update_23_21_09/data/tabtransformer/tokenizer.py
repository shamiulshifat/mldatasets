"""
Tokenizer for textualizer.
Extended from HuggingFace Tokenizers.
"""
import math
import re
from datetime import timedelta
from typing import Any, Collection, Dict, List, Literal, Optional, Set, Tuple, Union

import numpy as np
import pandas as pd
import torch
from transformers import AutoTokenizer, BatchEncoding, PreTrainedTokenizer, PreTrainedModel

from .dtypes import ColumnName, RawDType, learn_forced_dtypes, learn_raw_dtype_for_textualizer
from .utils import make_list


class TabularDataTokenizer:
    """
    Tokenizer for tabular data, with special tokens for tabular data specifically.
    """
    def __init__(self,
                 tokenizer: Union[str, PreTrainedTokenizer] = "distilgpt2",
                 num_columns: int = 20,
                 num_categories: int = 20,
                 max_small_integer: int = 99,
                 exponent_range: Union[int, Tuple[int, int]] = 20,
                 n_essential_digits: int = 2,
                 use_special_token_only: bool = True,
                 in_cell_pad_token: Optional[str] = "<|pad|>",
                 mask_token: Optional[str] = "<|mask|>",
                 cell_sep_token: str = "<|sep-cell|>",
                 row_sep_token: Optional[str] = "<|sep-row|>",
                 kv_sep_token: Optional[str] = "<|sep-kv|>",
                 nan_token: Optional[str] = "<|nan|>",
                 col_token_format: str = "<|col-{}|>",
                 cat_token_format: str = "<|cat-{}|>",
                 pos_token: Optional[str] = "<|pos|>",
                 neg_token: Optional[str] = "<|neg|>",
                 int_token_format: str = "<|int-{}|>",
                 exp_token_format: str = "<|exp-{}|>",
                 essential_digit_token_format: str = "<|dig-{}|>",
                 mantissa_token_format: Optional[str] = "<|man-{}|>",
                 year_token: Optional[str] = "<|year|>",
                 month_token: Optional[str] = "<|month|>",
                 day_token: Optional[str] = "<|day|>",
                 hour_token: Optional[str] = "<|hour|>",
                 minute_token: Optional[str] = "<|minute|>",
                 second_token: Optional[str] = "<|second|>",
                 microsecond_token: Optional[str] = "<|microsecond|>",
                 weekday_token: Optional[str] = "<|weekday|>",
                 am_pm_token: Optional[str] = "<|am-pm|>",
                 day_of_year_token: Optional[str] = "<|day-of-yr|>",
                 wkno_token: Optional[str] = "<|wk-num|>",
                 tz_token: Optional[str] = "<|tz|>"):
        """
        Initialize a tokenizer for tabular data.

        Parameters
        ----------
        tokenizer : PreTrainedTokenizer, or str
            Tokenizer from Hugging Face
            (or the tokenizer's corresponding model name to load by AutoTokenizer.from_pretrained).
        num_columns : int
            Number of columns to textualize column names.
            If the column names are used instead of special tokens for column names, the value can be set to 0.
        num_categories : int
            Maximum number of categories in the data.
            If the actual value (in textual format) of the categorical values are used to textualize the tabular data,
            the value can be 0.
        max_small_integer : int
            For small integers as tokens, the largest small integer (in terms of absolute value).
            If no small integer is used, the value can be negative (e.g. -1).
            Do take note that if you are not using the raw value to tokenize datetime and timedelta,
            make sure the value here covers needed values for denoting the datetime/timedelta.
            For example, years are cut into two parts to denote, so if some datetime column has year 2008, then the
            smallest possible value here is 20, and if there is another year 2030, the smallest possible value here is
            30. And if some minutes are varying, make sure this value is no smaller than 59 to cover all possible
            minutes.
        exponent_range : int, or (int, int)
            The exponent range in scientific representation of all numerical values.
            For example, 3.5e-8 has the exponent -8.
            The range should ideally cover all numerical values that are to be represented by
            scientific notation factorization.
            If one value is given, the range used is the absolute range (-M, M).
            This range is inclusive of the two boundaries.
            If the textualization is not using scientific notation factorization, the range can be set to -1.
        n_essential_digits : int
            In the scientific notation factorization, we separate the first few digits in mantissa as essential, given
            special tokens to it. This parameter sets the number of digits that are considered essential.
            There will be ten to the power of this value number of special tokens for these essential digits.
            If the textualization is not using scientific notation factorization, the value can be set to 0.
        use_special_token_only : bool
            Whether this tokenizer only uses special tokens that we added.
            If so, tokens originally in the tokenizer will never appear in the result, so we will subtract the
            resultant token ID values by the size of the original tokenizer to save some vocabulary size.
            Do be careful when setting this to true by verifying:

            1. All special tokens you provide are not originally in the tokenizer.
            2. The way you textualize the data does not make use of any tokens outside the special tokens we added.
               For example, scientific notation factorization is used for numerical value, column names will be
               represented using special columns instead of the raw column name, etc.
        in_cell_pad_token : str, optional
            The pad token of the tokenizer. It can be (and actually suggested to be if use_special_token_only is set
            True) different from the pad token originally set in the tokenizer.
            If no padding in-cell is used, it can be None.
        mask_token : str, optional
            The mask token of the tokenizer. It can be (and actually suggested to be if use_special_token_only is set
            True) different from the pad token originally set in the tokenizer.
            If no masking is used at any time, it can be None.
        cell_sep_token : str
            The separator token that separates different cells in a row.
        row_sep_token : str, optional
            The separator token that separates different rows.
            If the textualization never applies to multiple rows, this parameter can be None.
        kv_sep_token : str, optional
            The separator token that separates the column name from cell value.
            If special tokens for column names are used instead of raw column names, this parameter can be None.
        nan_token : str, optional
            The special token for nan values.
            If there are no nan values, or the raw text "nan" or otherwise is used to represent the nan values,
            this parameter can be None.
        col_token_format : str
            The special token for column names format. "{}" will be replaced by column indices.
        cat_token_format : str
            The special token for categorical values format. "{}" will be replaced by category indices.
        pos_token : str
            The special token for positive (including 0) sign (for scientific notation factorization).
            It can be None of scientific notation factorization is not used.
        neg_token : str
            The special token for negative sign (for scientific notation factorization).
            It can be None of scientific notation factorization is not used.
        int_token_format : str
            The special token for small integer format. "{}" will be replaced by the integer value.
        exp_token_format : str
            The special token for exponent format. "{}" will be replaced by exponent values.
        essential_digit_token_format : str
            The special token for essential digits of mantissa format. "{}" will be replaced by the values for the
            essential digits.
        mantissa_token_format : str, optional
            The special token for non-essential mantissa digit format. "{}" will be replaced by 0-9 as mantissa digits.
            It can be None of scientific notation factorization is not used.
        year_token : str, optional
            The special token indicating year in datetime.
            It can be None if no datetime is to be represented by non-raw format.
        month_token : str, optional
            The special token indicating month in datetime.
            It can be None if no datetime is to be represented by non-raw format.
        day_token : str, optional
            The special token indicating day in datetime.
            It can be None if no datetime is to be represented by non-raw format.
        hour_token : str, optional
            The special token indicating hour in datetime.
            It can be None if no datetime is to be represented by non-raw format.
        minute_token : str, optional
            The special token indicating minute in datetime.
            It can be None if no datetime is to be represented by non-raw format.
        second_token : str, optional
            The special token indicating second in datetime.
            It can be None if no datetime is to be represented by non-raw format.
        microsecond_token : str, optional
            The special token indicating microsecond in datetime.
            It can be None if no datetime is to be represented by non-raw format.
        weekday_token : str, optional
            The special token indicating weekday in datetime.
            It can be None if the weekday is never used in auxiliary to non-raw format of datetime textualization.
        am_pm_token : str, optional
            The special token indicating AM or PM in datetime.
            It can be None if the AM/PM notation is never used in auxiliary to non-raw format of datetime textualization.
        day_of_year_token : str, optional
            The special token indicating day of the year in datetime.
            It can be None if the day of the year is never used in auxiliary to non-raw format of datetime textualization.
        wkno_token : str, optional
            The special token indicating week number in datetime.
            It can be None if the week number is never used in auxiliary to non-raw format of datetime textualization.
        tz_token : str, optional
            The special token indicating timezone in datetime.
            It can be None if the timezone is never used in auxiliary to non-raw format of datetime textualization.
        """
        if isinstance(tokenizer, str):
            tokenizer = AutoTokenizer.from_pretrained(tokenizer)
        self.tokenizer = tokenizer

        new_tokens = []
        self._special_offset = len(tokenizer)
        offset = self._special_offset
        offset, self.in_cell_pad_token, self._in_cell_pad_token_id = self._update_special_token(offset,
                                                                                                in_cell_pad_token)
        self._cell_sep_token_id = offset
        self.cell_sep_token = cell_sep_token
        offset += 1
        offset, self.row_sep_token, self._row_sep_token_id = self._update_special_token(offset, row_sep_token)
        offset, self.kv_sep_token, self._kv_sep_token_id = self._update_special_token(offset, kv_sep_token)
        offset, self.nan_token, self._nan_token_id = self._update_special_token(offset, nan_token)
        new_tokens += [self.in_cell_pad_token, self.cell_sep_token, self.row_sep_token, self.kv_sep_token, self.nan_token]
        self._col_offset = offset
        new_tokens += [
            col_token_format.format(i)
            for i in range(num_columns)
        ]
        self.num_columns = num_columns
        self._col_token_format = col_token_format
        offset += num_columns
        self._cat_offset = offset
        new_tokens += [
            cat_token_format.format(i)
            for i in range(num_categories)
        ]
        self.num_categories = num_categories
        self._cat_token_format = cat_token_format
        offset += num_categories
        offset, self.pos_token, self._pos_token_id = self._update_special_token(offset, pos_token)
        offset, self.neg_token, self._neg_token_id = self._update_special_token(offset, neg_token)
        new_tokens += [self.pos_token, self.neg_token]
        self._int_offset = offset
        new_tokens += [
            int_token_format.format(i)
            for i in range(max_small_integer + 1)
        ]
        self.max_small_integer = max_small_integer
        self._int_token_format = int_token_format
        offset += max(0, max_small_integer + 1)
        if isinstance(exponent_range, Collection):
            min_exp, max_exp = exponent_range
        else:
            min_exp, max_exp = -exponent_range, exponent_range
        self._min_exp = min_exp
        self._max_exp = max_exp
        self.has_exponent = max_exp >= min_exp
        self._exp_offset = offset
        new_tokens += [
            exp_token_format.format(exp)
            for exp in range(min_exp, max_exp + 1)
        ]
        self._exp_token_format = exp_token_format
        offset += max(0, max_exp - min_exp + 1)
        self._essential_digit_offset = offset
        n_essential_digit_tokens = int(10 ** n_essential_digits)
        if n_essential_digit_tokens < 10:
            n_essential_digit_tokens = 0
        new_tokens += [
            essential_digit_token_format.format(num)
            for num in range(n_essential_digit_tokens)
        ]
        self._essential_digit_token_format = essential_digit_token_format
        offset += n_essential_digit_tokens
        self._n_essential_digits = n_essential_digits
        self._mantissa_offset = offset
        if mantissa_token_format is not None:
            new_tokens += [
                mantissa_token_format.format(num)
                for num in range(10)
            ]
            offset += 10
        self._mantissa_token_format = mantissa_token_format
        offset, self.year_token, self._year_token_id = self._update_special_token(offset, year_token)
        offset, self.month_token, self._month_token_id = self._update_special_token(offset, month_token)
        offset, self.day_token, self._day_token_id = self._update_special_token(offset, day_token)
        offset, self.hour_token, self._hour_token_id = self._update_special_token(offset, hour_token)
        offset, self.minute_token, self._minute_token_id = self._update_special_token(offset, minute_token)
        offset, self.second_token, self._second_token_id = self._update_special_token(offset, second_token)
        offset, self.microsecond_token, self._microsecond_token_id = self._update_special_token(offset,
                                                                                                microsecond_token)
        offset, self.weekday_token, self._weekday_token_id = self._update_special_token(offset, weekday_token)
        offset, self.am_pm_token, self._am_pm_token_id = self._update_special_token(offset, am_pm_token)
        offset, self.day_of_year_token, self._day_of_year_token_id = self._update_special_token(offset,
                                                                                                day_of_year_token)
        offset, self.wkno_token, self._wkno_token_id = self._update_special_token(offset, wkno_token)
        offset, self.tz_token, self._tz_token_id = self._update_special_token(offset, tz_token)
        new_tokens += [
            year_token, month_token, day_token, hour_token, minute_token, second_token, microsecond_token,
            weekday_token, am_pm_token, day_of_year_token, wkno_token, tz_token
        ]

        new_tokens = [
            x for x in new_tokens
            if x is not None and " " not in x
        ]
        self.tokenizer.add_special_tokens({
            "additional_special_tokens": new_tokens,
        }, replace_additional_special_tokens=False)
        if mask_token is not None:
            self.tokenizer.add_special_tokens({
                "mask_token": mask_token
            })
        self.mask_token = mask_token
        self.pad_token = self.tokenizer.eos_token if self.tokenizer.pad_token_id is None \
            else self.tokenizer.pad_token

        self._use_special_token_only = use_special_token_only
        if use_special_token_only:
            self._vocab_size = len(new_tokens)
            for attr_name in dir(self):
                if attr_name.endswith("_token_id") or \
                        (attr_name.endswith("_offset") and not attr_name == "_special_offset"):
                    orig_val = getattr(self, attr_name)
                    if orig_val is not None:
                        setattr(self, attr_name, orig_val - self._special_offset)
        else:
            self._vocab_size = len(self.tokenizer)

    @staticmethod
    def _update_special_token(offset: int, token: Optional[str]) -> Tuple[int, Optional[str], Optional[int]]:
        if token is not None and " " not in token:
            token_id = offset
            offset += 1
        else:
            token_id = None
        return offset, token, token_id

    def update_model(self, model: PreTrainedModel):
        """
        Update the Hugging Face model with the new vocabulary.

        Parameters
        ----------
        model : PreTrainedModel
            The Hugging Face model to adapt the vocab size on.
        """
        model.resize_token_embeddings(self._vocab_size)

    def encode(self, *args, **kwargs) -> List[int]:
        """
        Inherited from PreTrainedTokenizer.
        """
        result = self.tokenizer.encode(*args, **kwargs)
        if self._use_special_token_only:
            result = [x - self._special_offset for x in result]
        return result

    def decode(self,
               token_ids: Union[List[int], torch.Tensor],
               *args, **kwargs) -> str:
        """
        Inherited from PreTrainedTokenizer.
        """
        if self._use_special_token_only:
            if isinstance(token_ids, List):
                token_ids = [x + self._special_offset for x in token_ids]
            else:
                token_ids += self._special_offset
        result = self.tokenizer.decode(token_ids, *args, **kwargs)
        return result

    def tokenize(self, *args, **kwargs) -> List[str]:
        """
        Inherited from PreTrainedTokenizer.
        """
        return self.tokenizer.tokenize(*args, **kwargs)

    def de_tokenize(self, tokens: List[str]) -> str:
        """
        Inverse the tokenize step.

        Parameters
        ----------
        tokens : list[str]
            The list of tokens to combine.

        Returns
        -------
        str
            The combined text.
        """
        ids = self.tokenizer.convert_tokens_to_ids(tokens)
        return self.tokenizer.decode(ids)

    def __call__(self, *args, **kwargs) -> BatchEncoding:
        """
        Inherited from PreTrainedTokenizer.
        """
        result = self.tokenizer(*args, **kwargs)
        if self._use_special_token_only:
            for key in ["labels", "input_ids"]:
                if key in result:
                    if isinstance(result[key][0], int):
                        result[key] = [x - self._special_offset for x in result[key]]
                    else:
                        result[key] = [[x - self._special_offset for x in sent] for sent in result[key]]
        return result

    def get_column_token(self, index: int) -> str:
        """
        Construct the column token for the column with the given index.

        Parameters
        ----------
        index : int
            The column index.

        Returns
        -------
        str
            The token for this column name.

        Raises
        ------
        KeyError
            If the column index is out of scope.
        """
        if index >= self.num_columns:
            raise KeyError(f"Column index {index} is out of the range of allowed number of columns.")
        return self._col_token_format.format(index)

    def get_category_token(self, index: int) -> str:
        """
        Construct the column token for the category with the given index.

        Parameters
        ----------
        index : int
            The category index.

        Returns
        -------
        str
            The token for this category.

        Raises
        ------
        KeyError
            If the category index is out of scope.
        """
        if index >= self.num_categories:
            raise KeyError(f"Category index {index} is out of the range of allowed number of categories.")
        return self._cat_token_format.format(index)

    def check_column_token(self, token: str) -> Tuple[int, bool]:
        """
        Check the column token and extract the index.

        Parameters
        ----------
        token : str
            The token to check whether it is a valid column name token.

        Returns
        -------
        int
            The index of the column, if it is valid, otherwise -1 is returned.
        bool
            Whether the given token is a valid column name token.
        """
        pattern = re.escape(self._col_token_format).replace('\\{\\}', r'(?P<index>\d+)')
        match = re.fullmatch(pattern, token)
        if match:
            index_value = int(match.group('index'))
            if not (0 <= index_value < self.num_columns):
                return np.nan, False
            return index_value, True
        else:
            return np.nan, False

    def check_category_token(self, token: str) -> Tuple[int, bool]:
        """
        Check the category token and extract the index.

        Parameters
        ----------
        token : str
            The token to check whether it is a valid category token.

        Returns
        -------
        int
            The index of the category, if it is valid, otherwise -1 is returned.
        bool
            Whether the given token is a valid category token.
        """
        pattern = re.escape(self._cat_token_format).replace('\\{\\}', r'(?P<index>\d+)')
        match = re.fullmatch(pattern, token)
        if match:
            index_value = int(match.group('index'))
            if not (0 <= index_value < self.num_categories):
                return np.nan, False
            return index_value, True
        else:
            return np.nan, False

    def factorize_scientific_notation(self, x: Union[int, float], include_sign: bool = True) -> str:
        """
        Use scientific notation factorization tokenization for numeric value and convert to the corresponding text.

        Parameters
        ----------
        x : float, or int
            The value to convert.
        include_sign : bool
            Whether to include sign.

        Returns
        -------
        str
            The converted textual data.
        """
        if include_sign:
            sign = self.pos_token if x >= 0 else self.neg_token
        else:
            sign = ""
        x = abs(x)
        if x == 0:
            exponent = 0
            mantissa = "0"
        else:
            exponent = math.floor(math.log10(x))
            mantissa = str(x).replace(".", "").strip("0")
        if not (self._min_exp <= exponent <= self._max_exp):
            raise ValueError(f"The exponent {exponent} for {x} is out of range.")
        exponent = self._exp_token_format.format(exponent)
        if len(mantissa) < self._n_essential_digits:
            mantissa = mantissa + "0" * (self._n_essential_digits - len(mantissa))
        if self._n_essential_digits > 0:
            essential_digits = self._essential_digit_token_format.format(int(mantissa[:self._n_essential_digits]))
        else:
            essential_digits = ""
        remaining_mantissa = mantissa[self._n_essential_digits:]
        non_essential_digits = []
        for d in remaining_mantissa:
            non_essential_digits.append(self._mantissa_token_format.format(int(d)))
        non_essential_digits = "".join(non_essential_digits)
        return f"{sign}{exponent}{essential_digits}{non_essential_digits}"

    def defactorize_scientific_notation(self, x: str, including_sign: bool = True) -> Tuple[float, bool]:
        """
        Reversely tokenize the scientific notation factorization of numeric value and convert back to the value.

        Parameters
        ----------
        x : str
            The textual format of the scientific notation factorization result.
        including_sign : bool
            Whether the string contains information about sign.

        Returns
        -------
        float
            The value recovered.
        bool
            Whether the value is valid.
        """
        exp_pattern = re.escape(self._exp_token_format).replace('\\{\\}', '(?P<exp>-?\\d+)')
        mantissa_pattern = "(?P<mantissa>(?:{mantissa_format})*)".format(
            mantissa_format=re.escape(self._mantissa_token_format).replace('\\{\\}', '(\\d)')
        )
        if self._n_essential_digits > 0:
            essential_pattern = re.escape(self._essential_digit_token_format)\
                .replace('\\{\\}', '(?P<essential>\\d{{1,{x}}})').format(x=self._n_essential_digits)
        else:
            essential_pattern = ""
        pattern = f"{exp_pattern}{essential_pattern}{mantissa_pattern}"
        if including_sign:
            pattern = r"(?P<sign>{pos}|{neg})".format(
                pos=re.escape(self.pos_token),
                neg=re.escape(self.neg_token)
            ) + pattern
        match = re.fullmatch(pattern, x)
        if not match:
            return np.nan, False
        sign_val = 1
        if including_sign:
            sign_val = 1 if match.group("sign") == self.pos_token else -1
        exponent = int(match.group("exp"))
        if not self._min_exp <= exponent <= self._max_exp:
            return np.nan, False
        number_string = ""
        if self._n_essential_digits > 0:
            essential_digits = match.group("essential")
            number_string = essential_digits
            number_string += "0" * (self._n_essential_digits - len(essential_digits))
        mantissa_matches = re.findall(re.escape(self._mantissa_token_format).replace('\\{\\}', '(\\d)'),
                                      match.group("mantissa"))
        number_string += "".join(mantissa_matches)
        if number_string == "":
            number_string = "0"
        first_val = sign_val * int(number_string[0])
        sci_string = f"{first_val}.{number_string[1:]}e{exponent}"
        return float(sci_string), True

    def denote_small_integer(self, x: int, include_sign: bool = True) -> str:
        """
        Convert small integer value to the corresponding text.

        Parameters
        ----------
        x : int
            The value to convert.
        include_sign : bool
            Whether to include sign.

        Returns
        -------
        str
            The converted textual data.
        """
        if include_sign:
            sign = self.pos_token if x >= 0 else self.neg_token
        else:
            sign = ""
        x = abs(x)
        if x > self.max_small_integer:
            raise ValueError(f"The small integer with absolute value {x} is out of range.")
        value = self._int_token_format.format(x)
        return f"{sign}{value}"

    def revert_small_integer(self, x: str, including_sign: bool = True, group_digits: Optional[int] = None,
                             n_groups: Optional[int] = None) -> \
            Tuple[int, bool]:
        """
        Recover small integer to the original value.

        Parameters
        ----------
        x : str
            The textual format small integer.
        including_sign : bool
            Whether the string contains information about sign.
        group_digits : int, optional
            If provided, multiple small integer tokens in a row are allowed.
            Each token correspond to this number of digits (so, for example, the value for this parameter is 2, and the
            small integer value extracted from a token inside is 9, it actually means 09).
        n_groups : int, optional
            Limit the number of groups to exactly matching the value.

        Returns
        -------
        float
            The value recovered.
        bool
            Whether the value is valid.
        """
        pattern = ""
        if including_sign:
            pattern += r'(?P<sign>{pos}|{neg})?'.format(
                pos=re.escape(self.pos_token),
                neg=re.escape(self.neg_token)
            )

        int_pattern = re.escape(self._int_token_format).replace('\\{\\}', '(?P<intval>\\d+)')
        if group_digits:
            pattern += f'(?:{int_pattern})+'
        else:
            pattern += int_pattern

        match = re.fullmatch(pattern, x)
        if not match:
            return np.nan, False

        sign_val = 1
        if including_sign:
            sign = match.group('sign')
            if sign is None:
                return np.nan, False
            sign_val = 1 if sign == self.pos_token else -1

        int_matches = re.findall(int_pattern, x)
        if n_groups is not None:
            if len(int_matches) != n_groups:
                return np.nan, False
        int_matches = [int(match) for match in int_matches]
        if not all(0 <= val <= self.max_small_integer for val in int_matches):
            return np.nan, False
        digits = group_digits if group_digits else 0
        int_str = "".join([str(match).zfill(digits) for match in int_matches])
        return sign_val * int(int_str), True

    @classmethod
    def great_tokenizer_args(cls) -> Dict[str, Any]:
        """
        Get the tokenizer arguments for GReaT.

        Returns
        -------
        dict
            The arguments to construct the tokenizer that is identical to GReaT setup.
        """
        return dict(
            tokenizer="distilgpt2",
            num_columns=0,
            num_categories=0,
            max_small_integer=-1,
            exponent_range=-1,
            n_essential_digits=0,
            use_special_token_only=False,
            in_cell_pad_token="<|endoftext|>",
            mask_token=None,
            cell_sep_token=", ",
            row_sep_token=None,
            kv_sep_token=" is ",
            nan_token="None",
            pos_token=None,
            neg_token=None,
            mantissa_token_format=None,
            year_token=None,
            month_token=None,
            day_token=None,
            hour_token=None,
            minute_token=None,
            second_token=None,
            microsecond_token=None,
            weekday_token=None,
            am_pm_token=None,
            day_of_year_token=None,
            wkno_token=None,
            tz_token=None
        )

    @classmethod
    def learn_minimum_tokenizer_args(cls,
                                     data: pd.DataFrame,
                                     use_raw_column_name: bool = False,
                                     use_raw_data: bool = False,
                                     drop_columns: Optional[List[ColumnName]] = None,
                                     categorical_columns: Optional[List[ColumnName]] = None,
                                     numerical_columns: Optional[List[ColumnName]] = None,
                                     datetime_columns: Optional[List[ColumnName]] = None,
                                     timedelta_columns: Optional[List[ColumnName]] = None,
                                     mixed_columns: Optional[List[ColumnName]] = None,
                                     encoding_columns: Optional[List[ColumnName]] = None,
                                     non_std_columns: Optional[List[ColumnName]] = None,
                                     unique_threshold: float = .95,
                                     encoding_threshold: int = 200,
                                     max_small_integer: int = 99,
                                     use_scientific_notation_factorization: bool = True,
                                     pad_in_cell: bool = True,
                                     allow_mask: bool = True,
                                     group_size: int = 1,
                                     include_weekday: bool = True,
                                     include_am_pm: bool = False,
                                     include_day_of_year: bool = False,
                                     include_week_number: bool = False,
                                     include_timezone: bool = True,
                                     wkno_as_small_integers: bool = False,
                                     include_all_params: bool = True) -> Dict[str, Any]:
        """
        Learn the arguments for the given data that has minimum vocab for the tokenizer.

        Parameters
        ----------
        data : pd.DataFrame
            The input data.
        use_raw_column_name : bool, optional
            Whether to use raw column name, or to use the special column tokens.
        use_raw_data : bool, optional
            Whether to always use raw data.
        drop_columns : list[str], optional
            Columns to be dropped. They do not need kwargs.
        categorical_columns : list[str], optional
            Columns specified to be treated as categorical columns.
        numerical_columns : list[str], optional
            Columns specified to be treated as numerical columns.
        datetime_columns : list[str], optional
            Columns specified to be treated as datetime columns.
        timedelta_columns : list[str], optional
            Columns specified to be treated as timedelta columns.
        mixed_columns : list[str], optional
            Columns mixing either numerical, datetime, or timedelta (exactly one of them) with some special strings
            (each recognized as a category).
        encoding_columns : list[str], optional
            Columns that has some encodings describing its information and can be matched back by nearest neighbors.
            Such columns include countries, cities, companies, etc.
        non_std_columns : list[str], optional
            Non-standard columns. Columns cannot be grouped into the above five types.
            For example, ID, name, email, etc.
        unique_threshold : float, optional
            After removing N/A values in the column, if the number of unique non-continuous values divided by
            the number of rows hit this threshold, this column will be treated as non-standard. Default is 0.95.
        encoding_threshold : int, optional
            If the number of different categories (besides N/A) is greater or equal to this value, and we do not hit
            the unique threshold above, we will treat it as encoding. Default is 200.
        max_small_integer : int, optional
            For small integers as tokens, the largest small integer (in terms of absolute value).
            If no small integer is used, the value can be negative (e.g. -1).
            Do take note that if you are not using the raw value to tokenize datetime and timedelta,
            make sure the value here covers needed values for denoting the datetime/timedelta.
            For example, years are cut into two parts to denote, so if some datetime column has year 2008, then the
            smallest possible value here is 20, and if there is another year 2030, the smallest possible value here is
            30. And if some minutes are varying, make sure this value is no smaller than 59 to cover all possible
            minutes.
            This value may be overriden if there are requirements from datetime or timedelta.
        use_scientific_notation_factorization : bool, optional
            Whether to use scientific notation factorization during textualization.
        pad_in_cell : bool, optional
            Whether to pad the data inside each cell during textualization.
        allow_mask : bool, optional
            Whether to allow the use of mask during textualization.
        group_size : int, optional
            The number of rows per sentence grouped together.
        include_weekday : bool, optional
            Whether weekday information is included after textualization.
        include_am_pm : bool, optional
            Whether AM/PM information is included after textualization.
        include_day_of_year : bool, optional
            Whether day of the year information is included after textualization.
        include_week_number : bool, optional
            Whether week number information is included after textualization.
        include_timezone : bool, optional
            Whether timezone information is included after textualization.
        wkno_as_small_integers : bool, optional
            Whether timedelta data's number of weeks is treated as small integers.
        include_all_params : bool, optional
            Whether to return all parameters or only the learned ones.

        Returns
        -------
        dict
            The learned arguments for tokenizer.
        """
        data = data.drop(columns=[
            c for c in make_list(drop_columns)
            if c in data.columns
        ])
        has_other_token = False

        if use_raw_column_name:
            num_columns = 0
            has_other_token = True
        else:
            num_columns = len(data.columns)

        num_cat = 0
        non_small_int_found = False
        has_sign = False
        min_num_abs = max_small_integer
        exponent_range = -1
        need_year = False
        need_month = False
        need_day = False
        need_hour = False
        need_minute = False
        need_second = False
        need_microsecond = False
        need_weekday = False
        need_am_pm = False
        need_day_of_year = False
        need_week_number = False
        need_timezone = False
        if use_raw_data:
            has_nan = False
            has_other_token = True
        else:
            has_nan = data.isnull().sum().sum() > 0
            forced_dtypes = learn_forced_dtypes(categorical_columns, numerical_columns, datetime_columns,
                                                timedelta_columns, mixed_columns, encoding_columns, non_std_columns)
            col_per_type = {}
            for c in data.columns:
                dtype = learn_raw_dtype_for_textualizer(
                    data=data.loc[:, c],
                    raw_dtype=forced_dtypes.get(c),
                    unique_threshold=unique_threshold,
                    encoding_threshold=encoding_threshold
                )
                if dtype not in col_per_type:
                    col_per_type[dtype] = []
                col_per_type[dtype].append(c)
            for col in col_per_type.get(RawDType.categorical, []):
                num_cat = cls._learn_for_categorical(data.loc[:, col], num_cat)

            small_int_pool = {*range(max_small_integer + 1)}
            max_small_integer_seen = 0
            min_exp = np.inf
            max_exp = -np.inf
            for col in col_per_type.get(RawDType.numerical, []):
                (has_other_token, has_sign, min_exp, max_exp,
                 max_small_integer_seen, non_small_int_found) = cls._learn_for_numerical(
                    data.loc[:, col], has_other_token, has_sign, min_exp, max_exp, max_small_integer_seen,
                    non_small_int_found, small_int_pool, use_scientific_notation_factorization)

            for col in col_per_type.get(RawDType.datetime, []):
                (max_small_integer_seen, need_year, need_month, need_day, need_hour, need_minute, need_second,
                 need_microsecond, need_weekday, need_am_pm, need_day_of_year,
                 need_week_number, need_timezone) = cls._learn_for_datetime(
                    data.loc[:, col], include_weekday, include_am_pm, include_day_of_year, include_week_number,
                    include_timezone, max_small_integer_seen, need_year, need_month, need_day, need_hour, need_minute,
                    need_second, need_microsecond, need_weekday, need_am_pm, need_day_of_year, need_week_number,
                    need_timezone)

            for col in col_per_type.get(RawDType.timedelta, []):
                (has_other_token, has_sign, min_exp, max_exp, max_small_integer_seen, need_week_number, need_day,
                 need_hour, need_minute, need_microsecond, non_small_int_found) = cls._learn_for_timedelta(
                    data.loc[:, col], has_other_token, has_sign, min_exp, max_exp, max_small_integer_seen,
                    need_week_number, need_day, need_hour, need_minute, need_microsecond, non_small_int_found,
                    use_scientific_notation_factorization, wkno_as_small_integers)

            for col in col_per_type.get(RawDType.mixed, []):
                col_data = data.loc[:, col].dropna().reset_index(drop=True)
                num_col = pd.to_numeric(col_data, errors="coerce")
                col_data = col_data[~num_col.isnull()].reset_index(drop=True)
                dat_col = pd.to_datetime(col_data, errors="coerce")
                col_data = col_data[~dat_col.isnull()].reset_index(drop=True)
                tdel_col = pd.to_timedelta(col_data, errors="coerce")
                cat_col = col_data[~tdel_col.isnull()].reset_index(drop=True)
                num_cat = cls._learn_for_categorical(cat_col, num_cat)
                (has_other_token, has_sign, min_exp, max_exp,
                 max_small_integer_seen, non_small_int_found) = cls._learn_for_numerical(
                    num_col, has_other_token, has_sign, min_exp, max_exp, max_small_integer_seen,
                    non_small_int_found, small_int_pool, use_scientific_notation_factorization)
                (max_small_integer_seen, need_year, need_month, need_day, need_hour, need_minute, need_second,
                 need_microsecond, need_weekday, need_am_pm, need_day_of_year,
                 need_week_number, need_timezone) = cls._learn_for_datetime(
                    dat_col, include_weekday, include_am_pm, include_day_of_year, include_week_number,
                    include_timezone, max_small_integer_seen, need_year, need_month, need_day, need_hour, need_minute,
                    need_second, need_microsecond, need_weekday, need_am_pm, need_day_of_year, need_week_number,
                    need_timezone)
                (has_other_token, has_sign, min_exp, max_exp, max_small_integer_seen, need_week_number, need_day,
                 need_hour, need_minute, need_microsecond, non_small_int_found) = cls._learn_for_timedelta(
                    tdel_col, has_other_token, has_sign, min_exp, max_exp, max_small_integer_seen,
                    need_week_number, need_day, need_hour, need_minute, need_microsecond, non_small_int_found,
                    use_scientific_notation_factorization, wkno_as_small_integers)

            if len(col_per_type.get(RawDType.encoding, [])) > 0:
                has_other_token = True

            if max_exp >= min_exp:
                exponent_range = min_exp, max_exp
            min_num_abs = max(max_small_integer_seen, max_small_integer)

        learned_args = dict(
            num_columns=num_columns,
            num_categories=num_cat,
            max_small_integer=int(min_num_abs),
            exponent_range=exponent_range,
            n_essential_digits=2 if use_scientific_notation_factorization and non_small_int_found else 0,
            use_special_token_only=not has_other_token,
            in_cell_pad_token="<|pad|>" if pad_in_cell else None,
            mask_token="<|mask|>" if allow_mask else None,
            row_sep_token="<|sep-row|>" if group_size >= 2 else None,
            nan_token="<|nan|>" if has_nan else None,
            pos_token="<|pos|>" if has_sign else None,
            neg_token="<|neg|>" if has_sign else None,
            mantissa_token_format="<|man-{}|>" if use_scientific_notation_factorization
                                                  and non_small_int_found else None,
            year_token="<|year|>" if need_year else None,
            month_token="<|month|>" if need_month else None,
            day_token="<|day|>" if need_day else None,
            hour_token="<|hour|>" if need_hour else None,
            minute_token="<|minute|>" if need_minute else None,
            second_token="<|second|>" if need_second else None,
            microsecond_token="<|microsecond|>" if need_microsecond else None,
            weekday_token="<|weekday|>" if need_weekday else None,
            am_pm_token="<|am-pm|>" if need_am_pm else None,
            day_of_year_token="<|day-of-yr|>" if need_day_of_year else None,
            wkno_token="<|wk-num|>" if need_week_number else None,
            tz_token="<|tz|>" if need_timezone else None
        )
        if include_all_params:
            default_args = dict(
                tokenizer="distilgpt2",
                cell_sep_token="<|sep-cell|>",
                kv_sep_token="<|sep-kv|>",
                col_token_format="<|col-{}|>",
                cat_token_format="<|cat-{}|>",
                int_token_format="<|int-{}|>",
                exp_token_format="<|exp-{}|>",
                essential_digit_token_format="<|dig-{}|>",
            )
            learned_args.update(default_args)
        return learned_args

    @classmethod
    def _learn_for_timedelta(cls,
                             data: pd.Series,
                             has_other_token: bool,
                             has_sign: bool,
                             min_exp: int,
                             max_exp: int,
                             max_small_integer_seen: int,
                             need_week_number: bool,
                             need_day: bool,
                             need_hour: bool,
                             need_minute: bool,
                             need_microsecond: bool,
                             non_small_int_found: bool,
                             use_scientific_notation_factorization: bool,
                             wkno_as_small_integers: bool) -> \
            Tuple[bool, bool, int, int, int, bool, bool, bool, bool, bool, bool]:
        tdel_col: pd.Series = pd.to_timedelta(data, errors="coerce").dropna()
        if (tdel_col >= timedelta(0)).sum() != len(tdel_col) and \
                (tdel_col <= timedelta(0)).sum() != len(tdel_col):
            has_sign = True
        tdel_col = tdel_col.apply(lambda x: x if x >= timedelta(0) else timedelta(0) - x)
        weeks = (tdel_col.dt.days // 7)
        days = tdel_col.dt.days % 7
        hours = tdel_col.dt.components.hours
        minutes = tdel_col.dt.components.minutes
        seconds = tdel_col.dt.components.seconds
        microseconds = tdel_col.dt.microseconds
        if weeks.std() > 0:
            need_week_number = True
            if wkno_as_small_integers:
                max_small_integer_seen = max(max_small_integer_seen, weeks.max())
            elif not use_scientific_notation_factorization:
                has_other_token = True
            else:
                non_small_int_found = True
                min_exp, max_exp = cls._learn_exp_range(min_exp, max_exp, weeks)
        if days.std() > 0:
            need_day = True
            max_small_integer_seen = max(max_small_integer_seen, days.max())
        if hours.std() > 0:
            need_hour = True
            max_small_integer_seen = max(max_small_integer_seen, hours.max())
        if minutes.std() > 0:
            need_minute = True
            max_small_integer_seen = max(max_small_integer_seen, minutes.max())
        if seconds.std() > 0:
            need_minute = True
            max_small_integer_seen = max(max_small_integer_seen, seconds.max())
        if microseconds.std() > 0:
            need_microsecond = True
            max_small_integer_seen = max(max_small_integer_seen, 99)
        return (has_other_token, has_sign, min_exp, max_exp, max_small_integer_seen, need_week_number, need_day,
                need_hour, need_minute, need_microsecond, non_small_int_found)

    @classmethod
    def _learn_for_datetime(cls,
                            data: pd.Series,
                            include_weekday: bool,
                            include_am_pm: bool,
                            include_day_of_year: bool,
                            include_week_number: bool,
                            include_timezone: bool,
                            max_small_integer_seen: int,
                            need_year: bool,
                            need_month: bool,
                            need_day: bool,
                            need_hour: bool,
                            need_minute: bool,
                            need_second: bool,
                            need_microsecond: bool,
                            need_weekday: bool,
                            need_am_pm: bool,
                            need_day_of_year: bool,
                            need_week_number: bool,
                            need_timezone: bool) \
            -> Tuple[int, bool, bool, bool, bool, bool, bool, bool, bool, bool, bool, bool, bool]:
        dat_col: pd.Series = pd.to_datetime(data, errors="coerce").dropna()
        if dat_col.dt.year.std() > 0:
            need_year = True
            centries = dat_col.dt.year // 100
            years = dat_col.dt.year % 100
            max_small_integer_seen = max(max_small_integer_seen, centries.max())
            max_small_integer_seen = max(max_small_integer_seen, years.max())
        if dat_col.dt.month.std() > 0:
            need_month = True
            max_small_integer_seen = max(max_small_integer_seen, dat_col.dt.month.max())
        if dat_col.dt.day.std() > 0:
            if include_weekday:
                need_weekday = True
            if include_day_of_year:
                need_day_of_year = True
            if include_week_number:
                need_week_number = True
            need_day = True
            max_small_integer_seen = max(max_small_integer_seen, dat_col.dt.day.max())
        if dat_col.dt.hour.std() > 0:
            if include_am_pm:
                need_am_pm = True
            need_hour = True
            max_small_integer_seen = max(max_small_integer_seen, dat_col.dt.hour.max())
        if dat_col.dt.minute.std() > 0:
            need_minute = True
            max_small_integer_seen = max(max_small_integer_seen, dat_col.dt.minute.max())
        if dat_col.dt.second.std() > 0:
            need_second = True
            max_small_integer_seen = max(max_small_integer_seen, dat_col.dt.second.max())
        if dat_col.dt.microsecond.std() > 0:
            need_microsecond = True
            max_small_integer_seen = max(max_small_integer_seen, 99)
        if include_timezone and (dat_col.apply(lambda x: x.strftime("%z")) != "").sum() > 0:
            need_timezone = True
        return (max_small_integer_seen, need_year, need_month, need_day, need_hour, need_minute, need_second,
                need_microsecond, need_weekday, need_am_pm, need_day_of_year, need_week_number, need_timezone)

    @classmethod
    def _learn_for_numerical(cls,
                             data: pd.Series,
                             has_other_token: bool,
                             has_sign: bool,
                             min_exp: int,
                             max_exp: int,
                             max_small_integer_seen: int,
                             non_small_int_found: bool,
                             small_int_pool: Set[int],
                             use_scientific_notation_factorization: bool) -> Tuple[bool, bool, int, int, int, bool]:
        num_col = pd.to_numeric(data, errors="coerce").dropna()
        if len(num_col) <= 0:
            return has_other_token, has_sign, min_exp, max_exp, max_small_integer_seen, non_small_int_found
        if (num_col >= 0).sum() != len(num_col) and (num_col <= 0).sum() != len(num_col):
            has_sign = True
        has_non_small_int = num_col.isin(small_int_pool).sum() != len(num_col)
        if has_non_small_int:
            non_small_int_found = True
            if not use_scientific_notation_factorization:
                has_other_token = True
            else:
                num_col = num_col.abs()
                min_exp, max_exp = cls._learn_exp_range(min_exp, max_exp, num_col)
        else:
            max_small_integer_seen = max(max_small_integer_seen, num_col.abs().max())
        return has_other_token, has_sign, min_exp, max_exp, max_small_integer_seen, non_small_int_found

    @classmethod
    def _learn_for_categorical(cls, data: pd.Series, num_cat: int) -> int:
        nunique = data.nunique(dropna=True)
        num_cat = max(num_cat, nunique)
        return num_cat

    @classmethod
    def _learn_exp_range(cls, min_exp: int, max_exp: int, data: pd.Series) \
            -> Tuple[int, int]:
        is_zero = data == 0
        if is_zero.sum() > 0:
            min_exp = min(min_exp, 0)
            max_exp = max(max_exp, 0)
        data = data[~is_zero]
        min_val = data.min()
        max_val = data.max()
        min_exp = min(min_exp, math.floor(math.log10(min_val)))
        max_exp = max(max_exp, math.floor(math.log10(max_val)))
        return min_exp, max_exp

    @classmethod
    def make(cls,
             mode: Literal["great", "default", "learn"] = "learn",
             **kwargs) -> "TabularDataTokenizer":
        """
        Create a tokenizer from some specification.

        Parameters
        ----------
        mode : "great", or "default", or "learn"
            The mode of making tokenizer.
        **kwargs
            The arguments for the construction.

        Returns
        -------
        TabularDataTokenizer

            - If making in "great" mode, the GReaT tokenizer is constructed.
            - If making in "default" mode, we will take the `**kwargs` directly to construct a tokenizer.
            - If making in "learn" mode, we will construct a minimum tokenizer based on `**kwargs`, and for arguments
              not used for learning, we will override the learned values with the provided values in **kwargs.
        """
        learn_arg_names = {"data", "use_raw_column_name", "use_raw_data", "drop_columns", "categorical_columns",
                           "numerical_columns", "datetime_columns", "timedelta_columns", "mixed_columns",
                           "encoding_columns", "non_std_columns", "unique_threshold", "encoding_threshold",
                           "max_small_integer", "use_scientific_notation_factorization", "pad_in_cell",
                           "allow_mask", "group_size", "include_weekday", "include_am_pm", "include_day_of_year",
                           "include_week_number", "include_timezone", "wkno_as_small_integers",
                           "include_all_params"}
        if mode == "great":
            args = cls.great_tokenizer_args()
        elif mode == "default":
            args = kwargs
        elif mode == "learn":
            args = TabularDataTokenizer.learn_minimum_tokenizer_args(**{
                k: v for k, v in kwargs.items()
                if k in learn_arg_names
            })
            args.update({
                k: v for k, v in kwargs.items()
                if k not in learn_arg_names
            })
        else:
            raise ValueError(f"The mode of making tokenizer {mode} is not recognized.")
        return TabularDataTokenizer(**args)

