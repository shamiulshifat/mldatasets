"""Textualizer for handling mixed data."""

from datetime import datetime, timedelta
from typing import Any, Dict, Tuple, Union

import pandas as pd

from .base import ColumnTextualizer
from ...dtypes import ColumnName, RawDType
from ...tokenizer import TabularDataTokenizer
from ...utils import register


@register(ColumnTextualizer.registry, RawDType.mixed)
class MixedTextualizer(ColumnTextualizer):
    """
    Column textualizer for mixed raw data type.
    For textualization, we don't care about what data type we are mixing.
    And we can mix data of multiple different types.
    """
    def __init__(self,
                 tokenizer: TabularDataTokenizer,
                 name: ColumnName = "",
                 index: int = 0,
                 *,
                 is_small_integers: bool = False,
                 include_weekday: bool = True,
                 include_am_pm: bool = False,
                 include_day_of_year: bool = False,
                 include_week_number: bool = False,
                 include_timezone: bool = True,
                 wkno_as_small_integers: bool = False,
                 **kwargs):
        """
        All parameters are either inherited from the parent class, or from valid types for mixture, including
        categorical, numerical, datetime, and timedelta.
        """
        super().__init__(tokenizer, name, index, **kwargs)
        self.type_textualizer: ColumnTextualizer = self.registry[RawDType.categorical](
            tokenizer, name, index, use_raw_data=False,
            **{k: v for k, v in kwargs.items()
               if k != "use_raw_data"}
        )
        self.categorical_textualizer: ColumnTextualizer = self.registry[RawDType.categorical](
            tokenizer, name, index, **kwargs
        )
        self.numerical_textualizer: ColumnTextualizer = self.registry[RawDType.numerical](
            tokenizer, name, index, is_small_integers=is_small_integers, **kwargs
        )
        self.datetime_textualizer: ColumnTextualizer = self.registry[RawDType.datetime](
            tokenizer, name, index,
            include_weekday=include_weekday, include_am_pm=include_am_pm, include_day_of_year=include_day_of_year,
            include_week_number=include_week_number, include_timezone=include_timezone, **kwargs
        )
        self.timedelta_textualizer: ColumnTextualizer = self.registry[RawDType.timedelta](
            tokenizer, name, index, wkno_as_small_integers=wkno_as_small_integers, **kwargs
        )
        self._categorical_used = False
        self._numerical_used = False
        self._datetime_used = False
        self._timedelta_used = False

    def _textualize_notna_cell(self, x: Any) -> str:
        if self._numerical_used and pd.notnull(pd.to_numeric(x, errors="coerce")):
            type_prefix = self.type_textualizer._textualize_notna_cell(RawDType.numerical.name)
            return type_prefix + self.numerical_textualizer._textualize_notna_cell(x)
        elif self._datetime_used and pd.notnull(pd.to_datetime(x, errors="coerce")):
            type_prefix = self.type_textualizer._textualize_notna_cell(RawDType.datetime.name)
            return type_prefix + self.datetime_textualizer._textualize_notna_cell(x)
        elif self._timedelta_used and pd.notnull(pd.to_timedelta(x, errors="coerce")):
            type_prefix = self.type_textualizer._textualize_notna_cell(RawDType.timedelta.name)
            return type_prefix + self.timedelta_textualizer._textualize_notna_cell(x)
        elif self._categorical_used:
            type_prefix = self.type_textualizer._textualize_notna_cell(RawDType.categorical.name)
            return type_prefix + self.categorical_textualizer._textualize_notna_cell(x)
        else:
            raise ValueError(f"Cannot infer data type for {x}.")

    def _inverse_raw(self, x: str) -> Union[str, float, datetime, timedelta]:
        num_val = pd.to_numeric(x, errors="coerce")
        if pd.notnull(num_val):
            return num_val
        dat_val = pd.to_datetime(x, errors="coerce")
        if pd.notnull(dat_val):
            return dat_val
        tdel_val = pd.to_timedelta(x, errors="coerce")
        if pd.notnull(tdel_val):
            return tdel_val
        return x

    def _fit(self, data: pd.Series):
        data = data.dropna()
        if len(data) <= 0:
            return
        cat_values = []
        num_values = []
        dt_values = []
        tdel_values = []
        for x in data:
            if pd.notnull(pd.to_numeric(x, errors="coerce")):
                num_values.append(x)
            elif pd.notnull(pd.to_datetime(x, errors="coerce")):
                dt_values.append(x)
            elif pd.notnull(pd.to_timedelta(x, errors="coerce")):
                tdel_values.append(x)
            else:
                cat_values.append(x)
        types = []
        for name, values in zip(
            ["categorical", "numerical", "datetime", "timedelta"],
            [cat_values, num_values, dt_values, tdel_values]
        ):
            if len(values) > 0:
                setattr(self, f"_{name}_used", True)
                getattr(self, f"{name}_textualizer").fit(pd.Series(values))
                types.append(getattr(RawDType, name).name)
        self.type_textualizer.fit(pd.Series(types))

    def _inverse_tokens(self, x: str) -> Tuple[Any, bool]:
        this_cat_token = None
        for i in range(self.tokenizer.num_categories):
            cat_token = self.tokenizer.get_category_token(i)
            if x.startswith(cat_token):
                this_cat_token = cat_token
                x = x[len(cat_token):]
                break
        if this_cat_token is None:
            return "", False
        dtype, valid = self.type_textualizer._inverse_tokens(this_cat_token)
        if not valid:
            return "", False
        if dtype == RawDType.categorical.name and self._categorical_used:
            return self.categorical_textualizer._inverse_tokens(x)
        elif dtype == RawDType.numerical.name and self._numerical_used:
            return self.numerical_textualizer._inverse_tokens(x)
        elif dtype == RawDType.datetime.name and self._datetime_used:
            return self.datetime_textualizer._inverse_tokens(x)
        elif dtype == RawDType.timedelta.name and self._timedelta_used:
            return self.timedelta_textualizer._inverse_tokens(x)
        return "", False

    @property
    def raw_dtype(self) -> RawDType:
        return RawDType.mixed

    @classmethod
    def _dtype_specific_update(cls, data: pd.Series, tokenizer: TabularDataTokenizer, default_args: Dict[str, Any]):
        pool = {*range(tokenizer.max_small_integer + 1)}
        num_subset = pd.to_numeric(data, errors="coerce")
        is_num = num_subset.notnull()
        num_subset = num_subset.dropna()
        data = data[~is_num].reset_index(drop=True)
        is_dat = pd.to_datetime(data, errors="coerce").notnull()
        data = data[~is_dat].reset_index(drop=True)
        tdel_subset = pd.to_timedelta(data, errors="coerce").dropna()

        if num_subset.abs().isin(pool).sum() == len(num_subset):
            default_args["is_small_integers"] = True

        tdel_subset = tdel_subset.apply(lambda x: x.days // 7)
        if tdel_subset.isin(pool).sum() == len(tdel_subset):
            default_args["wkno_as_small_integers"] = True

    @classmethod
    def _learn_default_args(cls,
                            tokenizer: TabularDataTokenizer,
                            default_args: Dict[str, Any]) -> Dict[str, Any]:
        return default_args

