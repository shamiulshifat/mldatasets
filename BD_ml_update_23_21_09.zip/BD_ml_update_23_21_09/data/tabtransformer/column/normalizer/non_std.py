"""Normalizers for handling non-standard data. This is mainly a placeholder that does nothing to the data."""

from typing import Any, Dict, List, Tuple, Union

import pandas as pd

from .base import MainValueColumn, StdColumnNormalizer
from ...dtypes import SType
from ...utils import register


@register(StdColumnNormalizer.registry, SType.non_std)
class NonStdNormalizer(StdColumnNormalizer):
    """
    Non-std column normalizer.
    """
    def _normalize(self, data: pd.Series) -> pd.DataFrame:
        return pd.DataFrame({
            MainValueColumn: data
        })

    def _inverse_normalize(self, normalized: pd.DataFrame) -> pd.Series:
        return normalized.loc[:, MainValueColumn]

    def _fit(self, data: pd.Series):
        self.normalized_columns = [MainValueColumn]

    @classmethod
    def make(cls, stype: Union[str, SType], *args, **kwargs) -> "NonStdNormalizer":
        return cls(*args, **kwargs)

    @property
    def stype(self) -> SType:
        return SType.non_std

    @property
    def normalized_span_info(self) -> List[Tuple[int, SType]]:
        return []

    @classmethod
    def validate_kwargs(cls, args: Dict[str, Any]):
        if len(args) > 0:
            raise ValueError("No args should be given for non-std type.")

