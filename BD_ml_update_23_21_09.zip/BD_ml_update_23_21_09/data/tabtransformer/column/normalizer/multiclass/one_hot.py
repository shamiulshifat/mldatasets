"""One-hot encoding."""
from copy import deepcopy
from typing import Any, Collection, Dict, List, Optional, Tuple

import jsonschema
import pandas as pd
from sklearn.preprocessing import OneHotEncoder

from .base import MulticlassNormalizer, MulticlassNormalizerMethods
from ....dtypes import ColumnName, SType
from ....utils import register


@register(MulticlassNormalizer.sub_registry, MulticlassNormalizerMethods.one_hot)
class OneHotNormalizer(MulticlassNormalizer):
    """
    Multi-class column normalizer by one-hot encoding.
    The scikit-learn component used is
    [`OneHotEncoder`](https://scikit-learn.org/stable/modules/generated/sklearn.preprocessing.OneHotEncoder.html#sklearn.preprocessing.OneHotEncoder).
    `kwargs` may contain arguments to it.
    """
    def __init__(self,
                 name: str = "",
                 parent: ColumnName = "",
                 *,
                 enforce_categories: Optional[Collection] = None,
                 **kwargs):
        super().__init__(name, parent, enforce_categories=enforce_categories)
        self.oh = OneHotEncoder(**kwargs)

    def _normalize(self, data: pd.Series) -> pd.DataFrame:
        return pd.DataFrame(
            self.oh.transform(self._reshape_to_2d(data)).toarray(),
            columns=self.normalized_columns
        )

    def _inverse_normalize(self, normalized: pd.DataFrame) -> pd.Series:
        return pd.Series(self.oh.inverse_transform(normalized)[:, 0])

    def _fit_categorical(self, data: pd.Series):
        self.oh.fit(self._reshape_to_2d(data))
        self.normalized_columns = [
            f"is-{c}" for c in self.oh.categories_[0]
        ]

    @property
    def normalized_span_info(self) -> List[Tuple[int, SType]]:
        return [(len(self.oh.categories_[0]), SType.multiclass)]

    @classmethod
    def validate_kwargs(cls, args: Dict[str, Any]):
        if "enforce_categories" in args:
            cls._validate_kwargs_common({
                "enforce_categories": args["enforce_categories"]
            })
            args = deepcopy(args)
            del args["enforce_categories"]
        if "method_type" in args:
            del args["method_type"]
        schema = {
            "type": "object",
            "properties": {
                "categories": {
                    "oneOf": [
                        {
                            "enum": ["auto"]
                        },
                        {
                            "type": "array",
                            "items": {
                                "oneOf": [
                                    {
                                        "type": "array",
                                        "items": {
                                            "type": "string"
                                        }
                                    },
                                    {
                                        "type": "array",
                                        "items": {
                                            "type": "number"
                                        }
                                    }
                                ]
                            }
                        }
                    ]
                },
                "drop": {
                    "oneOf": [
                        {
                            "type": "null"
                        },
                        {
                            "enum": ["first", "if_binary"]
                        },
                        {
                            "type": "array",
                            "items": {
                                "type": ["string", "number"]
                            }
                        }
                    ]
                },
                "dtype": {
                    "enum": ["float32", "float64"]
                },
                "handle_unknown": {
                    "enum": ["error", "ignore"]
                },
                "min_frequency": {
                    "oneOf": [
                        {
                            "type": "null"
                        },
                        {
                            "type": "integer",
                            "minimum": 0
                        }
                    ]
                },
                "max_categories": {
                    "oneOf": [
                        {
                            "type": "null"
                        },
                        {
                            "type": "integer",
                            "minimum": 1
                        }
                    ]
                }
            },
            "additionalProperties": False
        }
        jsonschema.validate(instance=args, schema=schema)
