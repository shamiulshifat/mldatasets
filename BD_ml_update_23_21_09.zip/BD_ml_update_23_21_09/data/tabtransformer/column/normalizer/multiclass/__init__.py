"""Normalizers for handling multi-class categorical data."""

from .base import MulticlassNormalizer, MulticlassNormalizerMethods
from .label import LabelNormalizer
from .one_hot import OneHotNormalizer


__all__ = (
    "MulticlassNormalizerMethods",
    "MulticlassNormalizer",
    "LabelNormalizer",
    "OneHotNormalizer"
)
