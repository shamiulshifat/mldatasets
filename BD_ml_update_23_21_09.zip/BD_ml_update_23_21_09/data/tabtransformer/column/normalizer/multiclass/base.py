"""Shared structure and processing of handling multi-class categorical data."""

import enum
from abc import ABC, abstractmethod
from typing import Any, Dict, Optional, Collection, Type, Union

import jsonschema
import pandas as pd

from ..base import StdColumnNormalizer
from ....dtypes import ColumnName, SType
from ....utils import register, make_list, make_enum


class MulticlassNormalizerMethods(enum.Enum):
    """Methods of normalizing multi-class categorical values."""

    label = enum.auto()
    """Labeling the classes to integers between 0 and number of classes -1."""
    one_hot = enum.auto()
    """One-hot encoding."""


@register(StdColumnNormalizer.registry, SType.multiclass)
class MulticlassNormalizer(StdColumnNormalizer, ABC):
    """
    Multi-class column normalizer.
    """
    sub_registry: Dict[MulticlassNormalizerMethods, Type["MulticlassNormalizer"]] = {}
    """Sub-registry of multiclass for different methods."""

    def __init__(self,
                 name: str = "",
                 parent: ColumnName = "",
                 *,
                 enforce_categories: Optional[Collection] = None):
        """
        Parameters
        ----------
        enforce_categories : Collection, optional
            Categories that this standardized column should have.
            This should be a superset of the given data of fitting.
            This is to allow unseen but valid categories during inverse normalization
            (usually due to sampling of the fitting data, outside the implementation of normalizer).
        Other parameters are inherited from parent `StdColumnNormalizer`.
        """
        super().__init__(name, parent)
        self.enforce_categories = make_list(enforce_categories)

    @property
    def stype(self) -> SType:
        return SType.multiclass

    @classmethod
    def make(cls,
             stype: Union[str, SType],
             method_type: Union[str, MulticlassNormalizerMethods] = MulticlassNormalizerMethods.one_hot,
             *args, **kwargs) -> "MulticlassNormalizer":
        """
        Construct a `MulticlassNormalizer` instance based on the given types and arguments.

        Parameters
        ----------
        stype : str or SType
            The standard column type of the normalizer.
        method_type: str or MulticlassNormalizerMethods
            The method type for handling the multi-class categorical standard type.
        *args, **kwargs
            Parameters to the normalizer of the given method type in the given stype.
        """
        method_type: MulticlassNormalizerMethods = make_enum(method_type, MulticlassNormalizerMethods)
        return cls.sub_registry[method_type](*args, **kwargs)

    def _fit(self, data: pd.Series):
        data = pd.concat([data, pd.Series([*self.enforce_categories])], ignore_index=True)
        self._fit_categorical(data)

    @abstractmethod
    def _fit_categorical(self, data: pd.Series):
        raise NotImplementedError()

    @classmethod
    def validate_kwargs(cls, args: Dict[str, Any]):
        method = args.get("method_type", "one_hot")
        cls.sub_registry[MulticlassNormalizerMethods[method]].validate_kwargs(args)

    @classmethod
    def _validate_kwargs_common(cls, args: Dict[str, Any]):
        schema = {
            "type": "object",
            "properties": {
                "enforce_categories": {
                    "oneOf": [
                        {"type": "null"},
                        {
                            "type": "array",
                            "uniqueItems": True
                        }
                    ]
                },
                "method_type": {
                    "type": "string",
                    "enum": ["label", "one_hot"]
                }
            },
            "additionalProperties": False
        }
        jsonschema.validate(instance=args, schema=schema)
