"""Shared structure and processing of handling numerical data."""

import enum
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Tuple, Type, Union

import jsonschema
import numpy as np
import pandas as pd

from . import transforms as T
from .discretizer import Discretizer, DiscretizerAlgo
from ..base import MainValueColumn, StdColumnNormalizer
from ....dtypes import ColumnName, SType
from ....utils import make_dict, make_enum, make_list, register


class NumericalNormalizerMethods(enum.Enum):
    """Methods of normalizing numerical values."""

    identity = enum.auto()
    """No changes are applied to the data. Use the raw value directly."""
    max_abs = enum.auto()
    """Scale each feature by its maximum absolute value."""
    min_max = enum.auto()
    """Transform features by scaling each feature to a given range."""
    quantile = enum.auto()
    """Transform features using quantiles information."""
    robust = enum.auto()
    """Scale features using statistics that are robust to outliers."""
    standard = enum.auto()
    """Standardize features by removing the mean and scaling to unit variance."""
    cluster_based = enum.auto()
    """Cluster-based transformer by Gaussian Mixture Modeling."""


@register(StdColumnNormalizer.registry, SType.numerical)
class NumericalNormalizer(StdColumnNormalizer, ABC):
    """
    Numerical column normalizer.
    """

    sub_registry: Dict[NumericalNormalizerMethods, Type["NumericalNormalizerMethods"]] = {}
    """Sub-registry of multiclass for different methods."""

    def __init__(self,
                 name: str = "",
                 parent: ColumnName = "",
                 *,
                 rounding: Optional[int] = None,
                 unit: int = 1,
                 min_val: float = -np.inf,
                 max_val: float = np.inf,
                 transforms: Optional[List[Union[T.BaseTransform, Tuple[str, Dict[str, Any]]]]] = None,
                 discretizer_algo: Optional[Union[str, DiscretizerAlgo]] = DiscretizerAlgo.kbins,
                 discretizer_kwargs: Optional[Dict[str, Any]] = None):
        """
        Parameters
        ----------
        rounding : int, optional
            Number of digits to round to.
            For example, `rounding`=2 means rounding values to 2-digit precision.
            This value can also be negative to round to hundreds, thousands, etc.
            If not provided, no rounding is applied.
        unit : int, optional
            The smallest rounding unit (if `rounding` is not `None`).
            For example, `rounding`=2 with `unit`=5, then the values should be like 0.25, 1.40, -3.55
            but not 2.21, -4.19.
            If not provided, the default value taken is 1.
        min_val : float, optional
            Minimum value in the standardized column.
            If not provided, we will keep the original value as it is.
            If provided, any value smaller than this will be enforced to this value, so eventually no value can be
            smaller than this value.
        max_val : float, optional
            Maximum value in the standardized column, interpreted similarly to `min_val`.
        transforms : list[(str, dict) or BaseTransform], optional
            The
            [transformations](/tabtransformer/column/normalizer/numerical/transforms#tabtransformer.column.normalizer.numerical.transforms.BaseTransform.make)
            to apply to the data before fitting toward normalizer (but after formatting rounding and clipping).
        discretizer_algo : DiscretizerAlgo, optional
            The discretezer algorithm.
            If not provided, discretizer will not be constructed.
            So discretization-related transformations will not be available.
        discretizer_kwargs : dict
            Arguments for
            [discretizer](/tabtransformer/column/normalizer/numerical/discretizer#tabtransformer.column.normalizer.numerical.discretizer.Discretizer.make).
        Other parameters are inherited from parent `StdColumnNormalizer`.
        """
        super().__init__(name, parent)
        self.rounding = rounding
        self.unit = unit
        self.min = float(min_val)
        self.max = float(max_val)
        transforms = make_list(transforms)
        self.transforms = []
        for t in transforms:
            if isinstance(t, T.BaseTransform):
                self.transforms.append(t)
            else:
                t, kwargs = t
                self.transforms.append(T.BaseTransform.make(t, **kwargs))

        self.discretizer = None
        if discretizer_algo is not None:
            self.discretizer = Discretizer.make(discretizer_algo, **make_dict(discretizer_kwargs))

    def _normalize(self, data: pd.Series) -> pd.DataFrame:
        data = self._format_number(data)
        data = self._transform_forward(data)
        return self._normalize_content(data)

    @abstractmethod
    def _normalize_content(self, data: pd.Series) -> pd.DataFrame:
        raise NotImplementedError()

    def _inverse_normalize(self, normalized: pd.DataFrame) -> pd.Series:
        result = self._inverse_normalize_content(normalized)
        result = self._transform_backward(result)
        return self._format_number(result)

    def _transform_backward(self, data: pd.Series) -> pd.Series:
        data = data.values
        for t in reversed(self.transforms):
            data = t.backward(data)
        return pd.Series(data)

    @abstractmethod
    def _inverse_normalize_content(self, normalized: pd.DataFrame) -> pd.Series:
        raise NotImplementedError()

    def _fit(self, data: pd.Series):
        data = self._format_number(data)
        for t in self.transforms:
            t.fit(data.values)
        data = self._transform_forward(data)
        self._fit_content(data)
        if self.discretizer is not None:
            self.discretizer.fit(data)

    def discretize(self, data: pd.Series) -> pd.Series:
        """
        Discretize the given data.

        Parameters
        ----------
        data : pd.Series
            The data to discretize.

        Returns
        -------
        pd.Series
            The discretized data.
        """
        if self.discretizer is None:
            raise RuntimeError(f"Column {self.name} of {self.parent} does not have a discretizer.")
        data = self._format_number(data)
        data = self._transform_forward(data)
        return self.discretizer.discretize(data)

    def inverse_discretize(self, data: pd.Series) -> pd.Series:
        """
        Inverse the discretization step. If the original data is continuous, recovered continuous data is very unlikely
        to be identical to the original.

        Parameters
        ----------
        data : pd.Series
            The discretized data.

        Returns
        -------
        pd.Series
            The recovered data from discretized result.
        """
        if self.discretizer is None:
            raise RuntimeError(f"Column {self.name} of {self.parent} does not have a discretizer.")
        data = self.discretizer.recover(data)
        data = self._transform_backward(data)
        return data

    def _transform_forward(self, data: pd.Series) -> pd.Series:
        data = data.values
        for t in self.transforms:
            data = t.forward(data)
        return pd.Series(data)

    def _format_number(self, data: pd.Series) -> pd.Series:
        if self.rounding is not None:
            data = data.apply(lambda x: round(x, self.rounding))
            if self.unit is not None:
                unit = self.unit * (10 ** (-self.rounding))
                data = data.apply(lambda x: unit * round(x / unit))
        data = data.apply(lambda x: max(min(x, self.max), self.min))
        return data

    @abstractmethod
    def _fit_content(self, data: pd.Series):
        raise NotImplementedError()

    @property
    def stype(self) -> SType:
        return SType.numerical

    @classmethod
    def make(cls,
             stype: Union[str, SType],
             method_type: Union[str, NumericalNormalizerMethods] = NumericalNormalizerMethods.cluster_based,
             *args, **kwargs) -> "NumericalNormalizer":
        method_type = make_enum(method_type, NumericalNormalizerMethods)
        return cls.sub_registry[method_type](*args, **kwargs)

    @classmethod
    def validate_kwargs(cls, args: Dict[str, Any]):
        method_type = args.get("method_type", "cluster_based")
        cls.sub_registry[NumericalNormalizerMethods[method_type]].validate_kwargs(args)

    @classmethod
    def _validate_kwargs_common(cls, args: Dict[str, Any]):
        schema = {
            "type": "object",
            "properties": {
                "method_type": {
                    "type": "string",
                    "enum": ["identity", "max_abs", "min_max", "quantile", "robust", "standard", "cluster_based"]
                },
                "rounding": {
                    "type": ["integer", "null"]
                },
                "unit": {
                    "type": "integer",
                    "minimum": 1
                },
                "min_val": {
                    "oneOf": [
                        {
                            "type": "string",
                            "enum": ["inf", "-inf"]
                        },
                        {"type": "number"}
                    ]
                },
                "max_val": {
                    "oneOf": [
                        {
                            "type": "string",
                            "enum": ["inf", "-inf"]
                        },
                        {"type": "number"}
                    ]
                },
                "transforms": {
                    "type": "array",
                    "items": {
                        "type": "array",
                        "minItems": 2,
                        "maxItems": 2,
                        "prefixItems": [
                            {
                                "enum": [*T.BaseTransform.registry]
                            },
                            {
                                "type": "object",
                            }
                        ]
                    }
                },
                "discretizer_algo": {
                    "type": ["string", "null"],
                    "enum": ["kbins", "kmeans"],
                    "default": None
                },
                "discretizer_kwargs": {
                    "type": "object",
                    "properties": {
                        "discretize_threshold": {
                            "type": "integer",
                            "minimum": 2
                        }
                    }
                }
            },
            "additionalProperties": False
        }
        jsonschema.validate(instance=args, schema=schema)

        discretizer_schema = {
            "kbins": {
                "type": "object",
                "properties": {
                    "strategy": {
                        "type": "string", "enum": ["uniform", "quantile", "kmeans"]
                    },
                    "discretize_threshold": {
                        "type": "integer",
                        "minimum": 2
                    },
                },
                "additionalProperties": False
            },
            "kmeans": {
                "type": "object",
                "properties": {
                    "init": {
                        "type": "string",
                        "enum": ["k-means++", "random"]
                    },
                    "n_init": {
                        "oneOf": [
                            {
                                "type": "integer",
                                "minimum": 1
                            },
                            {
                                "type": "string",
                                "enum": ["warn", "auto"]
                            }
                        ]
                    },
                    "max_iter": {
                        "type": "integer",
                        "minimum": 1
                    },
                    "tol": {
                        "type": "number",
                        "exclusiveMinimum": 0
                    },
                    "algorithm": {
                        "type": "string",
                        "enum": ["lloyd", "elkan", "auto", "full"]
                    },
                    "discretize_threshold": {
                        "type": "integer",
                        "minimum": 2
                    },
                },
                "additionalProperties": False
            }
        }
        discretizer_algo = args.get("discretizer_algo")
        if discretizer_algo is not None:
            jsonschema.validate(instance=args.get("discretizer_kwargs", {}),
                                schema=discretizer_schema[discretizer_algo])

        transforms = make_list(args.get("transforms"))
        for ttype, targs in transforms:
            T.BaseTransform.registry[ttype].validate_kwargs(targs)


@register(NumericalNormalizer.sub_registry, NumericalNormalizerMethods.identity)
class IdentityNormalizer(NumericalNormalizer):
    """
    Numerical column normalizer by doing no change.
    """
    def _inverse_normalize_content(self, normalized: pd.DataFrame) -> pd.Series:
        return normalized.loc[:, MainValueColumn]

    def _normalize_content(self, data: pd.Series) -> pd.DataFrame:
        return pd.DataFrame({MainValueColumn: data})

    def _fit_content(self, data: pd.Series):
        pass

    @property
    def normalized_span_info(self) -> List[Tuple[int, SType]]:
        return [(1, SType.numerical)]

    @classmethod
    def validate_kwargs(cls, args: Dict[str, Any]):
        cls._validate_kwargs_common(args)
