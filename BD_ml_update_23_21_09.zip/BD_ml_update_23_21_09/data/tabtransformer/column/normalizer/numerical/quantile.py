"""Numerical normalization by quantile."""

from copy import deepcopy
from typing import Any, Dict, List, Optional, Tuple, Union

import numpy as np
import pandas as pd
from sklearn.preprocessing import QuantileTransformer

from . import transforms as T
from .base import NumericalNormalizer, NumericalNormalizerMethods
from .discretizer import DiscretizerAlgo
from ..base import MainValueColumn
from ....dtypes import ColumnName, SType
from ....utils import register


@register(NumericalNormalizer.sub_registry, NumericalNormalizerMethods.quantile)
class QuantileNormalizer(NumericalNormalizer):
    """
    Numerical column normalizer by quantile transformation.
    The scikit-learn component used is
    [`QuantileTransformer`](https://scikit-learn.org/stable/modules/generated/sklearn.preprocessing.QuantileTransformer.html).
    `kwargs` may contain arguments to it.
    """
    def __init__(self,
                 name: str = "",
                 parent: ColumnName = "",
                 *,
                 rounding: Optional[int] = None,
                 unit: Optional[int] = None,
                 min_val: float = -np.inf,
                 max_val: float = np.inf,
                 transforms: Optional[List[Union[T.BaseTransform, Tuple[str, Dict[str, Any]]]]] = None,
                 discretizer_algo: Optional[Union[str, DiscretizerAlgo]] = None,
                 discretizer_kwargs: Optional[Dict[str, Any]] = None,
                 output_distribution: str = "normal",
                 **kwargs):
        super().__init__(
            name, parent,
            rounding=rounding, unit=unit, min_val=min_val, max_val=max_val,
            transforms=transforms, discretizer_algo=discretizer_algo, discretizer_kwargs=discretizer_kwargs
        )
        self._transformer = QuantileTransformer(
            output_distribution=output_distribution,
            **kwargs
        )

    def _normalize_content(self, data: pd.Series) -> pd.DataFrame:
        result = self._scaler.transform(self._reshape_to_2d(data))
        return pd.DataFrame({MainValueColumn: result[:, 0]})

    def _inverse_normalize_content(self, normalized: pd.DataFrame) -> pd.Series:
        result = self._scaler.inverse_transform(normalized.values)
        return pd.Series(result[:, 0])

    def _fit_content(self, data: pd.Series):
        self._scaler.fit(self._reshape_to_2d(data))
        self.normalized_columns = [MainValueColumn]

    @property
    def normalized_span_info(self) -> List[Tuple[int, SType]]:
        return [(1, SType.numerical)]

    @classmethod
    def validate_kwargs(cls, args: Dict[str, Any]):
        schema = {
            "type": "object",
            "properties": {
                "n_quantiles": {
                    "type": "integer",
                    "minimum": 1
                },
                "output_distribution": {
                    "enum": ["uniform", "normal"]
                },
                "ignore_implicit_zeros": {"type": "boolean"},
                "subsample": {
                    "type": "integer",
                    "minimum": 1
                }
            }
        }

        args = deepcopy(args)
        for c in schema["properties"]:
            if c in args:
                del args[c]
        cls._validate_kwargs_common(args)

