"""Cluster-based normalization by Gaussian Mixture Modeling."""
from copy import deepcopy
from typing import Any, Dict, Iterable, List, Tuple, Union

import jsonschema
import numpy as np
import pandas as pd
from sklearn.mixture import BayesianGaussianMixture

from .base import NumericalNormalizer, NumericalNormalizerMethods
from ..base import MainValueColumn, StdColumnNormalizer
from ....dtypes import ColumnName, SType
from ....utils import register


@register(NumericalNormalizer.sub_registry, NumericalNormalizerMethods.cluster_based)
class ClusterBasedNormalizer(NumericalNormalizer):
    """
    Numerical column normalizer by Gaussian Mixture Modeling.
    """
    def __init__(self,
                 name: str = "",
                 parent: ColumnName = "",
                 *,
                 max_clusters: int = 10,
                 weight_threshold: float = .005,
                 std_multiplier: float = 4,
                 weight_concentration_prior: float = .001,
                 mode_normalization_method: str = "one_hot",
                 eps: float = 1e-6,
                 clip: Union[float, Tuple[float, float]] = 1,
                 **kwargs):
        """
        Parameters
        ----------
        max_clusters : int, optional
            Maximum number of clusters allowed. Default is 10.
        weight_threshold : float, optional
            Minimum weight of the cluster to be retained after GMM is trained. Default is 0.005.
        std_multiplier : float, optional
            Divisor of the standard-scaled value so that it falls in some range. Default is 4.
        mode_normalization_method : str, optional
            The mode as multi-class normalization method.
        eps : float, optional
            The small value to add to avoid zero division. Default is 1e-6.
        clip : float or (float, float), optional
            After standard scaling and divided by `std_multiplier`, the value range to be clipped into.
            During training, this value is scaled to 0.99 times itself.
            If one value is provided, we use the positive and negative absolute value to clip.
            If two values are provided, they are used as the minimum and maximum clipping values respectively.
        **kwargs
            Including three types:

            - Arguments to parent
              [`NumericalNormalizer`](/tabtransformer/column/normalizer/numerical#tabtransformer.column.normalizer.numerical.NumericalNormalizer).
            - Arguments to scikit-learn
              [`BayesianGaussianMixture`](https://scikit-learn.org/stable/modules/generated/sklearn.mixture.BayesianGaussianMixture.html).
            - Arguments to the mode as
              [multi-class categorical](/tabtransformer/column/normalizer/multiclass#tabtransformer.column.normalizer.multiclass.MulticlassNormalizer.make) column.
        """
        num_args = {"rounding", "unit", "min_val", "max_val", "transforms", "discretizer_algo", "discretize_kwargs"}
        bgm_args = {"covariance_type", "tol", "reg_covar", "max_iter", "n_init", "init_params",
                    "weight_concentration_prior_type", "mean_precision_prior", "mean_prior", "degrees_of_freedom_prior",
                    "covariance_prior", "random_state", "warm_start", "verbose", "verbose_interval"}
        num_kwargs = {
            k: v for k, v in kwargs.items()
            if k in num_args
        }
        bgm_kwargs = {
            k: v for k, v in kwargs.items()
            if k in bgm_args
        }
        mc_kwargs = {
            k: v for k, v in kwargs.items()
            if k not in num_args | bgm_args
        }
        super().__init__(name, parent, **num_kwargs)
        self.max_clusters = max_clusters
        self.weight_threshold = weight_threshold
        self.std_multiplier = std_multiplier
        self.eps = eps
        if isinstance(clip, Iterable):
            self.min_clip, self.max_clip = clip
        else:
            self.min_clip, self.max_clip = -abs(clip), abs(clip)

        self.bgm = BayesianGaussianMixture(
            n_components=max_clusters,
            weight_concentration_prior=weight_concentration_prior,
            **bgm_kwargs
        )
        self.mc_norm = StdColumnNormalizer.make(
            SType.multiclass, mode_normalization_method,
            name=f"{name}|MC", parent=parent, **mc_kwargs
        )
        self._valid_modes = None
        self._means = None
        self._stds = None
        self._n_valid_modes = -1

    def _fit_content(self, data: pd.Series):
        data = self._reshape_to_2d(data)

        self.bgm.fit(data)
        self._valid_modes = self.bgm.weights_ > self.weight_threshold
        self._means = self.bgm.means_.reshape((1, -1))
        self._stds = np.sqrt(self.bgm.covariances_).reshape((1, -1))
        self._n_valid_modes = self._valid_modes.sum()

        selected_modes = self._select_mode(data)
        mode_to_fit = np.concatenate([selected_modes, np.arange(self._n_valid_modes)])
        self.mc_norm.fit(pd.Series(mode_to_fit))

        self.normalized_columns = [
            f"MC-{c}" for c in self.mc_norm.normalized_columns
        ] + [MainValueColumn]

    def _normalize_content(self, data: pd.Series) -> pd.DataFrame:
        data = self._reshape_to_2d(data)
        selected_modes = self._select_mode(data)
        mode_normalized = self.mc_norm.normalize(pd.Series(selected_modes))
        mode_normalized = mode_normalized.rename(columns={
            c: f"MC-{c}" for c in mode_normalized.columns
        })

        normalized = (data - self._means) / (self.std_multiplier * self._stds)
        normalized = normalized[:, self._valid_modes]
        normalized = normalized[np.arange(data.shape[0]), selected_modes]
        normalized = np.clip(normalized, self.min_clip * .99, self.max_clip * .99)
        normalized = pd.DataFrame({
            MainValueColumn: normalized
        })
        return pd.concat([mode_normalized, normalized], axis=1)

    def _select_mode(self, data: np.ndarray) -> np.ndarray:
        mode_probs = self.bgm.predict_proba(data)
        mode_probs = mode_probs[:, self._valid_modes]
        selected_mode = []
        for prob in mode_probs:
            prob_t = prob + self.eps
            prob_t = prob_t / prob_t.sum()
            selected_mode.append(
                np.random.choice(
                    np.arange(self._n_valid_modes), p=prob_t
                )
            )
        return np.array(selected_mode, dtype="int")

    def _inverse_normalize_content(self, normalized: pd.DataFrame) -> pd.Series:
        mc_columns = [
            c for c in normalized.columns
            if c.startswith("MC-")
        ]
        modes = self.mc_norm.inverse_normalize(
            normalized[mc_columns].rename({
                c: c[3:] for c in mc_columns
            })
        )
        modes = modes.values.astype(int)

        normalized = np.clip(normalized[MainValueColumn].values, self.min_clip, self.max_clip)
        means = self._means.reshape((-1,))[self._valid_modes][modes]
        stds = self._stds.reshape((-1,))[self._valid_modes][modes]
        recovered = normalized * self.std_multiplier * stds + means
        return pd.Series(recovered)

    @property
    def normalized_span_info(self) -> List[Tuple[int, SType]]:
        return self.mc_norm.normalized_span_info + [(1, SType.numerical)]

    @classmethod
    def validate_kwargs(cls, args: Dict[str, Any]):
        schema = {
            "type": "object",
            "properties": {
                "max_clusters": {
                    "type": "integer",
                    "minimum": 1
                },
                "weight_threshold": {
                    "type": "number",
                    "minimum": 0,
                    "maximum": 1
                },
                "std_multiplier": {
                    "type": "number",
                    "exclusiveMinimum": 0
                },
                "weight_concentration_prior": {
                    "type": ["number", "null"],
                    "exclusiveMinimum": 0
                },
                "eps": {
                    "type": "number",
                    "exclusiveMinimum": 0
                },
                "clip": {
                    "oneOf": [
                        {
                            "type": "number",
                            "exclusiveMinimum": 0
                        }, {
                            "type": "array",
                            "minItems": 2,
                            "maxItems": 2,
                            "items": {"type": "number"}
                        }
                    ]
                }
            }
        }
        jsonschema.validate(instance=args, schema=schema)

        clip = args.get("clip")
        if isinstance(clip, Iterable):
            a, b = clip
            if b <= a:
                raise ValueError("The clip range should have the latter value greater than the former, but got "
                                 f"{b} <= {a}.")

        args = deepcopy(args)
        for c in schema["properties"]:
            if c in args:
                del args[c]

        bgm_schema = {
            "type": "object",
            "properties": {
                "covariance_type": {
                    "enum": ["full", "tied", "diag", "spherical"]
                },
                "tol": {"type": "number", "minimum": 0},
                "reg_covar": {"type": "number", "minimum": 0},
                "max_iter": {"type": "integer", "minimum": 1},
                "n_init": {"type": "integer", "minimum": 1},
                "init_params": {
                    "enum": ["kmeans", "random", "k-means++", "random_from_data"]
                },
                "weight_concentration_prior_type": {
                    "enum": ["dirichlet_process", "dirichlet_distribution"]
                },
                "mean_precision_prior": {
                    "type": ["number", "null"],
                    "exclusiveMinimum": 0
                },
                "mean_prior": {
                    "type": ["array", "null"],
                    "items": {"type": "number"}
                },
                "degrees_of_freedom_prior": {
                    "type": ["number", "null"],
                    "minimum": 0
                },
                "covariance_prior": {
                    "type": ["array", "number", "null"],
                    "items": {
                        "type": "array",
                        "items": {"type": "number"}
                    }
                },
                "warm_start": {"type": "boolean"},
            }
        }
        jsonschema.validate(instance=args, schema=bgm_schema)
        for c in bgm_schema["properties"]:
            if c in args:
                del args[c]

        num_args = {"rounding", "unit", "min_val", "max_val", "transforms", "discretizer_algo", "discretizer_kwargs"}
        cls._validate_kwargs_common({
            k: v for k, v in args.items()
            if k in num_args
        })
        for c in num_args:
            if c in args:
                del args[c]

        mc_type = args.get("mode_normalization_method", "one_hot")
        args["method_type"] = mc_type
        if "mode_normalization_method" in args:
            del args["mode_normalization_method"]
        cls.registry[SType.multiclass].validate_kwargs(args)
