"""Numerical normalization by scaling."""

from abc import ABC
from copy import deepcopy
from typing import Any, Dict, List, Optional, Tuple, Union

import jsonschema
import numpy as np
import pandas as pd
from sklearn.preprocessing import MaxAbsScaler, MinMaxScaler, RobustScaler, StandardScaler

from . import transforms as T
from .base import NumericalNormalizer, NumericalNormalizerMethods
from .discretizer import DiscretizerAlgo
from ..base import MainValueColumn
from ....dtypes import ColumnName, SType
from ....utils import register


class ScalerNormalizer(NumericalNormalizer, ABC):
    """
    Numerical column normalizer by scikit-learn dimension-persistent numerical-to-numerical transformers.
    """

    _scalers = {
        NumericalNormalizerMethods.max_abs: MaxAbsScaler,
        NumericalNormalizerMethods.min_max: MinMaxScaler,
        NumericalNormalizerMethods.robust: RobustScaler,
        NumericalNormalizerMethods.standard: StandardScaler
    }

    def __init__(self,
                 name: str = "",
                 parent: ColumnName = "",
                 *,
                 rounding: Optional[int] = None,
                 unit: Optional[int] = None,
                 min_val: float = -np.inf,
                 max_val: float = np.inf,
                 transforms: Optional[List[Union[T.BaseTransform, Tuple[str, Dict[str, Any]]]]] = None,
                 discretizer_algo: Optional[Union[str, DiscretizerAlgo]] = None,
                 discretizer_kwargs: Optional[Dict[str, Any]] = None,
                 scaler_type: NumericalNormalizerMethods = NumericalNormalizerMethods.min_max,
                 **kwargs):
        super().__init__(
            name, parent,
            rounding=rounding, unit=unit, min_val=min_val, max_val=max_val,
            transforms=transforms, discretizer_algo=discretizer_algo, discretizer_kwargs=discretizer_kwargs
        )
        self._scaler = self._scalers[scaler_type](**kwargs)

    def _normalize_content(self, data: pd.Series) -> pd.DataFrame:
        result = self._scaler.transform(self._reshape_to_2d(data))
        return pd.DataFrame({MainValueColumn: result[:, 0]})

    def _inverse_normalize_content(self, normalized: pd.DataFrame) -> pd.Series:
        result = self._scaler.inverse_transform(normalized.values)
        return pd.Series(result[:, 0])

    def _fit_content(self, data: pd.Series):
        self._scaler.fit(self._reshape_to_2d(data))
        self.normalized_columns = [MainValueColumn]

    @property
    def normalized_span_info(self) -> List[Tuple[int, SType]]:
        return [(1, SType.numerical)]

    @classmethod
    def validate_kwargs(cls, args: Dict[str, Any]):
        cls._validate_kwargs_common(args)


@register(NumericalNormalizer.sub_registry, NumericalNormalizerMethods.max_abs)
class MaxAbsNormalizer(ScalerNormalizer):
    """
    Numerical column normalizer by max-abs scaling.
    The scikit-learn component used is
    [`MaxAbsScaler`](https://scikit-learn.org/stable/modules/generated/sklearn.preprocessing.MaxAbsScaler.html).
    `kwargs` may contain arguments to it.
    """
    def __init__(self,
                 name: str = "",
                 parent: ColumnName = "",
                 **kwargs):
        super().__init__(
            name, parent, scaler_type=NumericalNormalizerMethods.max_abs,
            **kwargs
        )


@register(NumericalNormalizer.sub_registry, NumericalNormalizerMethods.min_max)
class MinMaxNormalizer(ScalerNormalizer):
    """
    Numerical column normalizer by min-max scaling.
    The scikit-learn component used is
    [`MinMaxScaler`](https://scikit-learn.org/stable/modules/generated/sklearn.preprocessing.MinMaxScaler.html).
    `kwargs` may contain arguments to it.
    """
    def __init__(self,
                 name: str = "",
                 parent: ColumnName = "",
                 **kwargs):
        super().__init__(
            name, parent, scaler_type=NumericalNormalizerMethods.min_max,
            **kwargs
        )

    @classmethod
    def validate_kwargs(cls, args: Dict[str, Any]):
        schema = {
            "type": "object",
            "properties": {
                "feature_range": {
                    "type": "array",
                    "minItems": 2,
                    "maxItems": 2,
                    "items": {
                        "type": "number",
                    }
                },
                "clip": {
                    "type": "boolean"
                }
            }
        }
        jsonschema.validate(instance=args, schema=schema)

        a, b = args.get("feature_range", (0, 1))
        if b <= a:
            raise ValueError("The feature range should have the latter value greater than the former, but got "
                             f"{b} <= {a}.")

        args = deepcopy(args)
        for c in ["feature_range", "clip"]:
            if c in args:
                del args[c]
        cls._validate_kwargs_common(args)


@register(NumericalNormalizer.sub_registry, NumericalNormalizerMethods.robust)
class RobustNormalizer(ScalerNormalizer):
    """
    Numerical column normalizer by robust scaling.
    The scikit-learn component used is
    [`RobustScaler`](https://scikit-learn.org/stable/modules/generated/sklearn.preprocessing.RobustScaler.html).
    `kwargs` may contain arguments to it.
    """
    def __init__(self,
                 name: str = "",
                 parent: ColumnName = "",
                 **kwargs):
        super().__init__(
            name, parent, scaler_type=NumericalNormalizerMethods.robust,
            **kwargs
        )

    @classmethod
    def validate_kwargs(cls, args: Dict[str, Any]):
        schema = {
            "type": "object",
            "properties": {
                "with_centering": {"type": "boolean"},
                "with_scaling": {"type": "boolean"},
                "quantile_range": {
                    "type": "array",
                    "minItems": 2,
                    "maxItems": 2,
                    "items": {
                        "type": "number",
                        "minimum": 0,
                        "maximum": 100
                    }
                },
                "unit_variance": {"type": "boolean"}
            }
        }
        jsonschema.validate(instance=args, schema=schema)

        a, b = args.get("quantile_range", (25., 75.))
        if b <= a:
            raise ValueError("The quantile range should have the latter value greater than the former, but got "
                             f"{b} <= {a}.")

        args = deepcopy(args)
        for c in schema["properties"]:
            if c in args:
                del args[c]
        cls._validate_kwargs_common(args)


@register(NumericalNormalizer.sub_registry, NumericalNormalizerMethods.standard)
class StandardNormalizer(ScalerNormalizer):
    """
    Numerical column normalizer by standard scaling.
    The scikit-learn component used is
    [`StandardScaler`](https://scikit-learn.org/stable/modules/generated/sklearn.preprocessing.StandardScaler.html).
    `kwargs` may contain arguments to it.
    """
    def __init__(self,
                 name: str = "",
                 parent: ColumnName = "",
                 **kwargs):
        super().__init__(
            name, parent, scaler_type=NumericalNormalizerMethods.standard,
            **kwargs
        )

    @classmethod
    def validate_kwargs(cls, args: Dict[str, Any]):
        schema = {
            "type": "object",
            "properties": {
                "with_mean": {"type": "boolean"},
                "with_std": {"type": "boolean"}
            }
        }
        jsonschema.validate(instance=args, schema=schema)

        args = deepcopy(args)
        for c in schema["properties"]:
            if c in args:
                del args[c]
        cls._validate_kwargs_common(args)

