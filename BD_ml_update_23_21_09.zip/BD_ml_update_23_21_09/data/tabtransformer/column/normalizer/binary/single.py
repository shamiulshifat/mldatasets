"""Binary normalizer that uses one column to represent a binary standard column."""

from copy import deepcopy
from typing import Any, Dict, List, Optional, Tuple

import jsonschema
import pandas as pd

from .base import BinaryNormalizerMethods, BinaryNormalizer
from ..base import MainValueColumn, NumericalType
from ....dtypes import ColumnName, SType
from ....utils import register


@register(BinaryNormalizer.sub_registry, BinaryNormalizerMethods.single)
class SingleBinaryNormalizer(BinaryNormalizer):
    """
    Binary column normalizer by comparing to a threshold.
    """
    def __init__(self,
                 name: str = "",
                 parent: ColumnName = "",
                 *,
                 pos_label: Optional = None,
                 threshold: float = .5):
        """
        Parameters
        ----------
        threshold : float, optional
            The threshold to differentiate between [0, 1] to {0, 1} classes.
        Other parameters are inherited from parent `BinaryNormalizer`.
        """
        super().__init__(name, parent, pos_label=pos_label)
        self.threshold = threshold

    def _fit_boolean(self, data: pd.Series):
        self.normalized_columns = [MainValueColumn]

    def _normalize(self, data: pd.Series) -> pd.DataFrame:
        data = self._construct_boolean(data)
        return pd.DataFrame({
            MainValueColumn: data.astype(NumericalType)
        })

    def _inverse_normalize(self, normalized: pd.DataFrame) -> pd.Series:
        normalized = normalized.loc[:, MainValueColumn]
        recovered = normalized.apply(
            lambda x: self.pos_label if x >= self.threshold or len(self._neg_pool) <= 0
            else self._neg_pool.sample().iloc[0]
        )
        return recovered

    @property
    def normalized_span_info(self) -> List[Tuple[int, SType]]:
        return [(1, SType.binary)]

    @classmethod
    def validate_kwargs(cls, args: Dict[str, Any]):
        schema = {
            "type": "object",
            "properties": {
                "threshold": {
                    "type": "number",
                    "minimum": 0,
                    "maximum": 1
                }
            }
        }
        jsonschema.validate(instance=args, schema=schema)

        args = deepcopy(args)
        if "threshold" in args:
            del args["threshold"]
        cls._validate_kwargs_common(args)
