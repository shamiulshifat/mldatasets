"""Binary normalizer that uses two columns to represent a binary standard column."""

from typing import Any, Dict, List, Tuple

import pandas as pd

from .base import BinaryNormalizerMethods, BinaryNormalizer
from ..base import MainValueColumn, NumericalType
from ....dtypes import SType
from ....utils import register


@register(BinaryNormalizer.sub_registry, BinaryNormalizerMethods.double)
class DoubleBinaryNormalizer(BinaryNormalizer):
    """
    Binary column normalizer by comparing pos-to-neg two columns.
    """
    def _fit_boolean(self, data: pd.Series):
        self.normalized_columns = [f"{MainValueColumn}-pos", f"{MainValueColumn}-neg"]

    def _normalize(self, data: pd.Series) -> pd.DataFrame:
        pos = self._construct_boolean(data)
        neg = ~pos
        return pd.DataFrame({
            f"{MainValueColumn}-pos": pos.astype(NumericalType),
            f"{MainValueColumn}-neg": neg.astype(NumericalType)
        })

    def _inverse_normalize(self, normalized: pd.DataFrame) -> pd.Series:
        recovered = normalized.apply(
            lambda row: self.pos_label if
            row[f"{MainValueColumn}-pos"] >= row[f"{MainValueColumn}-neg"]
            else self._neg_pool.sample().iloc[0], axis=1
        )
        return recovered

    @property
    def normalized_span_info(self) -> List[Tuple[int, SType]]:
        return [(2, SType.multiclass)]

    @classmethod
    def validate_kwargs(cls, args: Dict[str, Any]):
        cls._validate_kwargs_common(args)
