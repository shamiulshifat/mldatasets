"""Shared structure and processing of handling binary data."""

import enum
from abc import ABC, abstractmethod
from typing import Any, Dict, Optional, Type, Union

import jsonschema
import pandas as pd

from ..base import StdColumnNormalizer
from ....dtypes import ColumnName, SType
from ....utils import make_enum, register


class BinaryNormalizerMethods(enum.Enum):
    """Methods of normalizing binary values."""

    single = enum.auto()
    """Using one column and comparing it to a threshold to tell which class this is."""
    double = enum.auto()
    """Constructing two columns, one positive and one negative, and comparing among them to tell which class this is."""


@register(StdColumnNormalizer.registry, SType.binary)
class BinaryNormalizer(StdColumnNormalizer, ABC):
    """
    Binary column normalizer.
    """
    sub_registry: Dict[BinaryNormalizerMethods, Type["BinaryNormalizer"]] = {}
    """Sub-registry of binary for different methods."""

    def __init__(self,
                 name: str = "",
                 parent: ColumnName = "",
                 *,
                 pos_label: Optional = None):
        """
        Parameters
        ----------
        pos_label : optional
            The positive label of the binary column.
            If not provided, we will pick the value with the highest frequency, breaking tie by
            the order of appearance in data (pandas `value_counts` implementation).
            All other values will be considered as negative.
        Other parameters are inherited from parent `StdColumnNormalizer`.
        """
        super().__init__(name, parent)
        self.pos_label = pos_label
        self._neg_pool = None

    @property
    def stype(self) -> SType:
        return SType.binary

    @classmethod
    def make(cls,
             stype: Union[str, SType],
             method_type: Union[str, BinaryNormalizerMethods] = BinaryNormalizerMethods.single,
             *args, **kwargs) -> "BinaryNormalizer":
        method_type = make_enum(method_type, BinaryNormalizerMethods)
        return cls.sub_registry[method_type](*args, **kwargs)

    def _fit(self, data: pd.Series):
        if self.pos_label is None:
            value_counts = data.value_counts()
            self.pos_label = value_counts.index[0]
        is_pos = data == self.pos_label
        self._neg_pool = data[~is_pos].reset_index(drop=True)
        self._fit_boolean(is_pos)

    @abstractmethod
    def _fit_boolean(self, data: pd.Series):
        raise NotImplementedError()

    def _construct_boolean(self, data: pd.Series) -> pd.Series:
        return data == self.pos_label

    @classmethod
    def validate_kwargs(cls, args: Dict[str, Any]):
        method = args.get("method_type", "single")
        cls.sub_registry[BinaryNormalizerMethods[method]].validate_kwargs(args)

    @classmethod
    def _validate_kwargs_common(cls, args: Dict[str, Any]):
        schema = {
            "type": "object",
            "properties": {
                "pos_label": {},
                "method_type": {
                    "type": "string",
                    "enum": ["single", "double"]
                }
            },
            "additionalProperties": False
        }
        jsonschema.validate(instance=args, schema=schema)
