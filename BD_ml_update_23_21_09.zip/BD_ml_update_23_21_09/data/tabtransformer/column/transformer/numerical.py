"""Transformer for handling numerical data."""

import math
from copy import deepcopy
from typing import Any, Dict, Optional, Union

import jsonschema
import numpy as np
import pandas as pd
from scipy.stats import normaltest, skewtest

from .base import ColumnTransformer, FillNaPolicy, MainValueColumn
from ..normalizer import StdColumnNormalizer
from ..normalizer.numerical import NumericalNormalizer, NumericalNormalizerMethods
from ...dtypes import ColumnName, RawDType, SType
from ...utils import make_enum, register


@register(ColumnTransformer.registry, RawDType.numerical)
class NumericalTransformer(ColumnTransformer):
    """
    Column transformer to numerical matrix for numerical raw data type.
    """
    def __init__(self,
                 name: ColumnName = "",
                 *,
                 fillna_value: Optional[float] = None,
                 fillna_policy: Union[FillNaPolicy, str] = FillNaPolicy.sample,
                 **kwargs):
        """
        Parameters
        ----------
        **kwargs
            Other arguments to make a
            [numerical normalizer](/tabtransformer/column/normalizer/numerical#tabtransformer.column.normalizer.numerical.NumericalTransformer.make).
        Other parameters are inherited from parent `ColumnTransformer`.
        """
        super().__init__(
            name,
            fillna_value=fillna_value,
            fillna_policy=fillna_policy
        )
        self._kwargs = kwargs

    def _fit_cleaned(self, data: pd.Series):
        self._standardized_dtypes[MainValueColumn] = SType.numerical
        self.normalizers[MainValueColumn] = StdColumnNormalizer.make(
            SType.numerical,
            name=MainValueColumn, parent=self.name,
            **self._kwargs
        )

    @property
    def raw_dtype(self) -> RawDType:
        return RawDType.numerical

    @classmethod
    @register(ColumnTransformer.args_learner, RawDType.numerical)
    def learn_args(cls,
                   data: pd.Series,
                   **kwargs) -> Dict[str, Any]:
        """
        We will do the following in sequence:

        1. Infer a rounding if not provided. We will try the rounding values [-15, 15] increasingly until the rounding
           does not change any of the values. If no success in this range, we will keep the rounding parameter as None.
        2. If rounding is provided or learned, learn the unit by GCD on the number of rounding units.
        3. Fix the range, if `"min_val"` and `"max_val"` are not provided, based on the values of `enforce_min` and
           `enforce_max` as described below.
        4. Check long-tail distribution. We will do a normal test on log values of the data, and a skew test on the
           original data. If both have p-values smaller than `p_value_threshold`, we consider this column to be
           long-tail distributed, and a log transformation will be applied on the data.
        5. If the method type is cluster-based (default in numerical raw data type overriden by provided method),
           we will further update the default arguments for multi-class normalizer in the learned argument.

        Parameters
        ----------
        enforce_min : bool, optional
            Whether to enforce the minimum value as the value range.
            If not provided, we will check only the following scenarios:

            - If all values cover consecutive integers (every value should occur).
            - If all values are positive/non-negative.
            - If all values are within [-1, 1].
        enforce_max : bool, optional
            Whether to enforce the maximum value as the value range.
            If not provided, we will check only the following scenarios:

            - If all values cover consecutive integers (every value should occur).
            - If all values are negative/non-positive.
            - If all values are within [-1, 1].
        p_value_threshold : float, optional
            The p-value threshold for long tail test above. Default is 0.05.
        Other parameters are inherited from parent
        [`ColumnTransformer.learn_args`](/tabtransformer/column/transformer#tabtransformer.column.transformer.ColumnTransformer.learn_args).
       """
        return super().learn_args(
            data,
            raw_dtype=RawDType.numerical,
            **kwargs
        )

    @classmethod
    @register(ColumnTransformer._args_learner, RawDType.numerical)
    def _learn_args(cls,
                    data: pd.Series,
                    *,
                    default_args: Dict[str, Any],
                    provided_args: Dict[str, Any],
                    default_norm_args_by_stype: Dict[SType, Dict[str, Any]],
                    enforce_min: Optional[bool] = None,
                    enforce_max: Optional[bool] = None,
                    p_value_threshold: float = .05,
                    **kwargs) -> Dict[str, Any]:
        args = deepcopy(default_norm_args_by_stype[SType.numerical])
        args.update(default_args)
        full_data = data.dropna()
        if len(full_data) <= 0:
            return args

        data = full_data.drop_duplicates()

        if "rounding" not in provided_args:
            for r in range(-15, 16):
                rounded = data.apply(
                    lambda x: round(x, r)
                )
                if (rounded == data).sum() == len(data):
                    args["rounding"] = r
                    break

        rounding = provided_args.get("rounding", args.get("rounding"))
        if "unit" not in provided_args and rounding is not None:
            single_unit = 10 ** (-rounding)
            units = data.apply(
                lambda x: round(x / single_unit)
            )
            gcd = math.gcd(*units)
            if gcd == 0:
                gcd = 1
            args["unit"] = gcd

        unit = provided_args.get("unit", args.get("unit"))
        data = cls._round(data, rounding, unit)

        if "min_val" not in provided_args or "max_val" not in provided_args:
            min_val = data.min()
            max_val = data.max()
            enforce_min = provided_args.get("enforce_min", args.get("enforce_min", enforce_min))
            enforce_max = provided_args.get("enforce_max", args.get("enforce_max", enforce_max))

            arg_min_val = None
            if enforce_min:
                arg_min_val = min_val
            elif enforce_min is None:
                if min_val >= 0:
                    arg_min_val = 0
                elif min_val >= -1 and max_val <= 1:
                    arg_min_val = -1
                if rounding == 0:
                    if len(data) == max_val - min_val + 1:
                        arg_min_val = min_val
            if arg_min_val is not None:
                args["min_val"] = arg_min_val

            arg_max_val = None
            if enforce_max:
                arg_max_val = max_val
            elif enforce_max is None:
                if max_val <= 0:
                    arg_max_val = 0
                elif min_val >= -1 and max_val <= 1:
                    arg_max_val = 1
                if rounding == 0:
                    if len(data) == max_val - min_val + 1:
                        arg_max_val = max_val
            if arg_max_val is not None:
                args["max_val"] = arg_max_val

        if "transforms" not in provided_args:
            is_long_tail = provided_args.get("is_long_tail")
            if is_long_tail is None:
                try:
                    full_data = cls._round(data, rounding, unit)
                    _, p1 = normaltest(np.log(full_data.values + full_data.min() + 1))
                    is_log_normal = (not pd.isnull(p1)) and p1 <= p_value_threshold
                    _, p2 = skewtest(full_data.values)
                    is_skew = (not pd.isnull(p2)) and p2 <= p_value_threshold
                    is_long_tail = is_log_normal and is_skew
                except Exception:
                    is_long_tail = False
            if is_long_tail:
                args["transforms"] = [
                    ("log", {"min_val": provided_args.get("min_val", args.get("min_val"))})
                ]

        method_type: NumericalNormalizerMethods = make_enum(
            provided_args.get("method_type",
                              args.get("method_type", NumericalNormalizerMethods.cluster_based)),
            NumericalNormalizerMethods
        )
        if method_type == NumericalNormalizerMethods.cluster_based:
            old = deepcopy(default_norm_args_by_stype[SType.multiclass])
            old.update(args)
            args = old

        return args

    @classmethod
    def _round(cls, data: pd.Series, rounding: Optional[int] = None, unit: Optional[int] = 1) -> pd.Series:
        if rounding is not None:
            data = data.apply(lambda x: round(x, rounding))
            if unit is not None:
                unit = unit * (10 ** (-rounding))
                data = data.apply(lambda x: unit * round(x / unit))
        return data

    @classmethod
    def validate_kwargs(cls, args: Dict[str, Any]):
        schema = {
            "type": "object",
            "properties": {
                "fillna_value": {
                    "type": ["number", "null"]
                },
                "fillna_policy": {
                    "type": "string",
                    "enum": ["mean", "min", "special", "sample"]
                },
                "enforce_min": {
                    "type": "boolean"
                },
                "enforce_max": {
                    "type": "boolean"
                },
                "raw_dtype": {
                    "enum": ["numerical"]
                }
            }
        }
        jsonschema.validate(instance=args, schema=schema)

        args = deepcopy(args)
        for c in ["fillna_value", "fillna_policy", "raw_dtype"]:
            if c in args:
                del args[c]

        NumericalNormalizer.validate_kwargs(args)
