"""Transformer for handling datetime data."""

import enum
import math
import time
from copy import deepcopy
from typing import Any, Dict, List, Optional, Union

from datetime import datetime, timedelta

import jsonschema
import pandas as pd

from .base import ColumnTransformer, FillNaPolicy, MainValueColumn
from ..normalizer import StdColumnNormalizer
from ..normalizer.binary import BinaryNormalizer
from ..normalizer.multiclass import MulticlassNormalizer
from ..normalizer.numerical import NumericalNormalizer
from ...dtypes import ColumnName, RawDType, SType
from ...utils import filter_dict, make_dict, make_enum, make_list, register


class TimeUnit(enum.Enum):
    """Unit for date-time/time-delta."""

    year = enum.auto()
    month = enum.auto()
    day = enum.auto()
    hour = enum.auto()
    minute = enum.auto()
    second = enum.auto()
    microsecond = enum.auto()

    def construct_datetime(self, ref: datetime, value: int) -> datetime:
        """
        Calculate the datetime by a base and the number of units different.

        Parameters
        ----------
        ref : datetime
            The base datetime value.
        value : int
            The difference, namely, the number of units to add to ref.

        Returns
        -------
        datetime
            The constructed datetime.
        """
        if value < 0:
            raise ValueError("We do not support calculation of negative difference.")
        if self == TimeUnit.year:
            return datetime(
                year=ref.year + value,
                month=ref.month,
                day=ref.day,
                hour=ref.hour,
                minute=ref.minute,
                second=ref.second,
                microsecond=ref.microsecond
            )
        elif self == TimeUnit.month:
            month = ref.month + value - 1
            diff_year = month // 12
            month = month % 12 + 1
            return datetime(
                year=int(ref.year + diff_year),
                month=int(month),
                day=ref.day,
                hour=ref.hour,
                minute=ref.minute,
                second=ref.second,
                microsecond=ref.microsecond
            )
        if self == TimeUnit.day:
            diff = timedelta(days=value)
        elif self == TimeUnit.hour:
            diff = timedelta(hours=value)
        elif self == TimeUnit.minute:
            diff = timedelta(minutes=value)
        elif self == TimeUnit.second:
            diff = timedelta(seconds=value)
        elif self == TimeUnit.microsecond:
            diff = timedelta(microseconds=value)
        else:
            raise NotImplementedError(f"Time unit {self.name} is not recognized.")
        return ref + diff

    def diff_unit(self, this: datetime, ref: datetime) -> int:
        """
        Calculate the number of units different.

        Parameters
        ----------
        this : datetime
            The minuend datetime value.
        ref : datetime
            The subtrahend datetime value.

        Returns
        -------
        int
            The number of units different.
        """
        if ref > this:
            raise ValueError("We do not support calculation of negative difference.")
        if self == TimeUnit.year:
            return this.year - ref.year
        elif self == TimeUnit.month:
            by_year = 12 * (this.year - ref.year)
            total_moths = by_year + this.month - ref.month
            return total_moths
        days = (this - ref).days
        if self == TimeUnit.day:
            return days
        seconds = (this - ref).seconds
        seconds += days * 24 * 60 * 60
        if self == TimeUnit.hour:
            return seconds // (60 * 60)
        elif self == TimeUnit.minute:
            return seconds // 60
        elif self == TimeUnit.second:
            return seconds
        microseconds = (this - ref).microseconds
        microseconds += seconds * 1e6
        if self == TimeUnit.microsecond:
            return microseconds
        raise NotImplementedError(f"Time unit {self.name} is not recognized.")

    @classmethod
    def all(cls, ascending: bool = True) -> List["TimeUnit"]:
        """
        List all units in order.

        Parameters
        ----------
        ascending : bool, optional
            Whether to order the units in increasing order.
            Default is True.
        """
        result = [
            TimeUnit.microsecond, TimeUnit.second, TimeUnit.minute, TimeUnit.hour,
            TimeUnit.day, TimeUnit.month, TimeUnit.year
        ]
        if ascending:
            return result
        return result[::-1]

    @property
    def default_directive(self) -> str:
        """Default directive of this time unit."""
        if self == TimeUnit.year:
            return "%Y"
        if self == TimeUnit.month:
            return "%m"
        if self == TimeUnit.day:
            return "%d"
        if self == TimeUnit.hour:
            return "%H"
        if self == TimeUnit.minute:
            return "%M"
        if self == TimeUnit.second:
            return "%S"
        if self == TimeUnit.microsecond:
            return "%f"
        raise NotImplementedError(f"Time unit {self.name} is not recognized.")

    @property
    def _suffix(self) -> str:
        if self == TimeUnit.year or self == TimeUnit.month:
            return "-"
        if self == TimeUnit.day:
            return " "
        if self == TimeUnit.hour or self == TimeUnit.minute:
            return ":"
        if self == TimeUnit.microsecond:
            return "."
        raise NotImplementedError(f"Time unit {self.name} is not recognized.")

    @classmethod
    def default_format(cls,
                       start: Union[str, "TimeUnit"] = "year",
                       end: Union[str, "TimeUnit"] = "microseconds") -> str:
        """
        Get the default format string for all units in start to end range.

        Parameters
        ----------
        start : str or TimeUnit
            The largest time unit.
        end : str or TimeUnit
            The smallest time unit.

        Returns
        -------
        str
            The constructed format string.
        """
        units = cls.all(False)
        start = make_enum(start, TimeUnit)
        end = make_enum(end, TimeUnit)
        st_idx = units.index(start)
        ed_idx = units.index(end)
        result = ""
        suffix = ""
        for unit in units[st_idx:ed_idx + 1]:
            result += suffix + unit.default_directive
            suffix = unit._suffix
        return result


@register(ColumnTransformer.registry, RawDType.datetime)
class DatetimeTransformer(ColumnTransformer):
    """
    Column transformer to numerical matrix for date-time raw data type.
    """
    _directive_typed_pool = {
        "binary": {"%p"},
        "multiclass": {"%a", "%A", "%b", "%B", "%Z"},
        "numerical": {
            "%w", "%d", "%m", "%y", "%Y", "%H", "%I", "%M", "%S", "%f", "%j", "%U", "%W", "%C", "%G", "%u", "%v"
        },
        "null_numerical": {"%z"},
        "seconds": {"%c", "%X"},
        "day": {"%x"}
    }
    _directive_types = {
        d: t for t, ds in
        _directive_typed_pool.items()
        for d in ds
    }
    _invalid_date_only = {
        "%H", "%I", "%p", "%M", "%S", "%f", "%c", "%X"
    }
    _invalid_time_only = {
        "%a", "%A", "%w", "%d", "%b", "%B", "%m", "%y", "%Y", "%j", "%U", "%W", "%c", "%C", "%x", "%G", "%u", "%V"
    }
    _default_dir_args = {
        "%w": dict(rounding=0, min_val=0, max_val=6),
        "%d": dict(rounding=0, min_val=1, max_val=31),
        "%m": dict(rounding=0, min_val=1, max_val=12),
        "%y": dict(rounding=0, min_val=0, max_val=99),
        "%Y": dict(rounding=0, min_val=1, max_val=9999),
        "%H": dict(rounding=0, min_val=0, max_val=23),
        "%I": dict(rounding=0, min_val=0, max_val=12),
        "%M": dict(rounding=0, min_val=0, max_val=59),
        "%S": dict(rounding=0, min_val=0, max_val=59),
        "%f": dict(rounding=0, min_val=0, max_val=999999),
        "%z": dict(rounding=2, min_val=-12, max_val=12),
        "%j": dict(rounding=0, min_Val=1, max_val=366),
        "%U": dict(rounding=0, min_val=0, max_val=53),
        "%W": dict(rounding=0, min_val=0, max_val=53),
        "%C": dict(rounding=0, min_val=0, max_val=99),
        "%x": dict(rounding=0, min_val=0),
        "%c": dict(rounding=0, min_val=0),
        "%X": dict(rounding=0, min_val=0),
        "%G": dict(rounding=0, min_val=1, max_val=9999),
        "%u": dict(rounding=0, min_val=1, max_val=7),
        "%V": dict(rounding=0, min_val=1, max_val=53),
    }
    _default_format = "%Y-%m-%d %H:%M:%S.%f"

    def __init__(self,
                 name: ColumnName = "",
                 *,
                 fillna_value: Optional = None,
                 fillna_policy: Union[FillNaPolicy, str] = FillNaPolicy.sample,
                 datetime_format: Optional[str] = None,
                 date_only: bool = False,
                 time_only: bool = False,
                 unit: Union[TimeUnit, str] = TimeUnit.microsecond,
                 smallest_chunk: int = 1,
                 as_numerical: bool = True,
                 separate: Optional[List[str]] = None,
                 main_separate: Optional[List[str]] = None,
                 validate: bool = False,
                 dir_norm_args: Optional[Dict[str, Dict[str, Any]]] = None,
                 **kwargs):
        """
        Parameters
        ----------
        datetime_format : str, optional
            The datetime format string (under Python implementation).
            If not provided, only datetime format understood in `pd.to_datetime` are allowed,
            and the format of reconstructed data will be using "%Y-%m-%d %H:%M:%S.%f".
        date_only : bool, optional
            Whether this datetime column has only date, without detailed timing within the day.
        time_only : bool, optional
            Whether this datetime column has only time, without exact date.
        unit : TimeUnit, optional
            The smallest time unit in this column.
            If not provided, the smallest unit, microsecond, is used.
        smallest_chunk : int, optional
            The smallest chunk in the unit. If not provided, 1 is used.
        as_numerical : bool, optional
            Whether to convert the entire date-time value as a numerical value (will in fact be integer).
            This will be done by default.
        separate : list[str], optional
            The list of Python datetime directives to convert the data to.
            If not provided, no directives are used for conversion.
            If `as_numerical` is `False`, please make sure this list is sufficient to recover the complete datetime.
        main_separate : list[str], optional
            A subset of separate.
            In the case where `as_numerical` is `False`, this subset will be used to determine the datetime value.
            This subset should not have conflict within itself (for example, %Y and %y cannot appear together).
            We will not check on the validity of non-conflict. So please check the conflict on your own.
            If `as_numerical` is `False` and `main_separate` is not provided, the complete list of `separate` is used.
        validate : bool, optional
            Whether to validate the input.
        dir_norm_args : dict[str, dict[str, ]], optional
            No normalization args per directive given in `separate`.
        **kwargs
            Prefixed with "main_".
            Parameters to make the
            [numerical normalizer](/tabtransformer/column/normalizer/numerical#tabtransformer.column.normalizer.numerical.NumericalTransformer.make)
            for the main value (the value constructed where `as_numerical` is set True).
            Unmentioned parameters will use the values from `default_num_`*.
        Other parameters are inherited from parent `ColumnTransformer`.
        """
        super().__init__(
            name,
            fillna_value=fillna_value, fillna_policy=fillna_policy
        )
        separate = make_list(separate)
        if not as_numerical and main_separate is None:
            main_separate = separate
        if validate:
            self._validate(datetime_format, separate, main_separate, date_only, time_only)
        self.datetime_format = datetime_format
        self.date_only = date_only
        self.time_only = time_only
        self.smallest_chunk = smallest_chunk
        self.unit: TimeUnit = make_enum(unit, TimeUnit)
        self.as_numerical = as_numerical
        self.separate = separate
        self.main_separate = main_separate

        self._min = None

        self._main_args = filter_dict(kwargs, "main_")

        dir_norm_args = make_dict(dir_norm_args)
        self._dir_args = {
            directive: make_dict(dir_norm_args.get(directive))
            for directive in self.separate
        }

    def _validate(self, datetime_format: str, separate: List[str], main_separate: List[str],
                  date_only: bool, time_only: bool):
        if date_only and time_only:
            raise ValueError("Cannot have both date and time only.")
        for directive in separate:
            if directive not in self._directive_types:
                raise ValueError(f"Datetime directive {directive} is not recognized.")
        format_directives = []
        while "%" in datetime_format:
            datetime_format = datetime_format[datetime_format.index("%"):]
            directive = datetime_format[:2]
            if directive in self._directive_types:
                format_directives.append(directive)
        if date_only:
            for directive in separate + format_directives:
                if directive in self._invalid_date_only:
                    raise ValueError(f"Directive {directive} is invalid for date only.")
        if time_only:
            for directive in separate + format_directives:
                if directive in self._invalid_time_only:
                    raise ValueError(f"Directive {directive} is invalid for time only.")
        if not {*main_separate} <= {*separate}:
            raise ValueError("The main separate list is not a subset of the separate list.")

    def _convert_dtype(self, data: pd.Series) -> pd.Series:
        try:
            return data.astype(self.raw_dtype.default_dtype)
        except Exception:
            return pd.to_datetime(data, errors="coerce", format=self.datetime_format)

    def _standardize_main_val(self, x: datetime) -> int:
        return self.unit.diff_unit(x, self._min) // self.smallest_chunk

    def _standardize(self, data: pd.Series, retain_non_std: bool = False) -> pd.DataFrame:
        out = {}
        if self.as_numerical:
            out[MainValueColumn] = data.apply(self._standardize_main_val)
        for directive in self.separate:
            column_name = directive.replace("%", "d-")
            extracted = data.apply(
                lambda x: x.strftime(directive)
            )
            dir_type = self._directive_types[directive]
            if dir_type == "null_numerical":
                out[f"{column_name}-isna"] = extracted == ""
                extracted = extracted.replace({"": "+0000"})
            if "numerical" in dir_type:
                extracted = extracted
            elif dir_type == "seconds":
                extracted = extracted.apply(
                    lambda x: time.mktime(datetime.strptime(x, directive).timetuple())
                )
            elif dir_type == "day":
                extracted = extracted.apply(
                    lambda x: datetime.strptime(x, directive).toordinal()
                )
            out[column_name] = extracted
        return pd.DataFrame(out)

    def _inverse_standardize(self, standardized: pd.DataFrame) -> pd.Series:
        if self.as_numerical:
            units = standardized.loc[:, MainValueColumn] * self.smallest_chunk
            recovered = units.apply(lambda x: self.unit.construct_datetime(self._min, x))
        else:
            for directive in self._directive_types["null_numerical"]:
                column_name = directive.replace("%", "d-")
                if column_name in standardized.columns:
                    standardized.loc[:, column_name] = standardized.apply(
                        lambda row: "" if row[f"{column_name}-isna"] else row[column_name]
                    )
                    standardized = standardized.drop(columns=[f"{column_name}-isna"])
            full_format = "-".join(self.main_separate)
            recovered = standardized.apply(
                lambda row: datetime.strptime(
                    "-".join(row[[d.replace("%", "d-") for d in self.main_separate]].tolist()),
                    full_format
                )
            )
        if self.datetime_format is not None:
            recovered = recovered.apply(lambda x: x.strftime(self.datetime_format))\
                .astype(self.raw_dtype.default_dtype)
        return recovered

    def _fit_cleaned(self, data: pd.Series):
        self._min = data.min()
        if self.as_numerical:
            if isinstance(self._main_args.get("min_val"), datetime):
                self._main_args["min_val"] = self._standardize_main_val(self._main_args["min_val"])
            if isinstance(self._main_args.get("max_val"), datetime):
                self._main_args["max_val"] = self._standardize_main_val(self._main_args["max_val"])
            if "rounding" not in self._main_args:
                self._main_args["rounding"] = 0
            self._standardized_dtypes[MainValueColumn] = SType.numerical
            self.normalizers[MainValueColumn] = StdColumnNormalizer.make(
                SType.numerical,
                name=MainValueColumn, parent=self.name,
                **self._main_args
            )
        else:
            separate_format = "-".join(self.separate)
            converted = data.apply(
                lambda x: datetime.strptime(x.strftime(separate_format), separate_format)
            )
            if (converted - data).sum() != timedelta(0):
                raise RuntimeError("The separate directives cannot be used to recover the date-time completely.")

        for directive in self.separate:
            dir_type = self._directive_types[directive]
            column_name = directive.replace("%", "d-")
            if dir_type == "binary":
                self._standardized_dtypes[column_name] = SType.binary
            elif dir_type == "multiclass":
                self._standardized_dtypes[column_name] = SType.multiclass
            else:
                self._standardized_dtypes[column_name] = SType.numerical
                if dir_type == "null_numerical":
                    self._standardized_dtypes[f"{column_name}-isna"] = SType.binary
                    self.normalizers[f"{column_name}-isna"] = StdColumnNormalizer.make(
                        SType.binary, "single", name=f"{column_name}-isna", parent=self.name
                    )
            self.normalizers[column_name] = StdColumnNormalizer.make(
                self._standardized_dtypes[column_name],
                name=column_name, parent=self.name,
                **self._dir_args[directive]
            )

    @property
    def raw_dtype(self) -> RawDType:
        return RawDType.datetime

    @classmethod
    @register(ColumnTransformer.args_learner, RawDType.datetime)
    def learn_args(cls,
                   data: pd.Series,
                   **kwargs) -> Dict[str, Any]:
        """
        We will do the following in sequence:

        1. Infer whether the data is date-only or time-only.
            1. If date-only or time-only is provided to be true, take this value.
               If the two conflict, we prioritize date-only.
            2. If datetime format is provided, and if it does not contain time information, we consider this column to
               be date-only, and if it does not contain date information, we consider this column to be time-only.
            3. If there is default value provided as True, we assume that this is what the user wants. That is, if no
               inference based on the provided arguments is done according to the previous two steps, but default value
               is provided and is True, we consider this value as what the user expects.
               Since the most flexible assumption is that the data is neither date-only nor time-only, so we will
               continue to learn if they are set False in default.
            4. If the date does not change in the full column, the column is considered time-only. Similarly, if the
               time does not change in the full column, the column is considered date-only.
        2. Learn the time unit of the column. We will iterate all time units, starting from the smallest (microsecond
           if not date-only, and day if date-only), until the largest, or until there is variation in the column
           (whichever comes first). For example, for 12:30:00 and 12:45:00, the unit learned will be minute because
           there is variation in minute level but not in second or microsecond.
           Because the number of time units is a finite set, so there must be a unit learned.
        3. Based on the unit learned, the smallest chunk can be easily obtained by converting the datetime data into
           integer by the number of units, and obtaining the smallest chunk by GCD.
        4. If the input data is given as datetime instead of strings, we will provide a default datetime format from the
           largest unit (year if not time-only and hour if time-only) to the unit provided or learned.
        5. Fix the range of the data if enforcement is required by `enforce_min` or `enforce_max`.
           That is, if the `"main_min_val"` is not provided but `enforce_min` is set True, `"main_min_val"` will be
           the minimum value of the data. Maximum is learned similarly.
        6. If there are directives provided in `"separate"`, we will need to learn the normalizer arguments for each of
           them.
           Each directive, based on its nature, will have its own default normalizer arguments, which is pre-defined.
           The arguments learned for directives' normalizers will follow the order that default normalizer arguments
           for the standard type of this directive, overriden by the pre-defined default values, overriden by default
           values for datetime raw data type, overriden by provided arguments.
        7. Finally, we will use the integer data converted based on unit and smallest chunk learned to obtain the
           learned arguments for the main value using the learner for
           [numerical transformer](/tabtransformer/column/transformer/numerical#tabtransformer.column.transformer.numerical.NumericalTransformer.learn_args),
           and add prefix "main_" to them.

        Parameters
        ----------
        enforce_min : bool, optional
            Whether to enforce the minimum value as the value range.
            If not provided, we will not restrict the range.
        enforce_max : bool, optional
            Whether to enforce the maximum value as the value range.
            If not provided, we will not restrict the range.
        Other parameters are inherited from parent
        [`ColumnTransformer.learn_args`](/tabtransformer/column/transformer#tabtransformer.column.transformer.ColumnTransformer.learn_args).
        """
        return super().learn_args(
            data,
            raw_dtype=RawDType.numerical,
            **kwargs
        )

    @classmethod
    @register(ColumnTransformer._args_learner, RawDType.datetime)
    def _learn_args(cls,
                    data: pd.Series,
                    *,
                    default_args: Dict[str, Any],
                    provided_args: Dict[str, Any],
                    default_norm_args_by_stype: Dict[SType, Dict[str, Any]],
                    enforce_min: bool = False,
                    enforce_max: bool = False,
                    **kwargs) -> Dict[str, Any]:
        args = deepcopy(default_args)
        if provided_args.get("date_only", False):
            provided_args["time_only"] = False
        if provided_args.get("time_only", False):
            provided_args["date_only"] = False

        strings = [x for x in data if isinstance(x, str)]
        data = pd.to_datetime(data, errors="coerce", format=provided_args.get("datetime_format")).dropna()
        if len(data) <= 0:
            return args

        if "date_only" not in provided_args and "time_only" not in provided_args:
            if "datetime_format" in provided_args:
                format_str = provided_args["datetime_format"]
                valid_date_only = True
                valid_time_only = True
                while "%" in format_str:
                    format_str = format_str[format_str.index("%"):]
                    directive = format_str[:2]
                    if directive not in cls._directive_types:
                        continue
                    if directive in cls._invalid_date_only:
                        valid_date_only = False
                    if directive in cls._invalid_time_only:
                        valid_time_only = False
                if valid_date_only:
                    args["date_only"] = True
                    args["time_only"] = False
                elif valid_time_only:
                    args["time_only"] = True
                    args["date_only"] = False
            if "date_only" not in args or (not args.get("date_only", False) and not args.get("time_only", False)):
                days = data.apply(lambda x: datetime(year=x.year, month=x.month, day=x.day))
                if len(days) == (days == days.mean()).sum():
                    args["time_only"] = True
                    args["date_only"] = False
            if "time_only" not in args or (not args.get("date_only", False) and not args.get("time_only", False)):
                seconds = data.apply(lambda x: datetime(year=1970, month=1, day=1,
                                                        hour=x.hour, minute=x.minute, second=x.second,
                                                        microsecond=x.microsecond))
                if len(seconds) == (seconds == seconds.mean()).sum():
                    args["date_only"] = True
                    args["time_only"] = False

        if "unit" not in provided_args:
            format_str = ""
            date_only = provided_args.get("date_only", args.get("date_only"))
            for unit in TimeUnit.all():
                if date_only and unit > TimeUnit.day:
                    continue
                format_str = unit.default_directive + "-" + format_str
                converted = data.apply(
                    lambda x: datetime.strptime(x.strftime(format_str), format_str)
                )
                if len(converted) > (converted == converted.mean()).sum():
                    break
            args["unit"] = unit

        if "smallest_chunk" not in provided_args:
            unit = provided_args.get("unit", args.get("unit"))
            units = data.apply(
                lambda x: int(x.strftime(unit.default_directive))
            )
            gcd = 0
            for u in units:
                gcd = math.gcd(u, gcd)
            if gcd == 0:
                gcd = 1
            args["smallest_chunk"] = gcd
        smallest_chunk = provided_args.get("smallest_chunk", args.get("smallest_chunk", 1))

        if "datetime_format" not in provided_args:
            if len(strings) <= 0:
                unit = provided_args.get("unit", args.get("unit"))
                time_only = provided_args.get("time_only", args.get("time_only"))
                if time_only:
                    start = TimeUnit.hour
                else:
                    start = TimeUnit.year
                args["datetime_format"] = TimeUnit.default_format(start, unit)

        enforce_min = provided_args.get("enforce_min", args.get("enforce_min", enforce_min))
        enforce_max = provided_args.get("enforce_max", args.get("enforce_max", enforce_max))
        if enforce_min and "main_min_val" not in provided_args:
            args["main_min_val"] = data.min()
        if enforce_max and "main_max_val" not in provided_args:
            args["main_max_val"] = data.min()
        for key, src in zip(
            ["main_min_val", "main_min_val", "main_max_val", "main_max_val"],
            [args, provided_args, args, provided_args]
        ):
            if isinstance(src.get(key), str):
                src[key] = pd.to_datetime(src[key], format=provided_args.get("datetime_format"))

        directives = provided_args.get("separate", args.get("separate", []))
        given_dir_norm_args = {}
        for k, k_args in args.get("dir_norm_args", {}):
            given_dir_norm_args[k] = k_args
        for k, k_args in provided_args.get("dir_norm_args", {}):
            if k not in given_dir_norm_args:
                given_dir_norm_args[k] = k_args
            else:
                given_dir_norm_args[k].update(k_args)
        dir_norm_args = {}
        for directive in directives:
            default_args = make_dict(cls._default_dir_args.get(directive))
            this_args = make_dict(given_dir_norm_args.get(directive))
            d_args = deepcopy(default_args)
            if cls._directive_types[directive] == "binary":
                d_args.update(default_norm_args_by_stype[SType.binary])
            elif cls._directive_types[directive] == "multiclass":
                d_args.update(default_norm_args_by_stype[SType.multiclass])
            else:
                d_args.update(default_norm_args_by_stype[SType.numerical])
            d_args.update(this_args)
            dir_norm_args[directive] = d_args
        args["dir_norm_args"] = dir_norm_args

        main_values = data.apply(lambda x: unit.diff_unit(x, data.min()) // smallest_chunk)
        num_args = cls._args_learner[RawDType.numerical](
            cls=cls.registry[RawDType.numerical],
            data=main_values,
            default_args=default_norm_args_by_stype[SType.numerical],
            provided_args=provided_args,
            default_norm_args_by_stype=default_norm_args_by_stype
        )
        main_args = deepcopy(default_norm_args_by_stype[SType.numerical])
        main_args.update(num_args)
        for k, v in main_args.items():
            args[f"main_{k}"] = v

        return args

    @classmethod
    def validate_kwargs(cls, args: Dict[str, Any]):
        chunk_predicates = []
        for unit, max_chunk in zip(
                ["year", "month", "day", "hour", "minute", "second", "microsecond"],
                [9999, 12, 31, 24, 60, 60, 1000000]
        ):
            chunk_predicates.append({
                "if": {
                    "properties": {
                        "unit": {
                            "const": unit
                        }
                    }
                },
                "then": {
                    "properties": {
                        "smallest": {
                            "maximum": max_chunk
                        }
                    }
                }
            })
        all_directives = [*cls._directive_types]
        unique_directives = {
            "type": "array",
            "items": {
                "type": "string",
                "enum": all_directives
            },
            "uniqueItems": True
        }
        schema = {
            "type": "object",
            "properties": {
                "fillna_value": {
                    "type": ["string", "null"]
                },
                "fillna_policy": {
                    "type": "string",
                    "enum": ["mean", "min", "special", "sample"]
                },
                "datetime_format": {
                    "type": ["string", "null"]
                },
                "date_only": {
                    "type": "boolean",
                },
                "time_only": {
                    "type": "boolean",
                },
                "unit": {
                    "type": "string",
                    "enum": ["year", "month", "day", "hour", "minute", "second", "microsecond"]
                },
                "smallest": {
                    "type": "integer",
                    "minimum": 1
                },
                "as_numerical": {
                    "type": "boolean"
                },
                "separate": {
                    "oneOf": [
                        {"type": "null"},
                        unique_directives
                    ]
                },
                "main_separate": {
                    "oneOf": [
                        {"type": "null"},
                        unique_directives
                    ]
                },
                "validate": {
                    "type": "boolean"
                },
                "dir_norm_args": {
                    "type": "object",
                    "propertyNames": {
                        "enum": all_directives
                    },
                    "additionalProperties": {
                        "type": "object"
                    }
                },
                "enforce_min": {
                    "type": "boolean"
                },
                "enforce_max": {
                    "type": "boolean"
                },
                "raw_dtype": {
                    "enum": ["datetime"]
                }
            },
            "allOf": chunk_predicates,
        }
        jsonschema.validate(instance=args, schema=schema)

        fillna_value = args.get("fillna_value")
        if fillna_value is not None:
            pd.to_datetime(fillna_value, format=args.get("datetime_format"))
        datetime_format = args.get("datetime_format")
        if datetime_format is not None:
            datetime.strptime(datetime.now().strftime(datetime_format), datetime_format)
        date_only = args.get("date_only", False)
        time_only = args.get("time_only", False)
        if date_only and time_only:
            raise ValueError("Date-only and time-only cannot be true simultaneously.")
        unit = args.get("unit", "microsecond")
        if date_only and unit in {"hour", "minute", "second", "microsecond"}:
            raise ValueError(f"Unit {unit} is not valid for date-only datetime.")
        if time_only and unit in {"year", "month", "day"}:
            raise ValueError(f"Unit {unit} is not valid for time-only datetime.")
        as_numerical = args.get("as_numerical", True)
        separate = make_list(args.get("separate"))
        if not as_numerical:
            main_separate = make_list(args.get("main_separate", separate))
            if not {*main_separate} <= {*separate}:
                raise ValueError("The main separate list is not a subset of the separate list.")
            if date_only:
                for directive in separate:
                    if directive in cls._invalid_date_only:
                        raise ValueError(f"Directive {directive} is invalid for date only.")
            elif unit in {"hour", "minute", "second", "microsecond"}:
                hour_directives = sum(x in main_separate for x in ["%H", "%c", "%X"])
                h12_directive = int("%I" in main_separate)
                ap_directive = int("%p" in main_separate)
                if hour_directives + min(h12_directive, ap_directive) == 0:
                    raise ValueError(f"Hour information cannot be extracted from the main directives {main_separate}. "
                                     f"Please make sure at least one from %H, %c, %X or (%I + %p) is present.")
                elif hour_directives + h12_directive + ap_directive > 1:
                    raise ValueError("Two directives are expressing hour information. Please make sure main directives"
                                     " have no conflict.")
                if unit != "hour":
                    minute_directives = sum(x in main_separate for x in ["%M", "%c", "%X"])
                    if minute_directives == 0:
                        raise ValueError(f"Minute information cannot be extracted from the main directives "
                                         f"{main_separate}. Please make sure at least one from %M, %c, %X is present.")
                    elif minute_directives > 1:
                        raise ValueError("Two directives are expressing minute information. Please make sure main "
                                         "directives have no conflict.")
                    if unit != "minute":
                        second_directives = sum(x in main_separate for x in ["%S", "%c", "%X"])
                        if second_directives == 0:
                            raise ValueError(f"Second information cannot be extracted from the main directives "
                                             f"{main_separate}. Please make sure at least one from %M, %c, %X is "
                                             f"present.")
                        elif second_directives > 1:
                            raise ValueError("Two directives are expressing second information. Please make sure main "
                                             "directives have no conflict.")
                        if unit != "second" and "%f" not in main_separate:
                            raise ValueError(f"Microsecond information cannot be extracted from the main directives "
                                             f"{main_separate}. Please make sure that %f is present.")
            if time_only:
                for directive in separate:
                    if directive in cls._invalid_time_only:
                        raise ValueError(f"Directive {directive} is invalid for time only.")
            else:
                year_directives = sum(x in main_separate for x in [
                    "%Y", "%c", "%x", "%G", "%y"
                ])
                if year_directives == 0:
                    raise ValueError(f"Year information cannot be extracted from the main directives {main_separate}. "
                                     f"Please make sure at least one from %Y, %c, %x, %G, %y is present.")
                elif year_directives > 1:
                    raise ValueError("Two directives are expressing year information. Please make sure main directives"
                                     " have no conflict.")
                if unit != "year":
                    month_directives = sum(x in main_separate for x in [
                        "%b", "%B", "%m", "%v", "%x", "%j"
                    ])
                    if month_directives == 0:
                        raise ValueError(f"Month information cannot be extracted from the main directives "
                                         f"{main_separate}. Please make sure at least one from %b, %B, %m, %v, %x, %j.")
                    elif month_directives > 1:
                        raise ValueError("Two directives are expressing month information. Please make sure main "
                                         "directives have no conflict.")
                    if unit != "month":
                        day_directives = sum(x in main_separate for x in ["%d", "%j", "%c", "%x"])
                        weekday_directives = sum(x in main_separate for x in ["%a", "%A", "%w", "%u"])
                        week_directives = sum(x in main_separate for x in ["%U", "%W", "%V"])
                        if day_directives == 0 and (week_directives == 0 or weekday_directives == 0):
                            raise ValueError(f"Day information cannot be extracted from the main directives "
                                             f"{main_separate}. Please make sure you either provide the day in month,"
                                             f"day in year, or week number with day in week.")
                        if day_directives + min(weekday_directives, week_directives) > 1:
                            raise ValueError("Two directives are expressing day information. Please make sure main "
                                             "directives have no conflict.")
                        if week_directives > 1:
                            raise ValueError("Two directives are expressing week information. Please make sure main "
                                             "directives have no conflict.")
                        if weekday_directives > 1:
                            raise ValueError("Two directives are expressing day in week information. Please make sure"
                                             "main directives have no conflict.")

            zone_directives = sum(x in main_separate for x in ["%z", "%Z"])
            if zone_directives > 1:
                raise ValueError("Two directives are expressing time-zone information. Please make sure main "
                                 "directives have no conflict.")

        dir_norm_args = args.get("dir_norm_args", {})
        if not {*dir_norm_args} <= {*separate}:
            diff = {*dir_norm_args} - {*separate}
            raise ValueError("Directive normalizer arguments should correspond to the separate directives list. "
                             f"Got directives {diff} not in the list.")
        for dir_name, dir_args in dir_norm_args.items():
            if cls._directive_types[dir_name] == "binary":
                BinaryNormalizer.validate_kwargs(dir_args)
            elif cls._directive_types[dir_name] == "multiclass":
                MulticlassNormalizer.validate_kwargs(dir_args)
            else:
                NumericalNormalizer.validate_kwargs(dir_args)

        main_args_numerical = filter_dict(args, "main_")
        if "separate" in main_args_numerical:
            del main_args_numerical["separate"]
        if not as_numerical and len(main_args_numerical) > 0:
            raise ValueError("The datetime as one numerical value is not used as a standardized component. "
                             f"Arguments {[*main_args_numerical]} with prefix \"main_\" are redundant.")
        NumericalNormalizer.validate_kwargs(main_args_numerical)
