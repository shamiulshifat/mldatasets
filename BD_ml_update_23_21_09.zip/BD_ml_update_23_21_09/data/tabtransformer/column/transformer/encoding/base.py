"""Common structure for transformers for encoding data."""

import enum
import os
from abc import ABC
from copy import deepcopy
from typing import Any, Collection, Dict, Optional, Type, Union

import jsonschema
import numpy as np
import pandas as pd
import pkg_resources
from sklearn.neighbors import NearestNeighbors

from ..base import ColumnTransformer, FillNaPolicy, MainValueColumn
from ...normalizer import StdColumnNormalizer
from ....dtypes import ColumnName, RawDType, SType
from ....utils import make_dict, register


class PredefinedEncoder(enum.Enum):
    """Types of common encoders that are pre-defined."""

    country = enum.auto()
    """Countries in the world."""


@register(ColumnTransformer.registry, RawDType.encoding)
class EncodingTransformer(ColumnTransformer):
    """
    Column transformer to numerical matrix for data that are to be matched with some encodings provided in a separate
    DataFrame. Such columns typically include those well-known entities like countries, languages, (big) companies, etc.
    """
    sub_registry: Dict[PredefinedEncoder, Type["EncodingTransformer"]] = {}

    def __init__(self,
                 name: ColumnName = "",
                 *,
                 info_data: str = "",
                 index_column: str = "ID",
                 eps: float = 1e-6,
                 column_kwargs: Optional[Dict[ColumnName, Dict[str, Any]]] = None,
                 fillna_value: Optional = None,
                 fillna_policy: Union[FillNaPolicy, str] = FillNaPolicy.sample,
                 na_equivalences: Optional[Collection] = None,
                 **kwargs):
        """
        Parameters
        ----------
        info_data : str
            The information data CSV file.
        index_column : str
            The column to match with (join on).
        eps : float
            The value considered to be ~0 for distances.
        column_kwargs : dict[str, dict]]
            Arguments for each column in the information data.
        **kwargs
            Arguments to sklearn
            [`NearstNeighbors`](https://scikit-learn.org/stable/modules/generated/sklearn.neighbors.NearestNeighbors.html).
        Other parameters are inherited from parent `ColumnTransformer`.
      """
        super().__init__(name, fillna_value=fillna_value, fillna_policy=fillna_policy, na_equivalences=na_equivalences)
        self._info_data = pd.read_csv(info_data)
        self._index_column = index_column
        self._column_kwargs = make_dict(column_kwargs)
        self._info_columns: Dict[ColumnName, ColumnTransformer] = {}

        self._nn = NearestNeighbors(**kwargs)
        self._eps = eps

    def _fit_cleaned(self, data: pd.Series):
        self._standardized_dtypes[MainValueColumn] = SType.non_std
        self.normalizers[MainValueColumn] = StdColumnNormalizer.make(
            SType.non_std,
            name=MainValueColumn, parent=self.name
        )
        info_data = self._info_data.drop(columns=[self._index_column])
        for c in info_data.columns:
            column_args = ColumnTransformer.learn_args(info_data.loc[:, c], **self._column_kwargs.get(c, {}))
            transformer = ColumnTransformer.make(
                name=c, **column_args
            )
            transformer.fit(info_data.loc[:, c])
            self._info_columns[c] = transformer
            self._standardized_dtypes.update({
                f"{c}||{sc}": t
                for sc, t in transformer._standardized_dtypes.items()
            })
            for sc, normalizer in transformer.normalizers.items():
                normalizer.parent = self.name
                normalizer.name = f"{c}||{sc}"
                self.normalizers[normalizer.name] = normalizer

    def fit(self, data: pd.Series):
        super().fit(data)
        normalized = self.transform(data)
        self._nn.fit(normalized.values)

    def _standardize(self, data: pd.Series, retain_non_std: bool = False) -> pd.DataFrame:
        name = data.name
        raw_data = data.copy()
        data = pd.concat({"data": data.to_frame()}, axis=1)
        info = pd.concat({"info": self._info_data}, axis=1)
        merged = data.merge(info, left_on=[("data", name)], right_on=[("info", self._index_column)], how="left")
        if not merged["data"].iloc[:, 0].equals(raw_data):
            raise RuntimeError("The merged result does not match with input rows.")
        merged = merged["info"].drop(columns=[self._index_column])
        per_info_column = []
        for c, t in self._info_columns.items():
            cleaned = t.clean(merged.loc[:, c])
            standardized = t.standardize(cleaned, retain_non_std)
            standardized = standardized.rename(columns={
                sc: f"{c}||{sc}"
                for sc in standardized.columns
            })
            per_info_column.append(standardized)
        if retain_non_std:
            per_info_column.append(pd.DataFrame({
                MainValueColumn: raw_data
            }))
        return pd.concat(per_info_column, axis=1)

    def _inverse_standardize(self, standardized: pd.DataFrame) -> pd.Series:
        normalized = self.normalize(standardized)
        distances, indices = self._nn.kneighbors(normalized.values)
        result = []
        for dist, idx in zip(distances, indices):
            close_idx = np.where(dist < self._eps)[0]
            if len(close_idx) > 0:
                selected_idx = np.random.choice(idx[close_idx])
            else:
                probs = 1. / dist
                probs /= probs.sum()
                selected_idx = np.random.choice(idx, p=probs)
            value = self._info_data.iloc[selected_idx][self._index_column]
            result.append(value)
        return pd.Series(result, name=self.name)

    @property
    def raw_dtype(self) -> RawDType:
        return RawDType.encoding

    @classmethod
    @register(ColumnTransformer.args_learner, RawDType.encoding)
    def learn_args(cls,
                   data: pd.Series,
                   *,
                   provided_args: Optional[Dict[str, Any]] = None,
                   **kwargs) -> Dict[str, Any]:
        info_data = pd.read_csv(provided_args["info_data"])
        index_column = provided_args["index_column"]
        info_data = info_data.drop(columns=[index_column])
        info_column_kwargs = make_dict(provided_args.get("column_kwargs"))
        for c in info_data.columns:
            info_column_kwargs[c] = ColumnTransformer.learn_args(
                data=data,
                provided_args=make_dict(info_column_kwargs.get(c)),
                **kwargs
            )

        args = deepcopy(provided_args)
        args["column_kwargs"] = info_column_kwargs
        return args

    @classmethod
    def validate_kwargs(cls, args: Dict[str, Any]):
        info_data = args["info_data"]
        try:
            predefined = PredefinedEncoder[info_data]
            cls.sub_registry[predefined].validate_kwargs(args)
        except KeyError:
            cls._validate_kwargs(args)

    @classmethod
    def _validate_kwargs(cls, args: Dict[str, Any]):
        info_data = pd.read_csv(args["info_data"])
        index_column = args["index_column"]
        info_data = info_data.drop(columns=[index_column])
        columns = [*info_data.columns]
        for col in columns:
            if "||" in col:
                raise ValueError("String \"||\" should not be contained in a column name")
        schema = {
            "type": "object",
            "properties": {
                "info_data": {
                    "type": "string"
                },
                "index_column": {
                    "type": "string"
                },
                "eps": {
                    "type": "number",
                    "minimum": 0
                },
                "column_kwargs": {
                    "type": "object",
                    "properties": {
                        column: {"type": "object"}
                        for column in columns
                    },
                    "additionalProperties": False
                },
                "fillna_value": {},
                "fillna_policy": {
                    "type": "string",
                    "enum": ["mean", "min", "special", "sample"]
                },
                "raw_dtype": {
                    "enum": ["encoding"]
                }
            },
            "additionalProperties": False
        }
        jsonschema.validate(instance=args, schema=schema)

        info_column_kwargs = make_dict(args.get("column_kwargs"))
        for col, kwargs in info_column_kwargs.items():
            ColumnTransformer.validate_kwargs(kwargs)

    @classmethod
    @register(ColumnTransformer._args_learner, RawDType.encoding)
    def _learn_args(cls, data: pd.Series, *, default_args: Dict[str, Any], provided_args: Dict[str, Any],
                    default_norm_args_by_stype: Dict[SType, Dict[str, Any]], **kwargs) -> Dict[str, Any]:
        return provided_args

    @classmethod
    def make(cls,
             raw_dtype: Union[RawDType, str],
             name: ColumnName = "",
             info_data: Union[PredefinedEncoder, str] = "",
             **kwargs) -> "EncodingTransformer":
        predefined = None
        if isinstance(info_data, str):
            try:
                predefined = PredefinedEncoder[info_data]
            except KeyError:
                pass
        else:
            predefined = info_data
        if predefined is None:
            return cls(name, info_data=info_data, **kwargs)
        return cls.sub_registry[predefined](**kwargs)


class PredefinedEncodingTransformer(EncodingTransformer, ABC):
    """Common encoding transformers that are pre-defined, corresponding to each type in `PredefinedEncoder`."""
    _index_column = None
    predefined_type: PredefinedEncoder = None
    """The pre-defined type of this transformer."""

    def __init__(self,
                 name: ColumnName = "",
                 **kwargs):
        super().__init__(
            name,
            info_data=self.filename(),
            index_column=self._index_column,
            **kwargs
        )

    @classmethod
    def filename(cls) -> str:
        """The resource file name."""
        try:
            return os.path.join(os.path.dirname(__file__), f"{cls.predefined_type.name}.csv")
        except Exception:
            return pkg_resources.resource_filename(
                "tabtransformer",
                os.path.join("column", "transformer", "encoding", f"{cls.predefined_type.name}.csv")
            )

    @classmethod
    def validate_kwargs(cls, args: Dict[str, Any]):
        args = deepcopy(args)
        args["info_data"] = os.path.join(cls.filename())
        args["index_column"] = cls._index_column
        cls._validate_kwargs(args)
