"""Pre-defined encoding data for countries."""

from typing import List, Optional

import pandas as pd
import pycountry

from .base import EncodingTransformer, PredefinedEncoder, PredefinedEncodingTransformer
from ....dtypes import ColumnName
from ....utils import register


@register(EncodingTransformer.sub_registry, PredefinedEncoder.country)
class CountryTransformer(PredefinedEncodingTransformer):
    """
    Encoding of countries.
    We use data from two Kaggle datasets:
    [countries of the world 2023](https://www.kaggle.com/datasets/nelgiriyewithana/countries-of-the-world-2023)
    and [countries of the world](https://www.kaggle.com/datasets/fernandol/countries-of-the-world).
    """
    _index_column = "Country"
    predefined_type = PredefinedEncoder.country

    def __init__(self,
                 name: ColumnName = "",
                 *,
                 condense: bool = True,
                 **kwargs):
        """
        parameters
        ----------
        condense : bool
            Whether to use condensed information (selected columns) or the full dataset.
        Other parameters are inherited from parent `PredefinedEncodingTransformer`.
        """
        super().__init__(name, **kwargs)
        if condense:
            self._info_data = self._info_data[[
                "Country", "Population Density (P/Km2)", "Land Area (Km2)", "Birth Rate",
                "GDP", "Life expectancy", "Population 2023", "Unemployment rate", "Urban_population",
                "Region", "Net migration"
            ]]

    def _fit_cleaned(self, data: pd.Series):
        data = data.apply(self._get_country)
        self._info_data.loc[len(self._info_data), "Country"] = "Others"
        super()._fit_cleaned(data)

    @classmethod
    def _get_country(cls, x: str) -> str:
        full_get = cls._get_by_kw_country(x)
        if full_get is not None:
            return full_get

        full_search = cls._search_country(x)
        counts = {
            s: 3 for s in full_search
        }
        words = [x]
        for splitter in [" ", ",", ":", "(", ")", "|", "-", "."]:
            new_words = []
            for word in words:
                new_words.extend(word.split(splitter))
            words = new_words
        for word in words:
            word = word.strip().lower()
            if word == "the":
                continue
            word_search = cls._search_country(word)
            for ws in word_search:
                if ws not in counts:
                    counts[ws] = 0
                counts[ws] += 1

        best_guess = ["Others"]
        best_count = 0
        for guess, cnt in counts.items():
            if cnt > best_count:
                best_count = cnt
                best_guess = guess
            elif cnt == best_count:
                best_guess.append(guess)
        return best_guess[0]

    @staticmethod
    def _search_country(x: str) -> List[str]:
        try:
            return [y.alpha_3 for y in pycountry.countries.search_fuzzy(x)]
        except:
            return []

    @staticmethod
    def _get_by_kw_country(x: str) -> Optional[str]:
        keys = ["name", "common_name", "alpha_2", "alpha_3", "numeric"]
        for key in keys:
            result = pycountry.countries.get(**{key: x})
            if result is not None:
                return result.alpha_3


