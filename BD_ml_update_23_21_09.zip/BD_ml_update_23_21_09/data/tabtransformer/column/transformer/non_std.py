"""Transformer for handling non-standard typed data."""

from copy import deepcopy
from typing import Any, Dict

import jsonschema
import pandas as pd

from .base import ColumnTransformer, IsNaColumn, MainValueColumn
from ..normalizer import StdColumnNormalizer
from ...dtypes import RawDType, SType
from ...utils import register


@register(ColumnTransformer.registry, RawDType.non_std)
class NonStdTransformer(ColumnTransformer):
    """
    Column transformer to numerical matrix for non-standard raw data type.
    Such columns cannot be converted to numerical format easily ultimately.
    For example, IDs, names, and emails.
    """
    def _fit_cleaned(self, data: pd.Series):
        self._standardized_dtypes[MainValueColumn] = SType.non_std
        self.normalizers[MainValueColumn] = StdColumnNormalizer.make(
            SType.non_std,
            name=MainValueColumn, parent=self.name
        )

    def _standardize(self, data: pd.Series, retain_non_std: bool = False) -> pd.DataFrame:
        if not retain_non_std:
            return pd.DataFrame(index=data.index)
        return pd.DataFrame({
            MainValueColumn: data
        })

    def inverse_standardize(self, standardized: pd.DataFrame, assign_non_std: bool = True) -> pd.DataFrame:
        self._check_fitted("inverse standardization")
        if assign_non_std:
            standardized = standardized.copy()
            if MainValueColumn not in standardized.columns:
                standardized.loc[:, MainValueColumn] = range(len(standardized))
            if IsNaColumn in self.standardized_columns and IsNaColumn not in standardized.columns:
                standardized.loc[:, IsNaColumn] = 0
        if MainValueColumn not in standardized.columns:
            return pd.DataFrame(index=standardized.index)
        return standardized

    def normalize(self, data: pd.DataFrame) -> pd.DataFrame:
        result = {}
        columns = {*data.columns}
        for c in self._standardized_columns:
            if c in columns or self._standardized_dtypes[c] != SType.non_std:
                result[c] = self.normalizers[c].normalize(data.loc[:, c])
        return pd.concat(result, axis=1)

    @property
    def raw_dtype(self) -> RawDType:
        return RawDType.non_std

    @classmethod
    @register(ColumnTransformer.args_learner, RawDType.non_std)
    def learn_args(cls,
                   data: pd.Series,
                   **kwargs) -> Dict[str, Any]:
        return super().learn_args(
            data,
            raw_dtype=RawDType.non_std,
            **kwargs
        )

    @classmethod
    @register(ColumnTransformer._args_learner, RawDType.non_std)
    def _learn_args(cls,
                    data: pd.Series,
                    *,
                    default_args: Dict[str, Any],
                    provided_args: Dict[str, Any],
                    default_norm_args_by_stype: Dict[SType, Dict[str, Any]],
                    **kwargs) -> Dict[str, Any]:
        return deepcopy(default_args)

    @classmethod
    def validate_kwargs(cls, args: Dict[str, Any]):
        schema = {
            "type": "object",
            "properties": {
                "fillna_value": {},
                "fillna_policy": {
                    "type": "string",
                    "enum": ["mean", "min", "special", "sample"]
                },
                "raw_dtype": {
                    "enum": ["non_std"]
                }
            }
        }
        jsonschema.validate(instance=args, schema=schema)
