"""Transformer for handling mixed-typed data."""

from copy import deepcopy
from typing import Any, Dict, Optional, Union

import jsonschema
import pandas as pd

from .base import ColumnTransformer
from ...dtypes import ColumnName, RawDType, SType
from ...utils import find_special_category, make_dict, make_enum, register


@register(ColumnTransformer.registry, RawDType.mixed)
class MixedTransformer(ColumnTransformer):
    """
    Column transformer to numerical matrix for mixed raw data type.
    Here we specifically refer to the mixture of categorical with other raw types except for non-standard.
    """

    def __init__(self,
                 name: ColumnName = "",
                 *,
                 base_type: Union[RawDType, str] = RawDType.numerical,
                 value_mapper: Optional[Dict] = None,
                 **kwargs):
        """
        Parameters
        ----------
        base_type : RawDType, optional
            The data type mixed with categorical.
            By default the type is numerical.
        value_mapper : dict, optional
            Mapping categorical data to values of base type.
            If not provided, the base value of the type is used.
        Other parameters are inherited from parent `ColumnTransformer`.
        """
        base_type: RawDType = make_enum(base_type, RawDType)
        if base_type == RawDType.non_std or base_type == RawDType.categorical:
            raise ValueError(f"Base type {base_type.name} is not allowed as a mixed base type.")
        global_kwargs = {
            k: v for k, v in kwargs.items()
            if k.startswith("fillna")
        }
        kwargs = {
            k: v for k, v in kwargs.items()
            if not k.startswith("fillna")
        }
        super().__init__(
            name,
            **global_kwargs
        )
        self.base_type = base_type
        self.value_mapper = make_dict(value_mapper)
        self.categorical_transformer: ColumnTransformer = self.registry[RawDType.categorical]()
        self.base_transformer: ColumnTransformer = self.registry[base_type](**kwargs)

        self._all_categories = None
        self._special_category = None

    def _standardize(self, data: pd.Series, retain_non_std: bool = False) -> pd.DataFrame:
        categorical = self._extract_categorical(data)
        cat_standardized = self.categorical_transformer._standardize(categorical)
        cat_standardized = cat_standardized.rename(columns={
            c: f"cat-{c}" for c in cat_standardized.columns
        })

        base = self._extract_base(data)
        base_standardized = self.base_transformer._standardize(base)
        base_standardized = base_standardized.rename(columns={
            c: f"base-{c}" for c in base_standardized.columns
        })
        result = pd.concat([cat_standardized, base_standardized], axis=1)
        return result

    def _inverse_standardize(self, standardized: pd.DataFrame) -> pd.Series:
        cat_columns = [
            c for c in standardized.columns if c.startswith("cat-")
        ]
        cat_standardized = standardized[cat_columns].rename(columns={
            c: c[4:] for c in cat_columns
        })
        cat_cleaned = self.categorical_transformer \
            ._inverse_standardize(cat_standardized) \
            .astype(RawDType.categorical.default_dtype)

        base_columns = [
            c for c in standardized.columns if c.startswith("base-")
        ]
        base_standardized = standardized[base_columns].rename(columns={
            c: c[5:] for c in base_columns
        })
        base_cleaned = self.base_transformer \
            ._inverse_standardize(base_standardized) \
            .astype(self.base_type.default_dtype)

        combined = pd.DataFrame({
            "cat": cat_cleaned,
            "base": base_cleaned
        })
        result = combined.apply(
            lambda row: row["cat"] if row["cat"] != self._special_category else row["base"],
            axis=1
        )
        return result

    def _fit_cleaned(self, data: pd.Series):
        self._all_categories = {
            x for x in data if
            x in self.value_mapper or not isinstance(x, self.base_type.base_type)
        }
        self._special_category = find_special_category("<base>", self._all_categories)
        categorical = self._extract_categorical(data)
        self.categorical_transformer.fit(categorical)

        for c in self._all_categories:
            if c not in self.value_mapper:
                self.value_mapper[c] = self.base_type.base_value
        data = self._extract_base(data)
        self.base_transformer.fit(data)

        for c, t in self.categorical_transformer.standardized_dtypes.items():
            self._standardized_dtypes[f"cat-{c}"] = t
            self.normalizers[f"cat-{c}"] = self.categorical_transformer.normalizers[c]
        for c, t in self.base_transformer.standardized_dtypes.items():
            self._standardized_dtypes[f"base-{c}"] = t
            self.normalizers[f"base-{c}"] = self.base_transformer.normalizers[c]

    def _extract_base(self, data: pd.Series) -> pd.Series:
        data = data.replace(self.value_mapper).astype(self.base_type.default_dtype)
        return data

    def _extract_categorical(self, data: pd.Series) -> pd.Series:
        categorical = data.apply(
            lambda x: x if x in self._all_categories else self._special_category
        ).astype(RawDType.categorical.default_dtype)
        return categorical

    @property
    def raw_dtype(self) -> RawDType:
        return RawDType.mixed

    @classmethod
    @register(ColumnTransformer.args_learner, RawDType.mixed)
    def learn_args(cls,
                   data: pd.Series,
                   **kwargs) -> Dict[str, Any]:
        """
        We will do the following in sequence:

        1. Infer the base type other than categorical.
        2. Get all values that are not categorical, and then learn the arguments on these values for the base type.
           Default values for mixed raw data type will override default values for the base type if provided.
           However, they are all overriden by learned arguments, and in turn overriden by provided arguments.

        Parameters
        ----------
        default_base_type_args : dict, optional
            The default arguments for base type.
        **kwargs
            Other arguments for this base type's learn_args function.
        Other parameters are inherited from parent
        [`ColumnTransformer.learn_args`](/tabtransformer/column/transformer#tabtransformer.column.transformer.ColumnTransformer.learn_args).
        """
        return super().learn_args(
            data,
            raw_dtype=RawDType.mixed,
            **kwargs
        )

    @classmethod
    @register(ColumnTransformer._args_learner, RawDType.mixed)
    def _learn_args(cls,
                    data: pd.Series,
                    *,
                    default_args: Dict[str, Any],
                    provided_args: Dict[str, Any],
                    default_norm_args_by_stype: Dict[SType, Dict[str, Any]],
                    default_type_args: Optional[Dict[str, Any]] = None,
                    **kwargs) -> Dict[str, Any]:
        base_type = RawDType.numerical
        if "base_type" in default_args:
            base_type = make_enum(base_type, RawDType)
        base_args = make_dict(default_type_args).get(base_type, {})
        base_values = []
        for d in data:
            try:
                value = base_type.cast(d)
                base_values.append(value)
            except Exception:
                pass

        base_args = cls._args_learner[base_type](
            cls=cls.registry[base_type],
            data=pd.Series(base_values),
            default_args=base_args,
            provided_args=provided_args,
            default_norm_args_by_stype=default_norm_args_by_stype,
            **kwargs
        )

        args = deepcopy(default_args)
        args.update(base_args)
        return args

    @classmethod
    def validate_kwargs(cls, args: Dict[str, Any]):
        schema = {
            "type": "object",
            "properties": {
                "base_type": {
                    "type": "string",
                    "enum": ["numerical", "datetime", "timedelta"],
                    "default": "numerical"
                },
                "raw_dtype": {
                    "enum": ["mixed"]
                }
            },
            "allOf": [
                {
                    "if": {
                        "properties": {
                            "base_type": {
                                "enum": ["numerical", ""]
                            }
                        }
                    },
                    "then": {
                        "properties": {
                            "value_mapper": {
                                "type": "object",
                                "additionalProperties": {
                                    "type": "number"
                                }
                            }
                        }
                    }
                },
                {
                    "if": {
                        "properties": {
                            "base_type": {
                                "enum": ["datetime", "timedelta"]
                            }
                        }
                    },
                    "then": {
                        "properties": {
                            "value_mapper": {
                                "type": "object",
                                "additionalProperties": {
                                    "type": "string"
                                }
                            }
                        },
                    }
                }
            ]
        }
        jsonschema.validate(instance=args, schema=schema)

        args = deepcopy(args)
        for c in ["base_type", "value_mapper", "raw_dtype"]:
            if c in args:
                del args[c]

        base_type = args.get("base_type", "numerical")
        cls.registry[RawDType[base_type]].validate_kwargs(args)
