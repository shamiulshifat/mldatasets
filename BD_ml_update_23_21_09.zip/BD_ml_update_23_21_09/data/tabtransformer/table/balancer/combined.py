"""Combined balancer that contains multiple balancing steps."""

from typing import Any, Dict, List, Optional, Tuple, Union

import pandas as pd

from .sampler import Sampler
from ...dtypes import ColumnName
from ...utils import log_time, make_dict, make_list


class TableBalancer:
    def __init__(self,
                 target_columns: Optional[List[ColumnName]] = None,
                 sampler_kwargs: Optional[Dict[Union[ColumnName, Tuple[ColumnName, str]], Any]] = None):
        self.target_columns = make_list(target_columns)

        sampler_kwargs = make_dict(sampler_kwargs)
        sub_sampler_kwargs = {}
        for col, kwargs in sampler_kwargs.items():
            if isinstance(col, Tuple):
                col, st_col = col
            else:
                st_col = "__base__"
            if col not in sub_sampler_kwargs:
                sub_sampler_kwargs[col] = {}
            sub_sampler_kwargs[col][st_col] = kwargs

        self.samplers = {}
        for col in self.target_columns:
            for st_col, kwargs in sub_sampler_kwargs.get(col, {}).items():
                if st_col == "__base__":
                    key = col
                else:
                    key = col, st_col
                self.samplers[key] = Sampler(**make_dict(sampler_kwargs.get(col)))

    @log_time("Sampling data to balance imbalance targets", "Finished sampling data to resolve imbalance targets")
    def sample(self, data: pd.DataFrame, target: pd.DataFrame) -> pd.DataFrame:
        """
        Sample the given data to reduce imbalance problem.

        Parameters
        ----------
        data : pd.DataFrame
            The original numerical-only data. Ideally after normalization.
        target : pd.DataFrame
            The target columns. Ideally after discretization.

        Returns
        -------
        pd.DataFrame
            The sampled data that imbalance issue is mitigated.
        """
        for col, sampler in self.samplers.items():
            if isinstance(col, Tuple):
                col, st_col = col
                targ_col = target[col][st_col]
            else:
                targ_col = target[col]
            data, _ = sampler.sample(data, targ_col)
        return data
