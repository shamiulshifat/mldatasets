"""Combining column transformations."""

import json
import logging
from typing import Any, Collection, Dict, List, Optional, Tuple, Union

import pandas as pd

from ..column import ColumnTransformer, MainValueColumn
from ..column.transformer.encoding import PredefinedEncoder
from ..dtypes import ColumnName, RawDType, SType, learn_forced_dtypes
from ..utils import iterate_over_list, log, log_time, make_dict, make_enum, make_json_compatible, make_list


class TableNormalizer:
    """
    Normalizer of table after unnecessary data dropped.
    This class mainly combines the result of independent columns column-by-column from
    [`ColumnTransformer`](/tabtransformer#tabtransformer.ColumnTransformer)s.
    """

    def __init__(self, *,
                 target_columns: Optional[Union[ColumnName, List[ColumnName]]] = None,
                 column_kwargs: Optional[Dict[ColumnName, Dict[str, Any]]] = None, ):
        """
        Initialize a new instance of `TableNormalizer`, for a new dataset.

        Parameters
        ----------
        target_columns : list[str] or str, optional
            Columns that are the target to be predicted. In the output, if they are combined to the other columns,
            they are usually grouped and placed at the right-most columns unless otherwise stated.
        column_kwargs : dict, optional
            Arguments to each column.
            We will not do automatic detection, so if your dataset is not empty, do make sure that all columns are
            present in this dict.
            If you want to reduce the work for constructing input, please go to class methods `learn` or `make`.
        """
        if isinstance(target_columns, str):
            self.target_columns = [target_columns]
        else:
            self.target_columns = make_list(target_columns)

        self.columns, self.column_raw_dtypes, self.column_transformers = self._init_column_transformers(
            self.target_columns, column_kwargs)

    @staticmethod
    def _init_column_transformers(target_columns: List[ColumnName],
                                  column_kwargs: Optional[Dict[str, Dict[str, Any]]] = None) -> \
            (List[ColumnName], Dict[ColumnName, RawDType], Dict[ColumnName, ColumnTransformer]):

        non_std = []
        normal = []
        target = []
        column_raw_dtypes = {}
        column_transformers = {}
        column_kwargs = make_dict(column_kwargs)
        for c, kwargs in column_kwargs.items():
            dtype: RawDType = make_enum(kwargs["raw_dtype"], RawDType)
            column_raw_dtypes[c] = dtype
            if dtype == RawDType.non_std:
                non_std.append(c)
            elif c in target_columns:
                target.append(c)
            else:
                normal.append(c)
            kwargs = {
                k: v for k, v in kwargs.items()
                if k not in {"name", "raw_dtype"}
            }
            column_transformers[c] = ColumnTransformer.make(
                dtype, c, **kwargs
            )
        all_columns = non_std + normal + target
        return all_columns, column_raw_dtypes, column_transformers

    @log_time("Fitting transformer and normalizers", "Finished fitting transformer and normalizers")
    def fit(self, data: pd.DataFrame):
        """
        Fit the column transformers.

        Parameters
        ----------
        data : pd.DataFrame
            The raw data to fit.
        """
        data = data[self.columns]
        for c in self.columns:
            self.column_transformers[c].fit(data.loc[:, c])

    @log_time("Cleaning data to remove N/A values", "Finished data cleaning")
    def clean(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        Make the entire table N/A-value-free.

        Parameters
        ----------
        data : pd.DataFrame
            The data to clean, which should be the result after drop step.

        Returns
        -------
        pd.DataFrame
            The DataFrame after cleaning.
        """
        result = {}
        for c in self.columns:
            result[c] = self.column_transformers[c].clean(data.loc[:, c])
        return pd.concat(result, axis=1)

    @log_time("Inversely cleaning data by recovering N/A values", "Recovered N/A values")
    def inverse_clean(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        Recover N/A values from cleaned data.

        Parameters
        ----------
        data : pd.DataFrame
            The data after cleaning. This should be a 2-level-column DataFrame.
            The first level correspond to the column names in the dataset.

        Returns
        -------
        pd.DataFrame
            DataFrame where N/A values are recovered.
        """
        result = {}
        columns = {a for a, b in data.columns}
        for c in self.columns:
            if c not in columns:
                std_data = pd.DataFrame(index=data.index)
            else:
                std_data = data[c]
            result[c] = self.column_transformers[c].inverse_clean(std_data)
        return pd.DataFrame(result)

    @log_time("Converting data to standard categorical-or-numerical types",
              "Finished converting data to standard categorical-or-numerical types")
    def standardize(self,
                    data: pd.DataFrame,
                    return_non_std: bool = False,
                    return_target: bool = True,
                    combine_target: bool = False
                    ) -> Union[pd.DataFrame, Tuple[pd.DataFrame, pd.DataFrame]]:
        """
        Standardize the input data to categorical or numerical without N/A.

        Parameters
        ----------
        data : pd.DataFrame
            The data to standardize. It should be cleaned.
        return_non_std : bool, optional
            Whether to return non-standard columns.
            If so, the standardized result may contain some non-categorical and non-numerical data for them.
            Default is False.
        return_target : bool, optional
            Whether to return target columns. Default is True.
        combine_target : bool, optional
            Whether to combine the target to other columns or give as a separate DataFrame. Default is False.

        Returns
        -------
        pd.DataFrame
            The standardized DataFrame. This DataFrame will have columns in 2 levels.
        """
        result = {}
        target_result = {}
        for c in self.columns:
            standardized = self.column_transformers[c].standardize(
                data[c], retain_non_std=return_non_std)
            if c in self.target_columns:
                target_result[c] = standardized
            else:
                result[c] = standardized

        return self._combine_result(result, target_result, return_target, combine_target)

    @log_time("Inversely convert from standard categorical-or-numerical types to original raw data types",
              "Recovered data in raw data types")
    def inverse_standardize(self,
                            *data: pd.DataFrame,
                            assign_non_std: bool = True) -> pd.DataFrame:
        """
        Recover standardized data (categorical or numerical without N/A) back to data with more possible types
        (e.g. datetime).

        Parameters
        ----------
        data : pd.DataFrame
            The standardized data. This should be a 2-level-column DataFrame.
            The first level correspond to the column names in the dataset.
        assign_non_std : bool, optional
            If the input data does not contain values for non-standard columns, whether to give a dummy
            value from sequential integers (1, 2, ...) (and whether this data is N/A can possibly be recovered).

        Returns
        -------
        pd.DataFrame
            Non-standard raw data that may contain complicated data types like datetime.
        """
        if len(data) <= 0 or len(data) > 2:
            raise ValueError("The number of dataframes to inversely standardize should either be 1 or 2.")
        data = pd.concat([*data], axis=1)

        recovered = {}
        data_columns = {a for a, b in data.columns}
        for c in self.columns:
            if c not in data_columns and (
                    self.column_raw_dtypes[c] == RawDType.non_std or
                    self.column_transformers[c].normalized_dim == 0):
                std_data = pd.DataFrame(index=data.index)
            else:
                std_data = data[c]
            this_recovered = self.column_transformers[c].inverse_standardize(
                std_data, assign_non_std
            )
            if this_recovered is not None:
                recovered[c] = this_recovered
        return pd.concat(recovered, axis=1)

    @log_time("Normalizing standard types to numerical NN input", "Normalized data to numerical NN input")
    def normalize(self,
                  *data: pd.DataFrame,
                  return_target: bool = True,
                  combine_target: bool = False,
                  normalize_target: bool = False,
                  ) -> Union[pd.DataFrame, Tuple[pd.DataFrame, pd.DataFrame]]:
        """
        Normalize the standardized data to numerical matrices.

        Parameters
        ----------
        data : pd.DataFrame
            The data to normalize.
        return_target : bool, optional
            Whether to return target columns. Default is True.
        combine_target : bool, optional
            Whether to combine the target to other columns or give as a separate DataFrame. Default is False.
        normalize_target : bool, optional
            Whether to normalize target or keep it as standardized (so categorical remains as categorical).
            Default is True.

        Returns
        -------
        pd.DataFrame
            The standardized DataFrame. This DataFrame will have columns in 2 levels.
        """
        if len(data) <= 0 or len(data) > 2:
            raise ValueError("The number of dataframes to normalize should either be 1 or 2.")
        data = pd.concat([*data], axis=1)

        result = {}
        target_result = {}
        data_columns = {a for a, b in data.columns}
        for c in self.columns:
            if c not in data_columns and self.column_transformers[c].normalized_dim == 0:
                continue
            elif c in self.target_columns:
                if return_target:
                    if normalize_target:
                        normalized = self.column_transformers[c].normalize(data[c])
                    else:
                        normalized = pd.concat({MainValueColumn: data[c]}, axis=1)
                    target_result[c] = normalized
            else:
                normalized = self.column_transformers[c].normalize(data[c])
                result[c] = normalized

        return self._combine_result(result, target_result, return_target, combine_target)

    @staticmethod
    def _combine_result(result: Dict[str, pd.DataFrame], target_result: Dict[str, pd.DataFrame],
                        return_target: bool, combine_target: bool):
        result = pd.concat(result, axis=1)
        if len(target_result) > 0:
            target_result = pd.concat(target_result, axis=1)
        else:
            target_result = pd.DataFrame(index=result.index)
        if return_target:
            if combine_target:
                return pd.concat([result, target_result], axis=1)
            else:
                return result, target_result
        return result

    @log_time("Inversely normalizing data to recover standard categorical-or-numerical types",
              "Recovered standard categorical-or-numerical data from purely numerical NN input data")
    def inverse_normalize(self,
                          *data: pd.DataFrame) -> pd.DataFrame:
        """
        Recover numerical matrix back to standardized data.

        Parameters
        ----------
        data : pd.DataFrame
            The normalized data. This should be a 3-level-column DataFrame.
            The first level corresponds to the column names in the dataset.
            The second level corresponds to the standardized column name.
            The third level corresponds to the normalized column in the standardized column.

        Returns
        -------
        pd.DataFrame
            Standardized data that contains categorical or numerical data.
        """
        if len(data) <= 0 or len(data) > 2:
            raise ValueError("The number of dataframes to inversely standardize should either be 1 or 2.")
        data = pd.concat([*data], axis=1)

        recovered = {}
        data_columns = {a for a, b, c in data.columns}
        for c in self.columns:
            if c not in data_columns and (
                    self.column_raw_dtypes[c] == RawDType.non_std or
                    self.column_transformers[c].normalized_dim == 0):
                std_data = pd.DataFrame(index=data.index)
            else:
                std_data = data[c]
            recovered[c] = self.column_transformers[c].inverse_normalize(std_data)

        return pd.concat(recovered, axis=1)

    @log_time("Discretizing standardized result", "Discretizing standardized result")
    def discretize(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        Discretized the standardized data to discrete values.

        Parameters
        ----------
        data : pd.DataFrame
            The data to discretize, which should be standardized.
            We allow missing columns here.

        Returns
        -------
        pd.DataFrame
            The discretized data.
        """
        data_columns = {a for a, b in data.columns}
        result = {}
        for c in data_columns:
            result[c] = self.column_transformers[c].discretize(data[c])
        return pd.concat(result, axis=1)

    @log_time("Inversely discretizing data", "Recovered data from discretized result")
    def inverse_discretize(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        Recover discretized data back to continuous standardized data.

        Parameters
        ----------
        data : pd.DataFrame
            The discretized standardized data.

        Returns
        -------
        pd.DataFrame
            Standardized data that contains categorical or numerical data recovered from standardized result.
        """
        data_columns = {a for a, b in data.columns}
        data_columns = [
            c for c in self.columns
            if c in data_columns
        ]
        result = {}
        for c in data_columns:
            result[c] = self.column_transformers[c].inverse_discretize(data[c])
        return pd.concat(result, axis=1)

    @property
    def normalized_span_info(self) -> (List[Tuple[int, SType]], List[Tuple[int, SType]]):
        """
        Normalized columns span information (list of width (int) and standardized column type).
        Non-standard columns are excluded.
        The order follows the output data columns of calling `normalize`.
        Non-target and target columns are separated in this order.
        This result will be helpful in activation function construction for some training tasks.
        """
        return self.normalized_span_info_of(self.columns)

    def normalized_span_info_of(self, columns: List[ColumnName]) -> (List[Tuple[int, SType]], List[Tuple[int, SType]]):
        """
        Normalized columns span information (list of width (int) and standardized column type).
        Non-standard columns are excluded.

        Parameters
        ----------
        columns : list
            The columns to get normalized span info for.

        Returns
        -------
        list
            List of span info of non-target columns in the selected columns.
        list
            List of span info of target columns in the selected columns.
        """
        out = []
        target_out = []
        for c in columns:
            span_info = self.column_transformers[c].normalized_span_info
            if c in self.target_columns:
                target_out.extend(span_info)
            else:
                out.extend(span_info)
        return out, target_out

    @classmethod
    @log_time("Learning column kwargs", "Finished learning column kwargs")
    def learn_column_kwargs(cls,
                            data: pd.DataFrame,
                            drop_columns: Optional[List[ColumnName]] = None,
                            categorical_columns: Optional[List[ColumnName]] = None,
                            numerical_columns: Optional[List[ColumnName]] = None,
                            datetime_columns: Optional[List[ColumnName]] = None,
                            timedelta_columns: Optional[List[ColumnName]] = None,
                            mixed_columns: Optional[List[ColumnName]] = None,
                            encoding_columns: Optional[Dict[ColumnName, Union[str, PredefinedEncoder]]] = None,
                            non_std_columns: Optional[List[ColumnName]] = None,
                            unique_threshold: float = .95,
                            force_min_category: int = 3,
                            try_casting: bool = True,
                            max_mixed_category: int = 5,
                            default_categorical_kwargs: Optional[Dict[str, Any]] = None,
                            default_numerical_kwargs: Optional[Dict[str, Any]] = None,
                            default_datetime_kwargs: Optional[Dict[str, Any]] = None,
                            default_timedelta_kwargs: Optional[Dict[str, Any]] = None,
                            default_mixed_kwargs: Optional[Dict[str, Any]] = None,
                            default_non_std_kwargs: Optional[Dict[str, Any]] = None,
                            column_kwargs: Optional[Dict[str, Any]] = None,
                            label_threshold: float = 50,
                            enforce_min: Optional[bool] = None,
                            enforce_max: Optional[bool] = None,
                            p_value_threshold: float = .05,
                            default_binary_norm_kwargs: Optional[Dict[str, Any]] = None,
                            default_multiclass_norm_kwargs: Optional[Dict[str, Any]] = None,
                            default_numerical_norm_kwargs: Optional[Dict[str, Any]] = None,
                            ) -> Dict[str, Any]:
        """
        Learn the column kwargs for column transformers.

        Parameters
        ----------
        data : pd.DataFrame
            The input data.
        drop_columns : list[str], optional
            Columns to be dropped. They do not need kwargs.
        categorical_columns : list[str], optional
            Names of categorical columns. This list need not be comprehensive.
            From this parameter to `non_std_columns`, the sets should be mutually exclusive.
            Columns not mentioned in this six arguments will learn the data type.
        numerical_columns : list[str], optional
            Names of numerical columns. This list need not be comprehensive.
        datetime_columns : list[str], optional
            Names of datetime columns. This list need not be comprehensive.
        timedelta_columns : list[str], optional
            Names of timedelta columns. This list need not be comprehensive.
        mixed_columns : list[str], optional
            Names of columns mixing either numerical, datetime, or timedelta (exactly one of them)
            with some special strings (each recognized as a category). This list need not be comprehensive.
        encoding_columns : dict[str, str], optional
            Columns that has some encodings describing its information and can be matched back by nearest neighbors.
            Such columns include countries, cities, companies, etc.
            This is a dict matching the column name to the information of encoding (which is a .csv file or a
            pre-defined encoding type).
        non_std_columns : list[str], optional
            Non-standard column names. Columns cannot be grouped into the above five types.
            For example, ID, name, email, etc.
            In the output, if they are retained, they are usually grouped and placed at the left-most columns unless
            otherwise stated.
            Such columns cannot be targets.
        unique_threshold : float, optional
            From this argument on, we learn the data types for the columns not mentioned above.
            After removing N/A values in the column, if the number of unique non-continuous values divided by the
            number of rows hit this threshold, this column will be treated as non-standard. Default is 0.95.
        force_min_category : int, optional
            If the number of unique non-N/A values does not exceed this number, we will treat this column as categorical
            regardless of the data type. Default is 3.
        try_casting : bool, optional
            Sometimes the data provided is in `object` data type, but all content can be converted to some other data
            type (e.g. numerical, datetime), so learning from dtype of input DataFrame might be insufficient.
            By setting this argument on, we will try to do casting for all values.
            If succeeded for all items in the column except for N/As, we will use this succeeded data type.
            It also allows detection of mixed types.
            Default is True.
        max_mixed_category : int, optional
            If some value casting is successful but some are not, this column may be of mixed type.
            This value specifies how many failures (in terms of unique value) are allowed for this column to be a mixed
            type. Default is 5.
        default_categorical_kwargs : dict, optional
            Default arguments for
            [categorical](/tabtransformer/column/transformer/categorical#tabtransformer.column.transformer.categorical.CategoricalTransformer)
            column transformer.
        default_numerical_kwargs : dict, optional
            Default arguments for
            [numerical](/tabtransformer/column/transformer/numerical#tabtransformer.column.transformer.numerical.NumericalTransformer)
            column transformer.
        default_datetime_kwargs : dict, optional
            Default arguments for
            [datetime](/tabtransformer/column/transformer/datetime#tabtransformer.column.transformer.datetime.DatetimeTransformer)
            column transformer.
        default_timedelta_kwargs : dict, optional
            Default arguments for
            [timedelta](/tabtransformer/column/transformer/timedelta#tabtransformer.column.transformer.timedelta.TimedeltaTransformer)
            column transformer.
        default_mixed_kwargs : dict, optional
            Default arguments for
            [mixed](/tabtransformer/column/transformer/mixed#tabtransformer.column.transformer.mixed.MixedTransformer)
            column transformer.
        default_non_std_kwargs : dict, optional
            Default arguments for
            [non_std](/tabtransformer/column/transformer/non_std#tabtransformer.column.transformer.non_std.NonStdTransformer)
            column transformer.
        column_kwargs : dict, optional
            Arguments for specific columns, if they have special settings.
            If data types here conflict with the lists provided in xx_columns,
            we will stick to xx_columns.
        label_threshold : float, optional
            The maximum categories for default one-hot encoding.
            This argument is used only if the default category normalizer type is one-hot encoding,
            and the exact normalizer type is not provided.
            If the total number of categories is larger than this threshold, we will use label encoding instead of
            one-hot encoding.
            The default value is 50.
        enforce_min : bool, optional
            Whether to enforce the minimum value as the value range.
            If not provided, we will check only the following scenarios:

            - If all values cover consecutive integers (every value should occur).
            - If all values are positive/non-negative.
            - If all values are within [-1, 1].
        enforce_max : bool, optional
            Whether to enforce the maximum value as the value range.
            If not provided, we will check only the following scenarios:

            - If all values cover consecutive integers (every value should occur).
            - If all values are negative/non-positive.
            - If all values are within [-1, 1].
        p_value_threshold : float, optional
            The p-value threshold for long tail test (both scipy normaltest on log data and skewtest on raw data).
            Default is 0.05.
        default_binary_norm_kwargs : dict, optional
            Default kwargs for
            [binary](/tabtransformer/column/normalizer/binary#tabtransformer.column.normalizer.binary.BinaryNormalizer.make)
            normalizer.
        default_multiclass_norm_kwargs : dict, optional
            Default kwargs for
            [multiclass](/tabtransformer/column/normalizer/multiclass#tabtransformer.column.normalizer.multiclass.MulticlassNormalizer.make)
            normalizer.
        default_numerical_norm_kwargs : dict, optional
            Default kwargs for
            [numerical](/tabtransformer/column/normalizer/numerical#tabtransformer.column.normalizer.numerical.NumericalNormalizer.make)
            normalizer.
        """
        data = data.drop(columns=[
            c for c in make_list(drop_columns)
            if c in data.columns
        ])
        column_kwargs = make_dict(column_kwargs)
        column_raw_dtypes = cls._learn_raw_dtypes(
            categorical_columns, numerical_columns, datetime_columns,
            timedelta_columns, mixed_columns, encoding_columns, non_std_columns,
            column_kwargs)
        for col, info in make_dict(encoding_columns).items():
            if col not in column_kwargs:
                column_kwargs[col] = {}
            column_kwargs[col]["info_data"] = info

        transformer_args = cls._learn_kwargs(
            data, column_kwargs, column_raw_dtypes,
            default_categorical_kwargs, default_numerical_kwargs, default_datetime_kwargs,
            default_timedelta_kwargs, default_mixed_kwargs, default_non_std_kwargs,
            unique_threshold, force_min_category, try_casting, max_mixed_category,
            label_threshold, enforce_min, enforce_max, p_value_threshold,
            default_binary_norm_kwargs, default_multiclass_norm_kwargs, default_numerical_norm_kwargs
        )
        logging.debug(f"The learned argument is {json.dumps(make_json_compatible(transformer_args), indent=2)}")

        return transformer_args

    @classmethod
    def _learn_kwargs(cls,
                      data: pd.DataFrame,
                      column_kwargs: Dict[ColumnName, Dict[str, Any]],
                      column_raw_dtypes: Dict[ColumnName, RawDType],
                      default_categorical_kwargs: Optional[Dict[str, Any]],
                      default_numerical_kwargs: Optional[Dict[str, Any]],
                      default_datetime_kwargs: Optional[Dict[str, Any]],
                      default_timedelta_kwargs: Optional[Dict[str, Any]],
                      default_mixed_kwargs: Optional[Dict[str, Any]],
                      default_non_std_kwargs: Optional[Dict[str, Any]],
                      unique_threshold: float,
                      force_min_category: int,
                      try_casting: bool,
                      max_mixed_category: int,
                      label_threshold: float,
                      enforce_min: Optional[bool],
                      enforce_max: Optional[bool],
                      p_value_threshold: float,
                      default_binary_norm_kwargs: Optional[Dict[str, Any]],
                      default_multiclass_norm_kwargs: Optional[Dict[str, Any]],
                      default_numerical_norm_kwargs: Optional[Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
        default_args_by_dtype = {
            RawDType.categorical: make_dict(default_categorical_kwargs),
            RawDType.numerical: make_dict(default_numerical_kwargs),
            RawDType.datetime: make_dict(default_datetime_kwargs),
            RawDType.timedelta: make_dict(default_timedelta_kwargs),
            RawDType.mixed: make_dict(default_mixed_kwargs),
            RawDType.non_std: make_dict(default_non_std_kwargs)
        }
        default_args_by_stype = {
            SType.non_std: {},
            SType.binary: make_dict(default_binary_norm_kwargs),
            SType.multiclass: make_dict(default_multiclass_norm_kwargs),
            SType.numerical: make_dict(default_numerical_norm_kwargs)
        }
        transformer_args = iterate_over_list(
            cls._learn_kwargs_for_col,
            data.columns,
            return_format="dict",
            data=data,
            column_kwargs=column_kwargs,
            column_raw_dtypes=column_raw_dtypes,
            default_args_by_dtype=default_args_by_dtype,
            default_args_by_stype=default_args_by_stype,
            unique_threshold=unique_threshold,
            force_min_category=force_min_category,
            try_casting=try_casting,
            max_mixed_category=max_mixed_category,
            label_threshold=label_threshold,
            enforce_min=enforce_min,
            enforce_max=enforce_max,
            p_value_threshold=p_value_threshold
        )
        return transformer_args

    @classmethod
    def _learn_kwargs_for_col(cls,
                              col: ColumnName,
                              data: pd.DataFrame,
                              column_kwargs: Dict[ColumnName, Dict[str, Any]],
                              column_raw_dtypes: Dict[ColumnName, RawDType],
                              default_args_by_dtype: Dict[RawDType, Dict[str, Any]],
                              default_args_by_stype: Dict[SType, Dict[str, Any]],
                              unique_threshold: float,
                              force_min_category: int,
                              try_casting: bool,
                              max_mixed_category: int,
                              label_threshold: float,
                              enforce_min: Optional[bool],
                              enforce_max: Optional[bool],
                              p_value_threshold: float, ) -> Dict[str, Any]:
        dtype = column_raw_dtypes.get(col)
        provided_args = make_dict(column_kwargs.get(col))
        args = ColumnTransformer.learn_args(
            data=data.loc[:, col],
            default_args=default_args_by_dtype,
            provided_args=provided_args,
            unique_threshold=unique_threshold,
            force_min_category=force_min_category,
            try_casting=try_casting,
            max_mixed_category=max_mixed_category,
            raw_dtype=dtype,
            default_norm_args_by_stype=default_args_by_stype,
            label_threshold=label_threshold,
            enforce_min=enforce_min,
            enforce_max=enforce_max,
            p_value_threshold=p_value_threshold
        )
        return args

    @classmethod
    def _learn_raw_dtypes(cls,
                          categorical_columns: Optional[List[ColumnName]],
                          numerical_columns: Optional[List[ColumnName]],
                          datetime_columns: Optional[List[ColumnName]],
                          timedelta_columns: Optional[List[ColumnName]],
                          mixed_columns: Optional[List[ColumnName]],
                          encoding_columns: Optional[Dict[ColumnName, Union[str, PredefinedEncoder]]],
                          non_std_columns: Optional[List[ColumnName]],
                          column_kwargs: Dict[str, Any],
                          ) -> Dict[ColumnName, RawDType]:
        column_raw_dtypes: Dict[ColumnName, RawDType] = {}
        for c, kwargs in column_kwargs.items():
            dtype = kwargs.get("raw_dtype")
            if dtype is not None:
                column_raw_dtypes[c] = make_enum(dtype, RawDType)
        forced_dtypes = learn_forced_dtypes(
            categorical_columns, numerical_columns, datetime_columns, timedelta_columns, mixed_columns,
            [*make_dict(encoding_columns).keys()], non_std_columns
        )
        column_raw_dtypes.update(forced_dtypes)
        return column_raw_dtypes

    @log_time("Recovering N/A values in normalized data", "Recovered N/A values in normalized data",
              log.TRACE_LEVEL, logging.DEBUG)
    def inverse_normalized_na(self,
                              normalized: pd.DataFrame,
                              columns: Optional[Collection[ColumnName]] = None) -> pd.DataFrame:
        """
        Recover N/A values in standardized data.

        Parameters
        ----------
        normalized : pd.DataFrame
            The normalized DataFrame without N/A values.
            This should have 3-level columns.
        columns : list, optional
            List of columns to recover the N/A values on.

        Returns
        -------
        pd.DataFrame
            The normalized data with some N/A values recovered.
        """
        columns = make_list(columns)
        data_columns = {a for a, b, c in normalized.columns}
        new = {}
        for c in self.columns:
            if c in columns:
                new[c] = self.column_transformers[c].inverse_normalized_na(normalized[c])
            else:
                if c not in data_columns and (
                        self.column_transformers[c].raw_dtype == RawDType.non_std or
                        self.column_transformers[c].normalized_dim == 0):
                    continue
                new[c] = normalized[c]
        return pd.concat(new, axis=1)
