"""Textualizing tabular data to text."""

import math
from typing import Any, Collection, Dict, List, Literal, Optional, Tuple, Type, Union

import numpy as np
import pandas as pd
from transformers import BatchEncoding

from ..column import ColumnTextualizer
from ..dtypes import ColumnName, RawDType, learn_forced_dtypes
from ..tokenizer import TabularDataTokenizer
from ..utils import log_time, make_dict, make_enum, make_list


class TableTextualizer:
    """
    Textualizer of table after unnecessary data dropped.
    """
    def __init__(self,
                 tokenizer: TabularDataTokenizer,
                 column_kwargs: Optional[Dict[ColumnName, Dict[str, Any]]] = None,
                 target_columns: Optional[Union[ColumnName, List[ColumnName]]] = None,
                 use_raw_column_name: bool = False,):
        """
        Initialize a new instance of `TableTextualizer`, for a new dataset.

        Parameters
        ----------
        tokenizer : TabularDataTokenizer
            The tokenizer of text.
        target_columns : list[str] or str, optional
            Columns that are the target to be predicted. In the output, if they are combined to the other columns,
            they are usually grouped and placed at the right-most columns unless otherwise stated.
        column_kwargs : dict, optional
            Arguments to each column.
            We will not do automatic detection, so if your dataset is not empty, do make sure that all columns are
            present in this dict.
            If you want to reduce the work for constructing input, please go to class methods `learn` or `make`.
        use_raw_column_name : bool, optional
            Whether to use raw column name, or to use the special column tokens.
        """
        self.tokenizer = tokenizer
        if isinstance(target_columns, str):
            self.target_columns = [target_columns]
        else:
            self.target_columns = make_list(target_columns)
        self.columns = {}
        column_kwargs = make_dict(column_kwargs)
        self.column_names = []
        self.use_raw_column_name = use_raw_column_name
        for i, (c, kwargs) in enumerate(column_kwargs.items()):
            dtype: RawDType = make_enum(kwargs["raw_dtype"], RawDType)
            kwargs = kwargs.copy()
            del kwargs["raw_dtype"]
            self.columns[c] = ColumnTextualizer.make(
                raw_dtype=dtype,
                tokenizer=tokenizer,
                name=c,
                index=i,
                **kwargs
            )
            self.column_names.append(c)

    @log_time("Fitting textualizer", "Finished fitting textualizer")
    def fit(self, data: pd.DataFrame):
        """
        Fit the textualizer to the data.

        Parameters
        ----------
        data : pd.DataFrame
            The data to fit textualizer on.
        """
        data = data[self.column_names]
        for c in self.columns:
            self.columns[c].fit(data.loc[:, c])

    @log_time("Textualizing data", "Finished textualization")
    def textualize(self,
                   data: pd.DataFrame,
                   group_size: int = 1,
                   mask_target: bool = False,
                   mask_ratio: Optional[Union[int, float, Tuple[int, int], Tuple[float, float]]] = (.3, .7)) -> \
            Union[List[str], Tuple[List[str], List[str]]]:
        """
        Textualize the data.

        Parameters
        ----------
        data : pd.DataFrame
            The data to textualize.
        group_size : int, optional
            Number of rows to group in one sentence.
        mask_target : bool, optional
            Whether to add mask on target.
        mask_ratio : number, or (number, number), optional
            If float is given, the number is understood as ratio in total number of columns to mask.
            If integer is given, the number is understood as the number of columns to mask.
            If None, no masking is applied.

        Returns
        -------
        list[str]
            Text for each group.
        list[str], optional
            Masked text for each group.
        """
        n_col = len(self.columns)
        non_target_columns = [c for c in self.column_names if c not in self.target_columns]
        n_non_target_col = len(non_target_columns)
        n_target_col = len(self.target_columns)

        do_mask = mask_ratio is not None
        min_n_mask = 0
        max_n_mask = 0
        if do_mask:
            if isinstance(mask_ratio, Collection):
                min_n_mask, max_n_mask = mask_ratio
            else:
                min_n_mask, max_n_mask = mask_ratio, mask_ratio
        n_maskable_col = n_col if mask_target else n_non_target_col
        if not isinstance(min_n_mask, int):
            min_n_mask = int(min_n_mask * n_maskable_col)
        if not isinstance(max_n_mask, int):
            max_n_mask = math.ceil(max_n_mask * n_maskable_col)

        text_data = {}
        for c, textualizer in self.columns.items():
            text_data[c] = textualizer.textualize(data.loc[:, c])
        text_data = pd.DataFrame(text_data)

        text_out = []
        masked_out = []
        for _, row in text_data.iterrows():
            target_indices = np.random.choice(np.arange(n_target_col), size=n_target_col, replace=False)
            n_mask = np.random.randint(min_n_mask, max_n_mask + 1)
            mask_indices = np.random.choice(np.arange(n_maskable_col), size=n_mask, replace=False)
            non_tar_row_text_out, non_tar_row_masked_out = self._textualize_subrow(do_mask, mask_indices, non_target_columns, row)
            tar_row_text_out, tar_row_masked_out = self._textualize_subrow(
                do_mask, mask_indices - n_non_target_col, target_indices, row)
            row_text_out = self.tokenizer.cell_sep_token.join(non_tar_row_text_out + tar_row_text_out)
            text_out.append(row_text_out)
            if do_mask:
                row_masked_out = self.tokenizer.cell_sep_token.join(non_tar_row_masked_out + tar_row_masked_out)
                masked_out.append(row_masked_out)

        grouped_text_out = []
        grouped_masked_out = []
        for st in range(0, len(data), group_size):
            group = text_out[st:st + group_size]
            grouped_text_out.append(self.tokenizer.row_sep_token.join(group))
            if do_mask:
                masked_group = masked_out[st:st + group_size]
                grouped_masked_out.append(self.tokenizer.row_sep_token.join(masked_group))
        if do_mask:
            return grouped_text_out, grouped_masked_out
        else:
            return grouped_text_out

    def _textualize_subrow(self, do_mask: bool, mask_indices: np.ndarray, columns: List[ColumnName], row):
        n_col = len(columns)
        shuffled_indices = np.random.choice(np.arange(n_col), size=n_col, replace=False)
        row_text_out = []
        row_masked_out = []
        for i in shuffled_indices:
            col = columns[i]
            textualizer = self.columns[col]
            prefix = textualizer.cell_prefix(self.use_raw_column_name)
            value = row[col]
            row_text_out.append(f"{prefix}{value}")
            if do_mask:
                if i in mask_indices:
                    masked_value = "".join([
                        self.tokenizer.mask_token
                        for _ in range(textualizer.n_tokens)
                    ])
                else:
                    masked_value = value
                row_masked_out.append(f"{prefix}{masked_value}")
        return row_text_out, row_masked_out

    @log_time("Recovering raw DataFrame from text", "Recovered raw data")
    def recover_from_text(self,
                          data: List[str],
                          group_size: Optional[int] = None,
                          abandon_by_group: bool = False,
                          use_placeholder_for_invalid: bool = True,
                          duplicated_columns_allowed: bool = False,
                          invalid_cells_allowed: bool = False,
                          return_valid_indicator: bool = True) -> \
            Union[pd.DataFrame, Tuple[pd.DataFrame, pd.Series]]:
        """
        Recover raw DataFrame from list of sentences in text.

        Parameters
        ----------
        data : list[str]
            The textual sentences to recover data from.
        group_size : int, optional
            The number of rows per sentence.
            If not provided, we will not care about the group sizes.
        abandon_by_group : bool, optional
            Whether to abandon the entire group if one of the rows in the group is invalid,
            especially in the cases where each group has more than one row.
        use_placeholder_for_invalid : bool, optional
            Whether to keep the places where invalid rows are.
            Invalid values will be replaced by nan.
        duplicated_columns_allowed : bool, optional
            Whether duplicated columns within one row is allowed.
        invalid_cells_allowed : bool, optional
            Whether some invalid cells within a row is allowed, such that invalid cells does not invalidate the entire
            row if other parts of the sentence completes the information without error.
        return_valid_indicator : bool, optional
            Whether to return a Series of bool indicating whether each row is valid.
        """
        rows = []
        valid_indicator = []
        for gi, group in enumerate(data):
            group_rows = group.split(self.tokenizer.row_sep_token)
            text_group = []
            group_valid_indicator = []
            for row in group_rows:
                row_is_valid = True
                text_row = {}
                cells = row.split(self.tokenizer.cell_sep_token)
                for cell in cells:
                    if self.use_raw_column_name:
                        split = cell.split(self.tokenizer.kv_sep_token)
                        if len(split) != 2:
                            if not invalid_cells_allowed:
                                row_is_valid = False
                            continue
                        col_name, col_value = split
                        if col_name not in self.column_names:
                            if not invalid_cells_allowed:
                                row_is_valid = False
                            continue
                    else:
                        this_col_id = None
                        for col_id in range(self.tokenizer.num_columns):
                            col_token = self.tokenizer.get_column_token(col_id)
                            if cell.startswith(col_token):
                                this_col_id = col_id
                                cell = cell[len(col_token):]
                                break
                        if (this_col_id is None or this_col_id >= len(self.column_names)) \
                                and not invalid_cells_allowed:
                            row_is_valid = False
                            continue
                        else:
                            col_name = self.column_names[this_col_id]
                            col_value = cell
                    if col_name in text_row:
                        if not duplicated_columns_allowed:
                            row_is_valid = False
                        continue
                    text_row[col_name] = col_value
                for c in self.column_names:
                    if c not in text_row:
                        row_is_valid = False
                        text_row[c] = np.nan
                text_group.append(text_row)
                group_valid_indicator.append(row_is_valid)
            invalid_size = False
            if group_size is not None:
                if len(text_group) > group_size:
                    invalid_size = True
                    text_group = text_group[:group_size]
                    group_valid_indicator = group_valid_indicator[:group_size]
                elif len(text_group) < group_size and gi < len(data) - 1:
                    invalid_size = True
                    n_missing = group_size - len(text_group)
                    text_group.extend([{
                        c: np.nan for c in self.column_names}
                        for _ in range(n_missing)
                    ])
                    group_valid_indicator.extend([False for _ in range(n_missing)])
            if abandon_by_group:
                if not all(group_valid_indicator) or invalid_size:
                    group_valid_indicator = [False for _ in group_valid_indicator]
            rows += text_group
            valid_indicator += group_valid_indicator

        text_df = pd.DataFrame(rows)
        valid_indicator = pd.Series(valid_indicator)
        raw_df = {}
        for c, textualizer in self.columns.items():
            raw_df[c], col_valid_indicator = textualizer.inverse_textualize(text_df.loc[:, c])
            valid_indicator &= col_valid_indicator
        raw_df = pd.DataFrame(raw_df)

        if not use_placeholder_for_invalid:
            raw_df = raw_df[valid_indicator].reset_index(drop=True)
        if return_valid_indicator:
            return raw_df, valid_indicator
        else:
            return raw_df

    @log_time("Encoding textualized data", "Finished encoding")
    def encode(self,
               input_data: List[str],
               target_data: Optional[List[str]] = None,
               **kwargs) -> BatchEncoding:
        """
        Encode data to token IDs.

        Parameters
        ----------
        input_data : list[str]
            The input sentences.
        target_data : list[str], optional
            The target sentences. If not provided, the input is used as target.
        **kwargs
            Other arguments to __call__ of tokenizer.

        Returns
        -------
        BatchEncoding
            Result of calling the tokenizer.
        """
        if target_data is None:
            target_data = input_data
        return self.tokenizer(input_data, text_target=target_data, **kwargs)

    @log_time("Decoding token IDs to text", "Finished decoding")
    def decode(self, tokens: List[List[int]]) -> List[str]:
        """
        Decode the token IDs back to strings.

        Parameters
        ----------
        tokens : list[list]
            List of tokens to decode

        Returns
        -------
        list[str]
            List of decoded strings
        """
        text_data = [self.tokenizer.decode(t) for t in tokens]
        text_data = [d.replace("\n", " ") for d in text_data]
        empty_strings = [self.tokenizer.pad_token, "\r", self.tokenizer.in_cell_pad_token]
        for s in empty_strings:
            text_data = [d.replace(s, "") for d in text_data]
        return text_data

    @classmethod
    @log_time("Learning textualizer kwargs", "Finished learning textualizer kwargs")
    def learn_args(cls,
                   data: pd.DataFrame,
                   tokenizer: Union[TabularDataTokenizer, Literal["great", "default", "learn"]] = "learn",
                   *,
                   use_raw_column_name: Optional[bool] = None,
                   drop_columns: Optional[List[ColumnName]] = None,
                   categorical_columns: Optional[List[ColumnName]] = None,
                   numerical_columns: Optional[List[ColumnName]] = None,
                   datetime_columns: Optional[List[ColumnName]] = None,
                   timedelta_columns: Optional[List[ColumnName]] = None,
                   mixed_columns: Optional[List[ColumnName]] = None,
                   encoding_columns: Optional[List[ColumnName]] = None,
                   non_std_columns: Optional[List[ColumnName]] = None,
                   unique_threshold: float = .95,
                   encoding_threshold: int = 200,
                   default_categorical_kwargs: Optional[Dict[str, Any]] = None,
                   default_numerical_kwargs: Optional[Dict[str, Any]] = None,
                   default_datetime_kwargs: Optional[Dict[str, Any]] = None,
                   default_timedelta_kwargs: Optional[Dict[str, Any]] = None,
                   default_mixed_kwargs: Optional[Dict[str, Any]] = None,
                   default_encoding_kwargs: Optional[Dict[str, Any]] = None,
                   default_non_std_kwargs: Optional[Dict[str, Any]] = None,
                   column_kwargs: Optional[Dict[str, Any]] = None,
                   return_tokenizer: bool = False,
                   **kwargs) -> Union[Dict[str, Any], Tuple[Dict[str, Any], TabularDataTokenizer]]:
        """
        Learn the column kwargs for column textualizers.

        Parameters
        ----------
        data : pd.DataFrame
            The input data.
        tokenizer : TabularDataTokenizer, or str
            The tokenizer to use. If it is a string, we construct a tokenizer by the `make` function with kwargs.
        use_raw_column_name : bool
            Whether to use raw column name, or to use the special column tokens.
        drop_columns : list[str], optional
            Columns to be dropped. They do not need kwargs.
        categorical_columns : list[str], optional
            Names of categorical columns. This list need not be comprehensive.
            From this parameter to `non_std_columns`, the sets should be mutually exclusive.
            Columns not mentioned in this six arguments will learn the data type.
        numerical_columns : list[str], optional
            Names of numerical columns. This list need not be comprehensive.
        datetime_columns : list[str], optional
            Names of datetime columns. This list need not be comprehensive.
        timedelta_columns : list[str], optional
            Names of timedelta columns. This list need not be comprehensive.
        mixed_columns : list[str], optional
            Names of columns mixing either numerical, datetime, or timedelta (exactly one of them)
            with some special strings (each recognized as a category). This list need not be comprehensive.
        encoding_columns : dict[str, str], optional
            Columns that has some encodings describing its information and can be matched back by nearest neighbors.
            Such columns include countries, cities, companies, etc.
            This is a dict matching the column name to the information of encoding (which is a .csv file or a
            pre-defined encoding type).
        non_std_columns : list[str], optional
            Non-standard column names. Columns cannot be grouped into the above five types.
            For example, ID, name, email, etc.
        unique_threshold : float, optional
            After removing N/A values in the column, if the number of unique non-continuous values divided by the
            number of rows hit this threshold, this column will be treated as non-standard. Default is 0.95.
        encoding_threshold : int, optional
            If the number of different categories (besides N/A) is greater or equal to this value,
            and we do not hit the unique threshold above, we will treat it as encoding. Default is 200.
        default_categorical_kwargs : dict, optional
            Default arguments for categorical column textualizer.
        default_numerical_kwargs : dict, optional
            Default arguments for numerical column textualizer.
        default_datetime_kwargs : dict, optional
            Default arguments for datetime column textualizer.
        default_timedelta_kwargs : dict, optional
            Default arguments for timedelta column textualizer.
        default_mixed_kwargs : dict, optional
            Default arguments for mixed column textualizer.
        default_encoding_kwargs : dict, optional
            Default arguments for encoding column textualizer.
        default_non_std_kwargs : dict, optional
            Default arguments for non-standard column textualizer.
        column_kwargs : dict, optional
            Arguments for specific columns, if they have special settings.
            If data types here conflict with the lists provided in xx_columns,
            we will stick to xx_columns.
        return_tokenizer : bool, optional
            Whether to return the tokenizer constructed.
        **kwargs
            Arguments to make the tokenizer if it is not yet constructed.

        Returns
        -------
        dict
            The learned arguments to the textualizer.
        TabularDataTokenizer, optional
            The tokenizer used. It is returned only if `return_tokenizer is set True.
        """
        if isinstance(tokenizer, str):
            tokenizer = TabularDataTokenizer.make(
                tokenizer,
                data=data,
                use_raw_column_name=use_raw_column_name,
                drop_columns=drop_columns,
                categorical_columns=categorical_columns,
                numerical_columns=numerical_columns,
                datetime_columns=datetime_columns,
                timedelta_columns=timedelta_columns,
                mixed_columns=mixed_columns,
                encoding_columns=encoding_columns,
                non_std_columns=non_std_columns,
                unique_threshold=unique_threshold,
                encoding_threshold=encoding_threshold,
                **kwargs)
        data = data.drop(columns=[
            c for c in make_list(drop_columns)
            if c in data.columns
        ])
        if use_raw_column_name is None:
            use_raw_column_name = tokenizer.num_columns == 0
        forced_dtypes = learn_forced_dtypes(categorical_columns, numerical_columns, datetime_columns,
                                            timedelta_columns, mixed_columns, encoding_columns, non_std_columns)

        default_args_by_type = {}
        for dtype, default_args in zip(
            [RawDType.categorical, RawDType.numerical, RawDType.datetime, RawDType.timedelta,
             RawDType.mixed, RawDType.encoding, RawDType.non_std],
            [default_categorical_kwargs, default_numerical_kwargs, default_datetime_kwargs, default_timedelta_kwargs,
             default_mixed_kwargs, default_encoding_kwargs, default_non_std_kwargs]
        ):
            textualizer_class: Type[ColumnTextualizer] = ColumnTextualizer.registry[dtype]
            default_args_by_type[dtype] = textualizer_class.learn_default_args(tokenizer, default_args)

        result = {}
        column_kwargs = make_dict(column_kwargs)
        all_columns = {*data.columns} | {*column_kwargs}
        for c in all_columns:
            if c not in data.columns:
                result[c] = column_kwargs[c]
            else:
                result[c] = ColumnTextualizer.learn_args(
                    data=data.loc[:, c],
                    tokenizer=tokenizer,
                    raw_dtype=forced_dtypes.get(c),
                    unique_threshold=unique_threshold,
                    encoding_threshold=encoding_threshold,
                    default_args=default_args_by_type,
                    provided_args=column_kwargs.get(c)
                )
        result_dict = {
            "tokenizer": tokenizer,
            "column_kwargs": result,
            "use_raw_column_name": use_raw_column_name
        }
        if return_tokenizer:
            return result_dict, tokenizer
        else:
            return result_dict
