"""Integrated tabular data transformation class."""

import json
import logging
import os
from typing import Any, Dict, List, Optional, Tuple, Union

import numpy as np
import pandas as pd
import torch

from .args_validator import validate_data_kwargs, validate_format_kwargs, validate_learn_kwargs
from .balancer import TableBalancer
from .dropper import TableDropper
from .imputer import TableImputer
from .normalizer import TableNormalizer
from .reducer import DimReducer, DimReducerType, TableDimReducer
from ..column.transformer.encoding import PredefinedEncoder
from ..dtypes import ColumnName, SType
from ..utils import log, log_time, make_json_compatible


class TableTransformer:
    """
    Transformer of a tabular-formatted table.

    Example
    -------
    >>> import json
    >>> from tabtransformer import TableTransformer
    >>> data = TableTransformer.load_data("sample_data.csv")
    >>> data
    | categorical | numerical |
    |-------------|-----------|
    | A           | 1         |
    | B           | 0         |
    >>> with open("learn_args.json", "r") as f:
    >>>     learn_args = json.load(f)
    >>> learn_args  # the arguments for learning arguments
    {"drop_columns": [],
     "categorical_columns": [],
     ...
    }
    >>> TableTransformer.validate_learn_kwargs(data, learn_args)
    None
    >>> data_args = TableTransformer.learn_args(data, **learn_args)
    >>> data_args  # the learned data arguments
    {"drop_columns": [],
     "column_kwargs": {...},
     ...
    }
    >>> TableTransformer.validate_data_kwargs(data, data_args)
    None
    >>> transformer = TableTransformer(**data_args)
    >>> transformer.fit(data)
    >>> transformed = transformer.transform(data)
    >>> transformed  # the result depends on the actual transformation arguments used
    | categorical | numerical         |
    | val         | mode | val        |
    | cat1 | cat2 | cat1 | cat2 | val |
    |-------------|-------------------|
    | 1    | 0    | 1    | 0    | 0   |
    | 0    | 1    | 0    | 1    | 0   |
    >>> transformer.inverse_transform()  # may not necessarily get back the exact same result but possible
    | categorical | numerical |
    |-------------|-----------|
    | A           | 1         |
    | B           | 0         |

    For more detailed demostration on larger datasets, please refer to `notebook/actual-transformer-demo.ipynb`
    and `notebook/dummy-transformer-demo.ipynb`.
    """

    def __init__(self, *,
                 drop_columns: Optional[List[ColumnName]] = None,
                 dropna_columns: Optional[List[ColumnName]] = None,
                 target_columns: Optional[Union[ColumnName, List[ColumnName]]] = None,
                 column_kwargs: Optional[Dict[str, Any]] = None,
                 important_columns: Optional[List[ColumnName]] = None,
                 reversible_reducers: Optional[List[Union[
                     DimReducer, Tuple[Union[str, DimReducerType], int, Dict[str, Any]]
                 ]]] = None,
                 irreversible_reducers: Optional[List[Union[
                     DimReducer, Tuple[Union[str, DimReducerType], int, Dict[str, Any]]
                 ]]] = None,
                 impute_columns: Optional[List[ColumnName]] = None,
                 imputer_kwargs: Optional[Dict[str, Any]] = None,
                 imbalance_columns: Optional[List[ColumnName]] = None,
                 sampler_kwargs: Optional[Dict[Union[ColumnName, Tuple[ColumnName, str]], Any]] = None):
        """
        Initialize a new instance of `TableTransformer`, for a new dataset.
        Parameters include all parameters from constructors or fit functions of
        [`TableDropper`](/tabtransformer/table/dropper#tabtransformer.table.dropper.TableDropper),
        [`TableNormalizer`](/tabtransformer/table/normalizer#tabtransformer.table.normalizer.TableNormalizer),
        [`TableImputer`](/tabtransformer/table/imputer#tabtransformer.table.imputer.TableImputer),
        [`TableBalancer`](/tabtransformer/table/balancer#tabtransformer.table.balancer.TableBalancer),
        and [`TableDimReducer`](/tabtransformer/table/reducer#tabtransformer.table.reducer.TableDimReducer).
        The following shows special parameters only.

        Parameters
        ----------
        imbalance_columns: list, optional
            Columns to do some sampling to solve imbalance issue.
            If not provided, we will use all target columns.
        """
        logging.debug("Initializing TableTransformer ...")
        self.dropper = TableDropper(
            drop_columns=drop_columns,
            dropna_columns=dropna_columns
        )
        self.normalizer = TableNormalizer(
            target_columns=target_columns,
            column_kwargs=column_kwargs
        )
        self.imputer = TableImputer(
            impute_columns=impute_columns,
            imputer_kwargs=imputer_kwargs
        )
        self.reducer = TableDimReducer(
            reversible_reducers=reversible_reducers,
            irreversible_reducers=irreversible_reducers
        )
        if imbalance_columns is None:
            if isinstance(target_columns, str):
                imbalance_columns = [target_columns]
            else:
                imbalance_columns = target_columns
        self.balancer = TableBalancer(
            target_columns=imbalance_columns,
            sampler_kwargs=sampler_kwargs
        )
        self._important_columns = important_columns
        self._total_dim = None
        self._transformed_columns = None
        logging.debug("Finished initializing TableTransformer.")

    @property
    def fitted(self) -> bool:
        """Whether the transformer is fitted."""
        return self._total_dim is not None

    def drop(self, data: pd.DataFrame, drop_duplicates: bool = True) -> pd.DataFrame:
        """
        Inherited from [`dropper`](/tabtransformer/table/dropper#tabtransformer.table.dropper.TableDropper.drop).
        """
        return self.dropper.drop(data, drop_duplicates)

    def drop_column(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        Inherited from [`dropper`](/tabtransformer/table/dropper#tabtransformer.table.dropper.TableDropper.drop_column).
        """
        return self.dropper.drop_column(data)

    def dropna(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        Inherited from [`dropper`](/tabtransformer/table/dropper#tabtransformer.table.dropper.TableDropper.dropna).
        """
        return self.dropper.dropna(data)

    def drop_duplicates(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        Inherited from [`dropper`](/tabtransformer/table/dropper#tabtransformer.table.dropper.TableDropper.drop_duplicates).
        """
        return self.dropper.drop_duplicates(data)

    def fit_columns(self, data: pd.DataFrame):
        """
        Inherited from
        [`normalizer`](/tabtransformer/table/normalizer#tabtransformer.table.normalizer.TableNormalizer.fit).
        """
        self.normalizer.fit(data)

    def clean(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        Inherited from
        [`normalizer`](/tabtransformer/table/normalizer#tabtransformer.table.normalizer.TableNormalizer.clean).
        """
        return self.normalizer.clean(data)

    def inverse_clean(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        Inherited from
        [`normalizer`](/tabtransformer/table/normalizer#tabtransformer.table.normalizer.TableNormalizer.inverse_clean).
        """
        return self.normalizer.inverse_clean(data)

    def standardize(self,
                    data: pd.DataFrame,
                    return_non_std: bool = False,
                    return_target: bool = True,
                    combine_target: bool = False
                    ) -> Union[pd.DataFrame, Tuple[pd.DataFrame, pd.DataFrame]]:
        """
        Inherited from
        [`normalizer`](/tabtransformer/table/normalizer#tabtransformer.table.normalizer.TableNormalizer.standardize).
        """
        return self.normalizer.standardize(
            data,
            return_non_std=return_non_std,
            return_target=return_target,
            combine_target=combine_target
        )

    def inverse_standardize(self,
                            *data: pd.DataFrame,
                            assign_non_std: bool = True) -> pd.DataFrame:
        """
        Inherited from
        [`normalizer`](/tabtransformer/table/normalizer#tabtransformer.table.normalizer.TableNormalizer.inverse_standardize).
        """
        return self.normalizer.inverse_standardize(
            *data, assign_non_std=assign_non_std
        )

    def normalize(self,
                  *data: pd.DataFrame,
                  return_target: bool = True,
                  combine_target: bool = False,
                  normalize_target: bool = False,
                  ) -> Union[pd.DataFrame, Tuple[pd.DataFrame, pd.DataFrame]]:
        """
        Inherited from
        [`normalizer`](/tabtransformer/table/normalizer#tabtransformer.table.normalizer.TableNormalizer.normalize).
        """
        return self.normalizer.normalize(
            *data,
            return_target=return_target,
            combine_target=combine_target,
            normalize_target=normalize_target
        )

    def inverse_normalize(self, *data: pd.DataFrame) -> pd.DataFrame:
        """
        Inherited from
        [`normalizer`](/tabtransformer/table/normalizer#tabtransformer.table.normalizer.TableNormalizer.inverse_normalize).
        """
        return self.normalizer.inverse_normalize(*data)

    def discretize(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        Inherited from
        [`normalizer`](/tabtransformer/table/normalizer#tabtransformer.table.normalizer.TableNormalizer.discretize).
        """
        return self.normalizer.discretize(data)

    def inverse_discretize(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        Inherited from
        [`normalizer`](/tabtransformer/table/normalizer#tabtransformer.table.normalizer.TableNormalizer.inverse_discretize).
        """
        return self.normalizer.inverse_discretize(data)

    @property
    def normalized_span_info(self) -> (List[Tuple[int, SType]], List[Tuple[int, SType]]):
        """
        Inherited from
        [`normalizer`](/tabtransformer/table/normalizer#tabtransformer.table.normalizer.TableNormalizer.normalized_span_info).
        """
        return self.normalizer.normalized_span_info

    def normalized_span_info_of(self, columns: List[ColumnName]) -> (List[Tuple[int, SType]], List[Tuple[int, SType]]):
        """
        Inherited from
        [`normalizer`](/tabtransformer/table/normalizer#tabtransformer.table.normalizer.TableNormalizer.normalized_span_info_of).
        """
        return self.normalizer.normalized_span_info_of(columns)

    @classmethod
    def make(cls, path: Optional[str] = None, *args, **kwargs) -> "TableTransformer":
        """
        Construct a transformer from arguments or load from path.

        Parameters
        ----------
        path : str, optional
            The path of the transformer.
        *args, **kwargs
            Arguments to the TableTransformer
            [constructor](/tabtransformer/table/transformer#tabtransformer.table.transformer.TableTransformer).

        Returns
        -------
        TableTransformer
            The constructed transformer.
        """
        if path is not None and os.path.exists(path):
            result = torch.load(path)
            logging.info(f"Loaded transformer from {path}.")
            return result
        return cls(*args, **kwargs)

    @classmethod
    def _handle_load_args(cls, data: Union[str, pd.DataFrame], **kwargs) -> Tuple[pd.DataFrame, Dict[str, Any]]:
        if isinstance(data, str):
            format_kwargs = kwargs.get("format", {})
            data = cls.load_data(data, **format_kwargs)
            return data, {
                k: v for k, v in kwargs.items()
                if k != "format"
            }
        return data, kwargs

    @classmethod
    def learn_column_kwargs(cls,
                            data: pd.DataFrame,
                            drop_columns: Optional[List[ColumnName]] = None,
                            categorical_columns: Optional[List[ColumnName]] = None,
                            numerical_columns: Optional[List[ColumnName]] = None,
                            datetime_columns: Optional[List[ColumnName]] = None,
                            timedelta_columns: Optional[List[ColumnName]] = None,
                            mixed_columns: Optional[List[ColumnName]] = None,
                            encoding_columns: Optional[Dict[ColumnName, Union[str, PredefinedEncoder]]] = None,
                            non_std_columns: Optional[List[ColumnName]] = None,
                            unique_threshold: float = .95,
                            force_min_category: int = 3,
                            try_casting: bool = True,
                            max_mixed_category: int = 5,
                            default_categorical_kwargs: Optional[Dict[str, Any]] = None,
                            default_numerical_kwargs: Optional[Dict[str, Any]] = None,
                            default_datetime_kwargs: Optional[Dict[str, Any]] = None,
                            default_timedelta_kwargs: Optional[Dict[str, Any]] = None,
                            default_mixed_kwargs: Optional[Dict[str, Any]] = None,
                            default_non_std_kwargs: Optional[Dict[str, Any]] = None,
                            column_kwargs: Optional[Dict[str, Any]] = None,
                            label_threshold: float = 50,
                            enforce_min: Optional[bool] = None,
                            enforce_max: Optional[bool] = None,
                            p_value_threshold: float = .05,
                            default_binary_norm_kwargs: Optional[Dict[str, Any]] = None,
                            default_multiclass_norm_kwargs: Optional[Dict[str, Any]] = None,
                            default_numerical_norm_kwargs: Optional[Dict[str, Any]] = None,
                            ) -> Optional[Dict[str, Any]]:
        """
        Inherited from
        [`normalizer`](/tabtransformer/table/normalizer#tabtransformer.table.normalizer.TableNormalizer.learn_column_kwargs).
        """
        return TableNormalizer.learn_column_kwargs(
            data, drop_columns, categorical_columns, numerical_columns, datetime_columns, timedelta_columns,
            mixed_columns, encoding_columns, non_std_columns, unique_threshold, force_min_category, try_casting,
            max_mixed_category, default_categorical_kwargs, default_numerical_kwargs, default_datetime_kwargs,
            default_timedelta_kwargs, default_mixed_kwargs, default_non_std_kwargs, column_kwargs, label_threshold,
            enforce_min, enforce_max, p_value_threshold, default_binary_norm_kwargs, default_multiclass_norm_kwargs,
            default_numerical_norm_kwargs
        )

    @classmethod
    @log_time("Learning parameters for TableTransformer", "Finished learning parameters for the TableTransformer")
    def learn_args(cls,
                   data: Union[str, pd.DataFrame],
                   **kwargs) -> Dict[str, Any]:
        """
        Learn all the arguments for TableTransformer constructor.

        Parameters
        ----------
        data : pd.DataFrame or str
            The input data (or data path).
        **kwargs
            Arguments to TableTransformer
            [constructor](/tabtransformer/table/transformer#tabtransformer.table.transformer.TableTransformer) or
            [`learn_column_kwargs`](/tabtransformer/table/transformer#tabtransformer.table.transformer.TableTransformer.learn_column_kwargs)
            method.
            If data is given as data path, "format" keyword is allowed.
            If data is given as pd.DataFrame, "format" keyword is not allowed.

        Returns
        -------
        dict
            The complete learned parameters for the constructor.
        """
        format_args = kwargs.get("format")
        data, kwargs = cls._handle_load_args(data, **kwargs)
        learn_column_kwargs = {
            k: v for k, v in kwargs.items()
            if k not in {"dropna_columns", "target_columns", "imbalance_columns", "important_columns",
                         "reversible_reducers", "irreversible_reducers", "impute_columns", "imputer_kwargs",
                         "sampler_kwargs"}
        }
        column_kwargs = cls.learn_column_kwargs(
            data,
            **learn_column_kwargs
        )
        target_columns = kwargs.get("target_columns", [])
        if isinstance(target_columns, str):
            target_columns = [target_columns]
        imbalance_columns = kwargs.get("imbalance_columns", target_columns)
        out = dict(
            drop_columns=kwargs.get("drop_columns", []),
            dropna_columns=kwargs.get("dropna_columns", []),
            target_columns=target_columns,
            column_kwargs=column_kwargs,
            important_columns=kwargs.get("important_columns", []),
            reversible_reducers=kwargs.get("reversible_reducers", [("variance_threshold", 100, {})]),
            irreversible_reducers=kwargs.get("reversible_reducers", []),
            impute_columns=kwargs.get("impute_columns", []),
            imputer_kwargs=kwargs.get("imputer_kwargs", dict(
                n_neighbors=5,
                weights="uniform",
                metric="nan_euclidean"
            )),
            imbalance_columns=imbalance_columns,
            sampler_kwargs=kwargs.get("sampler_kwargs", {
                c: dict(
                    imb_algo="smote",
                    imb_kwargs=dict(
                        sampling_strategy="auto",
                        k_neighbors=5
                    ),
                    discretizer_kwargs=dict(
                        algo="kmeans",
                        discretize_threshold=20,
                        init="k-means++",
                        n_init="warn",
                        max_iter=300,
                        tol=1e-4,
                        algorithm="lloyd"
                    )
                ) for c in imbalance_columns
            })
        )
        if format_args is not None:
            out["format"] = format_args
        logging.debug(f"The learned parameters is {json.dumps(make_json_compatible(out), indent=2)}.")
        return out

    @classmethod
    def validate_learn_kwargs(cls, data: Union[str, pd.DataFrame], args: Dict[str, Any]):
        """
        Inherited from
        [args validator](/tabtransformer/table/args_validator#tabtransformer.table.args_validator.validate_learn_kwargs),
        but data IO is allowed (the data can be provided as a path).
        """
        if isinstance(data, str):
            validate_format_kwargs(data, args.get("format", {}))
            data, args = cls._handle_load_args(data, **args)
        validate_learn_kwargs(data, args)

    @classmethod
    def validate_data_kwargs(cls, data: Union[str, pd.DataFrame], args: Dict[str, Any]):
        """
        Inherited from
        [args validator](/tabtransformer/table/args_validator#tabtransformer.table.args_validator.validate_data_kwargs),
        but data IO is allowed (the data can be provided as a path).
        """
        if isinstance(data, str):
            validate_format_kwargs(data, args.get("format", {}))
            data, args = cls._handle_load_args(data, **args)
        validate_data_kwargs(data, args)

    def fit_reducers(self, data: pd.DataFrame):
        """
        Inherited from [`reducer`](/tabtransformer/table/reducer#tabtransformer.table.reducer.TableDimReducer.fit).
        """
        self.reducer.fit(data, self._important_columns)

    def reversible_reduce(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        Inherited from [`reducer`](/tabtransformer/table/reducer#tabtransformer.table.reducer.TableDimReducer.reversible_reduce).
        """
        return self.reducer.reversible_reduce(data)

    def irreversible_reduce(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        Inherited from [`reducer`](/tabtransformer/table/reducer#tabtransformer.table.reducer.TableDimReducer.irreversible_reduce).
        """
        return self.reducer.irreversible_reduce(data)

    def reduce(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        Inherited from [`reducer`](/tabtransformer/table/reducer#tabtransformer.table.reducer.TableDimReducer.reduce).
        """
        return self.reducer.reduce(data)

    def recover_reduced(self, reduced: pd.DataFrame) -> pd.DataFrame:
        """
        Inherited from [`reducer`](/tabtransformer/table/reducer#tabtransformer.table.reducer.TableDimReducer.recover).
        """
        return self.reducer.recover(reduced)

    def fit_imputer(self, data: pd.DataFrame):
        """
        Inherited from [`imputer`](/tabtransformer/table/imputer#tabtransformer.table.imputer.TableImputer.fit),
        but inverse normalized N/A is applied beforehand.
        """
        data = self.normalizer.inverse_normalized_na(
            data, columns=self.imputer.impute_columns)
        self.imputer.fit(data)

    def impute(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        Inherited from [`imputer`](/tabtransformer/table/imputer#tabtransformer.table.imputer.TableImputer.impute),
        but inverse normalized N/A is applied beforehand.
        """
        data = self.normalizer.inverse_normalized_na(
            data, columns=self.imputer.impute_columns)
        return self.imputer.impute(data)

    def balance(self, normalized: pd.DataFrame, discretized: pd.DataFrame) -> pd.DataFrame:
        """
        Inherited from [`balancer`](/tabtransformer/table/balancer#tabtransformer.table.balancer.TableBalancer.sample).
        """
        return self.balancer.sample(normalized, discretized)

    @log_time("Fitting TableTransformer", "Finished fitting all elements in TableTransformer")
    def fit(self, data: pd.DataFrame):
        """
        Complete all fitting steps of a given dataset.

        Parameters
        ----------
        data : pd.DataFrame
            The dataset to fit on.
        """
        data = self.drop(data, drop_duplicates=False)

        self.fit_columns(data)
        data = self.clean(data)
        standardized = self.standardize(data, combine_target=True)
        normalized = self.normalize(standardized, combine_target=True, normalize_target=True)

        self.fit_imputer(normalized)
        normalized = self.impute(normalized)

        self.fit_reducers(normalized)
        normalized = self.reduce(normalized)
        self._total_dim = normalized.shape[-1]
        self._transformed_columns = normalized.columns

    @log_time("Transforming raw data to the desired processed data", "Transformed raw data to processed data")
    def transform(self, data: pd.DataFrame):
        """
        Complete all transforming steps of a given dataset.

        Parameters
        ----------
        data : pd.DataFrame
            The dataset to transform.
        """
        data = self.drop(data, drop_duplicates=False)

        data = self.clean(data)
        standardized = self.standardize(data, combine_target=True)
        normalized = self.normalize(standardized, combine_target=True, normalize_target=True)

        normalized = self.impute(normalized)
        normalized = self.reduce(normalized)
        discretized = self.discretize(standardized)
        normalized = self.balance(normalized, discretized)
        return normalized

    @log_time("Inversely applying all reversible steps", "Finished recovering the raw data by reversible steps")
    def inverse_transform(self, data: Union[List[List[float]], np.ndarray, pd.DataFrame, torch.Tensor]) -> pd.DataFrame:
        """
        Inversely transform from reversibly transformed data to data before cleaning.

        Parameters
        ----------
        data
            Transformed data in any format.

        Returns
        -------
        pd.DataFrame
            Recovered DataFrame.
        """
        if isinstance(data, torch.Tensor):
            data = data.numpy()
        transformed = pd.DataFrame(data, columns=self._transformed_columns)
        normalized = self.recover_reduced(transformed)
        standardized = self.inverse_normalize(normalized)
        cleaned = self.inverse_standardize(standardized)
        recovered = self.inverse_clean(cleaned)
        return recovered

    @property
    def transformed_dim(self) -> int:
        """Total number of dimensions of the transformed data."""
        return self._total_dim

    @classmethod
    @log_time("Loading data from path", "Loaded data from path")
    def load_data(cls, path: str, **kwargs) -> pd.DataFrame:
        """
        Load data as `pd.DataFrame` from path.

        Parameters
        ----------
        path : str
            The path where the data is saved.

            - If it starts with "SQL_TABLE|", an SQL table with name after "SQL_TABLE|" in the path is read.
            - If it starts with "SQL_QUERY|", an SQL-query-constructed table with query after "SQL_QUERY|" in the path
              is read.
            - If it ends with ".csv", it is understood as a CSV file.
            - If it ends with ".tsv", it is understood as a TSV file (special CSV file where \\t instead of , is used as
              the delimiter.
            - If it ends with ".pkl", it is understood as a pickle file.
            - If it ends with ".xml", it is understood as an XML file.
            - If it ends with ".html", it is understood as an HTML file.
            - If it ends with ".json", it is understood as a JSON file.
            - If it ends with ".h5", it is understood as an HDF file.
            - If it ends with one of ".xls", ".xlsx", ".xlsm", ".xlsb", ".xlt", ".xltx", ".xltm", it is understood as an
              Excel Sheet file.
        **kwargs
            The arguments to the corresponding file type in `pd.read_*`.
            The corresponding pandas readers invoked are:
            [`read_sql_table`](https://pandas.pydata.org/docs/reference/api/pandas.read_sql_table.html),
            [`read_sql_query`](https://pandas.pydata.org/docs/reference/api/pandas.read_sql_query.html),
            [`read_csv`](https://pandas.pydata.org/docs/reference/api/pandas.read_csv.html),
            [`read_pickle`](https://pandas.pydata.org/docs/reference/api/pandas.read_pickle.html),
            [`read_xml`](https://pandas.pydata.org/docs/reference/api/pandas.read_xml.html),
            [`read_html`](https://pandas.pydata.org/docs/reference/api/pandas.read_html.html),
            [`read_json`](https://pandas.pydata.org/docs/reference/api/pandas.read_json.html),
            [`read_hdf`](https://pandas.pydata.org/docs/reference/api/pandas.read_hdf.html),
            [`read_excel`](https://pandas.pydata.org/docs/reference/api/pandas.read_excel.html).
        """
        if path.startswith("SQL_TABLE|"):
            data_type = "SQL table"
            path = path[10:]
            out = pd.read_sql_table(path, **kwargs)
        elif path.startswith("SQL_QUERY|"):
            data_type = "SQL query"
            path = path[10:]
            out = pd.read_sql_query(path, **kwargs)
        elif path.endswith(".csv"):
            data_type = "CSV file"
            out = pd.read_csv(path, **kwargs)
        elif path.endswith(".tsv"):
            data_type = "TSV file"
            out = pd.read_csv(path, sep="\t", encoding="utf-8", **kwargs)
            kwargs["sep"] = "\t"
            kwargs["encoding"] = "utf-8"
        elif path.endswith(".pkl"):
            data_type = "pickle file"
            out = pd.read_pickle(path, **kwargs)
        elif path.endswith(".xml"):
            data_type = "XML file"
            out = pd.read_xml(path, **kwargs)
        elif path.endswith(".html"):
            data_type = "HTML file"
            out = pd.concat(pd.read_html(path, **kwargs))
        elif path.endswith(".json"):
            data_type = "JSON file"
            out = pd.read_json(path, **kwargs)
        elif path.endswith(".h5"):
            data_type = "HDF file"
            out = pd.DataFrame(pd.read_hdf(path, **kwargs))
        elif any(path.endswith(ext) for ext in [".xls", ".xlsx", ".xlsm", ".xlsb", ".xlt", ".xltx", ".xltm"]):
            data_type = "Excel file"
            out = pd.read_excel(path, **kwargs)
        else:
            raise NotImplementedError(f"File path {path} is not recognized as a valid data file.")
        logging.log(log.TRACE_LEVEL, f"Loaded {data_type} {path} with arguments {kwargs}.")
        return out

    def save(self, path: str):
        """
        Save the current transformer to path.

        Parameters
        ----------
        path : str
            The file path to save this transformer to.
        """
        torch.save(self, path)
        logging.info(f"Saved transformer to {path}.")
