"""Dimension reducers based on manifold methods."""

import enum
from typing import Type, Union

import numpy as np
import pandas as pd

from sklearn.base import TransformerMixin
from sklearn.manifold import Isomap, LocallyLinearEmbedding

from .base import DimReducer, DimReducerType
from ...utils import register, make_enum


class ManifoldPolicy(enum.Enum):
    """Manifold dimension-reduction policies. They come from scikit-learn `manifold` package."""

    ISO = enum.auto()
    """Isomap."""
    LLE = enum.auto()
    """Locally linear embedding."""

    @property
    def sklearn_model(self) -> Type[TransformerMixin]:
        """The corresponding scikit-learn class."""
        if self == ManifoldPolicy.ISO:
            return Isomap
        elif self == ManifoldPolicy.LLE:
            return LocallyLinearEmbedding
        raise NotImplementedError(f'There is no scikit-learn model matching dimension reduction method {self.name}.')


@register(DimReducer.registry, DimReducerType.manifold)
class ManifoldDimReducer(DimReducer):
    """Dimension reducer by Manifolds."""
    def __init__(self,
                 max_dim: int = 100,
                 policy: Union[str, ManifoldPolicy] = ManifoldPolicy.ISO,
                 **kwargs):
        """
        Parameters
        ----------
        policy : ManifoldPolicy
            The manifold algorithm.
        **kwargs
            Arguments to the scikit-learn model (
            [`Isomap`](https://scikit-learn.org/stable/modules/generated/sklearn.manifold.Isomap.html) or
            [`LocallyLinearEmbedding`](https://scikit-learn.org/stable/modules/generated/sklearn.manifold.LocallyLinearEmbedding.html)
            ) besides `n_components`. The last column in the input is used as target.
        Other arguments are inherited from the parent `DimReducer`.
        """
        super().__init__(max_dim)
        self._policy: ManifoldPolicy = make_enum(policy, ManifoldPolicy)
        self._model = self._policy.sklearn_model(n_components=max_dim, **kwargs)

    def _fit(self, original: pd.DataFrame):
        self._model.fit(original)

    def _reduce(self, original: pd.DataFrame) -> np.ndarray:
        return self._model.transform(original)

    @property
    def name(self) -> str:
        return f"{self._policy.name}(dim={self._max_dim})"
