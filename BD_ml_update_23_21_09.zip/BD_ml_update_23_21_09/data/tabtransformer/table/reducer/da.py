"""Dimension reducers based on discriminant analysis methods."""

import numpy as np
import pandas as pd
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis

from .base import DimReducer, DimReducerType
from ...utils import register


@register(DimReducer.registry, DimReducerType.lda)
class LDADimReducer(DimReducer):
    """Dimension reducer by LDA."""
    def __init__(self,
                 max_dim: int = 100,
                 **kwargs):
        """
        Parameters
        ----------
        **kwargs
            Arguments to the scikit-learn
            [`LinearDiscriminantAnalysis`](https://scikit-learn.org/stable/modules/generated/sklearn.discriminant_analysis.LinearDiscriminantAnalysis.html)
            besides `n_components`. The last column in the input is used as target.
        Other arguments are inherited from the parent `DimReducer`.
        """
        super().__init__(max_dim)
        self._model = LinearDiscriminantAnalysis(n_components=max_dim, **kwargs)

    def _fit(self, original: pd.DataFrame):
        self._model.fit(
            X=original.iloc[:, :-1],
            y=original.iloc[:, -1]
        )

    def _reduce(self, original: pd.DataFrame) -> np.ndarray:
        return self._model.transform(original.iloc[:, :-1])

    @property
    def name(self) -> str:
        return f"LDA(dim={self._max_dim})"
