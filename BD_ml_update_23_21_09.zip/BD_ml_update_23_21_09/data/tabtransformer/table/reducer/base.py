"""Common structure for dimension reducers of different algorithms."""

import enum
import logging
from abc import ABC, abstractmethod
from typing import Dict, Type, Union

import numpy as np
import pandas as pd

from ...utils import log, log_time, make_enum


class DimReducerType(enum.Enum):
    """Dimension reducer algorithm type."""

    variance_threshold = enum.auto()
    """Remove columns with very low variance."""
    decomposition = enum.auto()
    """Decomposition algorithms like PCA, SVD."""
    lda = enum.auto()
    """Linear Discriminant Analysis."""
    manifold = enum.auto()
    """Manifold algorithms."""


class DimReducer(ABC):
    """
    A single dimension reduction operation.
    """
    registry: Dict[DimReducerType, Type["DimReducer"]] = {}

    def __init__(self, max_dim: int = 100):
        """
        Initialize a dimension reducer.

        Parameters
        ----------
        max_dim: int
            The maximum dimension.
        """
        self._max_dim = max_dim

    @log_time("Fitting reducer", "Finished fitting reducer",
              start_level=log.TRACE_LEVEL, end_level=logging.DEBUG, with_name=True)
    def fit(self, original: pd.DataFrame):
        """
        Fit the dimension reducer.

        Parameters
        ----------
        original : pd.DataFrame
            The data of high dimensions.
        """
        if original.shape[-1] > max(2, self._max_dim):
            self._fit(original)

    @abstractmethod
    def _fit(self, original: pd.DataFrame):
        raise NotImplementedError()

    @log_time("Reducing by", "Finished reducing by",
              start_level=log.TRACE_LEVEL, end_level=logging.DEBUG, with_name=True)
    def reduce(self, original: pd.DataFrame) -> np.ndarray:
        """
        Reduce the data to the maximum number of dimensions.

        Parameters
        ----------
        original : pd.DataFrame
            The data of high dimensions.

        Returns
        -------
        np.ndarray
            The data after dimension reduction.
        """
        if self._max_dim is None:
            raise RuntimeError("The maximum dimension is not set yet. "
                               "Please set a value before doing the dimension reduction.")
        if original.shape[-1] <= max(2, self._max_dim):
            return original.values
        return self._reduce(original)

    @abstractmethod
    def _reduce(self, original: pd.DataFrame) -> np.ndarray:
        raise NotImplementedError()

    @log_time("Recovering reduced data by", "Finished recovering reduced data by",
              start_level=log.TRACE_LEVEL, end_level=logging.DEBUG, with_name=True)
    def recover(self, reduced: np.ndarray) -> pd.DataFrame:
        """
        Recover the data to the original number of dimensions.

        Parameters
        ----------
        reduced : np.ndarray
            The data after dimension reduction.

        Returns
        -------
        pd.DataFrame
            The data recovered.
        """
        raise RuntimeError(f"The {self.__name__} is not reversible.")

    @classmethod
    def make(cls, dr_type: Union[str, DimReducerType], **kwargs) -> "DimReducer":
        """
        Make a dimension reducer.

        Parameters
        ----------
        dr_type : str or DimReducerType
            The dimension reducer type.
        **kwargs
            Other argument to the reducer of this type.
        """
        return cls.registry[make_enum(dr_type, DimReducerType)](**kwargs)

    @property
    @abstractmethod
    def name(self) -> str:
        """A short textual description of the reducer."""
        raise NotImplementedError()
