"""Dimension reducers based on feature selection methods."""

import numpy as np
import pandas as pd
from sklearn.feature_selection import VarianceThreshold

from .base import DimReducer, DimReducerType
from ...utils import register


@register(DimReducer.registry, DimReducerType.variance_threshold)
class VTDimReducer(DimReducer):
    """
    Dimension reducer by removing columns with low variance.
    This class if reversible if parameters are set nicely.
    """
    def __init__(self,
                 *args, **kwargs):
        """
        Parameters
        ----------
        **kwargs
            Arguments to the scikit-learn
            [`VarianceThreshold`](https://scikit-learn.org/stable/modules/generated/sklearn.feature_selection.VarianceThreshold.html).
        Other arguments are inherited from the parent `DimReducer`.
        """
        super().__init__(-1)
        if "max_dim" in kwargs:
            del kwargs["max_dim"]
        self._model = VarianceThreshold(*args, **kwargs)
        self._means = None
        self._columns = None

    def _fit(self, original: pd.DataFrame):
        self._model.fit(original.values)
        self._means = original.values.mean(axis=0)
        self._columns = original.columns

    def _reduce(self, original: pd.DataFrame) -> np.ndarray:
        return self._model.transform(original)

    def recover(self, reduced: np.ndarray) -> pd.DataFrame:
        recovered = self._model.inverse_transform(reduced)
        indicator = self._model.variances_ <= self._model.threshold
        recovered[:, indicator] = self._means[indicator]
        return pd.DataFrame(
            recovered, columns=self._columns
        )

    @property
    def name(self) -> str:
        return f"VT"
