import pandas as pd
import os
from chardet import detect
import time


def generate_summary_dataset(dataset, cat_cols):
    """
    Generate a summary dataframe for the given dataset.

    This function scans through each column in the given dataset and determines the number of unique values and the count of missing values. It also determines the type of each column based on the input list of categorical columns. The summary is returned as a pandas DataFrame with each column's metadata as a row.

    Parameters
    ----------
    dataset : pd.DataFrame
        The dataset for which the summary needs to be generated. The dataframe should have named columns.

    cat_cols : list of str
        The list of column names in the dataset which are to be considered as categorical. If a column name is not in this list, it will be considered as numerical.

    Returns
    -------
    pd.DataFrame
        The summary dataframe with each row representing a column from the input dataset.
        The columns in the output dataframe are:
        "Column": The name of the column in the input dataset.
        "Unique_Count": The number of unique values in the column.
        "Missing_Count": The number of missing (NaN) values in the column.
        "Type": The type of the column, either "Categorical" or "Numerical".
    """
    unique_count = []
    missing_count = []
    columns = []
    col_type = []
    for col in dataset.columns:
        columns.append(col)
        unique_count.append(dataset[col].nunique())
        missing_count.append(dataset[col].isnull().sum())
        if col in cat_cols:
            col_type.append("Categorical")
        else:
            col_type.append("Numerical")
    summary_dataset = pd.DataFrame()
    summary_dataset["Column"] = columns
    summary_dataset["Unique_Count"] = unique_count
    summary_dataset["Missing_Count"] = missing_count
    summary_dataset["Type"] = col_type
    return summary_dataset


def get_column_dtype(df, user_info, threshold=35):
    """
    Generate a dictionary of column types in a DataFrame.

    This function analyzes the DataFrame and returns a dictionary that contains lists of column names for each data type category.
    It also supports user-defined column types through user_info. If no user-defined types are provided, the function automatically
    classifies columns based on their data types and unique counts.

    Parameters
    ----------
    df : pd.DataFrame
        The input DataFrame.

    user_info : dict
        A dictionary where each key-value pair is a category of column and a list of column names in that category. The expected keys are:
        'categorical_columns', 'continuous_columns', 'log_columns', 'integer_columns', 'mixed_columns', 'datetime_columns', 'general_columns'.

    threshold : int, optional
        The threshold for the number of unique values below which a numerical column is classified as categorical. The default value is 35.

    Returns
    -------
    dict
        A dictionary where each key-value pair is a category of column and a list of column names in that category.

    Raises
    ------
    ValueError
        If there's an overlap between the categorical columns and the mixed columns.

    *************
    NOTE: THIS FUNCTION IS ALSO PRESENT IN THE CODE MODULE. IF YOU MAKE ANY CHANGES HERE, PLEASE MAKE SURE TO REFLECT THEM THERE AS WELL.
    *************
    """
    user_categorical_col = user_info["categorical_columns"]
    user_continuous_col = user_info["continuous_columns"]
    user_log_col = user_info["log_columns"]
    user_integer_col = user_info["integer_columns"]
    user_mixed_col = user_info["mixed_columns"]
    user_datetime_col = user_info["datetime_columns"]
    user_general_col = user_info["general_columns"]
    if len(user_categorical_col) == 0 and len(user_continuous_col) == 0:
        categorical_col = df.select_dtypes(include=["object"]).columns.tolist()
        numerical_col_temp = df.select_dtypes(exclude=["object"]).columns.tolist()
        integer_col = df.select_dtypes(include=["int"]).columns.tolist()
        numerical_col = []
        for num_col in numerical_col_temp:
            unique_counts = df[num_col].nunique()
            if unique_counts < threshold:
                categorical_col.append(num_col)
            else:
                numerical_col.append(num_col)
        # Remove datetime columns from columns list
        categorical_col = [
            x for x in categorical_col if x not in list(user_datetime_col.keys())
        ]
        numerical_col = [
            x for x in numerical_col if x not in list(user_datetime_col.keys())
        ]
        if len(set(categorical_col).intersection(set(user_mixed_col.keys()))) > 0:
            raise ValueError(
                "The automatically detected categorical columns overlap with the mixed columns. Please intput the columns manually."
            )
    # If there is an overlap between the categorical and mixed columns, raise an error
    else:
        categorical_col = user_categorical_col
        numerical_col = user_continuous_col
        integer_col = user_integer_col
        if len(set(categorical_col).intersection(set(user_mixed_col.keys()))) > 0:
            raise ValueError(
                "There is an overlap between the categorical and mixed columns. Please check your input."
            )
    columns_dtype = {}
    columns_dtype["categorical_columns"] = categorical_col
    columns_dtype["continuous_columns"] = numerical_col
    columns_dtype["log_columns"] = user_log_col
    columns_dtype["integer_columns"] = integer_col
    columns_dtype["mixed_columns"] = user_mixed_col
    columns_dtype["datetime_columns"] = user_datetime_col
    columns_dtype["general_columns"] = user_general_col
    return columns_dtype


def setup_temp(folder):
    """
    Sets up a hierarchical temporary directory structure within the specified folder.

    This function creates the main directory 'temp-dataset' and 'temp-graphs' within the specified folder.
    Then, within 'temp-graphs', it sets up a further hierarchical structure, consisting of 'temp-correlation-original',
    'temp-univariate-original', 'temp-bivariate_graphs', and 'temp-multivariate_graphs'.

    The purpose of this function is to facilitate organized storage of temporary data and graphical outputs in
    the process of data analysis.

    Parameters
    ----------
    folder : str
        The path of the folder within which the temporary directory structure is to be set up.

    Raises
    ------
    FileExistsError
        If the directory specified by folder already exists.
    """
    main_dir = ["temp-dataset", "temp-graphs"]
    temp_graphs = [
        "temp-graphs/temp-correlation-original",
        "temp-graphs/temp-univariate-original",
        "temp-graphs/temp-bivariate_graphs",
        "temp-graphs/temp-multivariate_graphs",
    ]
    os.mkdir(folder)
    for i in main_dir:
        os.mkdir(os.path.join(folder, i))
    for i in temp_graphs:
        os.mkdir(os.path.join(folder, i))


def get_encoding(file):
    """
    Determines the character encoding of a file.

    This function reads a file in binary mode, checks its character encoding using the `chardet.detect` function,
    and returns the detected encoding.

    Parameters
    ----------
    file : str
        The path to the file whose encoding is to be determined.

    Returns
    -------
    str
        The character encoding of the file, as a string.
    """
    with open(file, "rb") as f:
        data = f.read()
    csv_detect = detect(data)
    encoding = csv_detect["encoding"]
    return encoding


class Timer:
    """
    Timer class for measuring elapsed time.

    This class allows you to create a timer object that measures the time between the moment it's started and the moment it's stopped.
    This can be useful for profiling code to see how long certain parts take to run.

    Parameters
    ----------
    name : str
        The name of the timer instance. This name will be used when reporting the elapsed time.

    Attributes
    ----------
    name : str
        The name of the timer.
    start : float
        The start time of the timer. This is set when the `start` method is called.
    end : float
        The end time of the timer. This is set when the `stop` method is called.
    interval : float
        The elapsed time, in seconds. This is calculated when the `stop` method is called.

    Methods
    -------
    start():
        Starts the timer.
    stop():
        Stops the timer and prints the elapsed time.
    get_time():
        Returns the elapsed time in hours, minutes, and seconds.
    """

    def __init__(self, name):
        self.name = name

    def start(self):
        self.start = time.time()

    def stop(self):
        self.end = time.time()
        self.interval = self.end - self.start
        print(f"{self.name} took {self.interval} seconds")

    def get_time(self):
        if self.interval > 60:
            mins = self.interval // 60
            if mins > 60:
                hours = mins // 60
                mins = mins % 60
                secs = self.interval % 60
                return hours, mins, secs
            else:
                secs = self.interval % 60
                return 0, mins, secs
        else:
            return 0, 0, self.interval
