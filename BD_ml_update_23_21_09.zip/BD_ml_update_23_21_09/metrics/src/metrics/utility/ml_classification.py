from sklearn.metrics import accuracy_score, precision_score, recall_score, roc_auc_score
from sklearn.ensemble import (
    AdaBoostClassifier,
    BaggingClassifier,
    ExtraTreesClassifier,
    GradientBoostingClassifier,
    RandomForestClassifier,
)
import pandas as pd
import numpy as np

# Helper function
def classification_metric_visualisation(metric1_result, r):
    """
    Generates a DataFrame visualising the classification metrics for different models.

    This function accepts a dictionary of classification metrics and rounds up the results to a specified number 
    of decimal places. The output is a pandas DataFrame with models as index and classification metrics as columns. 
    The DataFrame is cleaned and formatted for better visualization.

    Parameters
    ----------
    metric1_result : dict
        The dictionary containing classification metrics. The dictionary should be structured with model names as 
        keys and another dictionary as values. This inner dictionary should contain the metrics as keys and their 
        values as values.
    r : int
        The number of decimal places to which the metrics should be rounded.

    Returns
    -------
    pandas.DataFrame
        A DataFrame containing the classification metrics for the models, 
        rounded to the specified number of decimal places.
    """
    metric_visualisation_artifact = pd.DataFrame(metric1_result).T
    metric_visualisation_artifact.fillna(0, inplace=True)
    # Round up the results
    for i in metric_visualisation_artifact.columns:
        metric_visualisation_artifact[i] = metric_visualisation_artifact[i].round(r)
    metric_visualisation_artifact.index.names = ["Models"]
    # Clean the column names
    col_name = ["Accuracy Score", "Precision Score", "Recall Score", "ROC AUC Score"]
    metric_visualisation_artifact.columns = col_name
    return metric_visualisation_artifact


class ClassificationMetrics:
    """
    A class to compute and summarize various classification metrics for different models 
    on original and synthetic data.

    Methods
    -------
    _classification_metrics(y_pred, y_pred_proba, y_test, metric):
        Computes the specified classification metric.
    _classification_summary(x_train, y_train, x_test, y_test, classification_models, metrics):
        Trains the specified models and computes the specified metrics.
    compute(original_data_preprocessed, synthetic_data_preprocessed, classification_models, metrics, metrics_round):
        Computes the metrics on the original and synthetic data, and returns a visualization.
    """
    def _classification_metrics(y_pred, y_pred_proba, y_test, metric):
        """
        Compute the specified classification metric.

        This method calculates the specified classification metric given the predicted and actual target values.

        Parameters
        ----------
        y_pred : array-like
            The predicted target values.
        y_pred_proba : array-like
            The predicted probabilities for each class.
        y_test : array-like
            The actual target values.
        metric : str
            The metric to compute. This should be one of 'roc_auc_score', 'accuracy_score', 'precision_score', or 'recall_score'.

        Returns
        -------
        float
            The computed metric.
        """
        if metric == "roc_auc_score":
            if y_pred_proba.shape[1] == 2:
                return roc_auc_score(y_test, y_pred_proba[:, 1])  # binary
            else:
                return roc_auc_score(
                    y_test, y_pred_proba, multi_class="ovr"
                )  # multi class
        if metric == "accuracy_score":
            accuracy = accuracy_score(y_test, y_pred)
            return accuracy
        if metric == "precision_score":
            weighted_precision = precision_score(y_test, y_pred, average="weighted")
            return weighted_precision
        if metric == "recall_score":
            weighted_recall = recall_score(y_test, y_pred, average="weighted")
            return weighted_recall

    def _classification_summary(
        x_train: pd.DataFrame,
        y_train: pd.DataFrame,
        x_test: pd.DataFrame,
        y_test: pd.DataFrame,
        classification_models: list,
        metrics: list,
    ) -> dict:
        """
        Train the specified models and compute the specified metrics.

        This method fits each of the specified models to the training data, makes predictions on the test data, 
        and computes the specified metrics.

        Parameters
        ----------
        x_train : pandas.DataFrame
            The training data.
        y_train : pandas.DataFrame
            The target values for the training data.
        x_test : pandas.DataFrame
            The test data.
        y_test : pandas.DataFrame
            The target values for the test data.
        classification_models : list
            The list of models to fit. These should be strings matching the names of sklearn classifiers.
        metrics : list
            The list of metrics to compute. These should be strings matching the names of sklearn metrics.

        Returns
        -------
        dict
            A dictionary with the computed metrics for each model.
        """
        score_dict = dict()
        for i in classification_models:
            score_dict[i] = {}
            if i == "AdaBoostClassifier":
                model = AdaBoostClassifier()
            if i == "BaggingClassifier":
                model = BaggingClassifier(n_jobs=-1)
            if i == "ExtraTreesClassifier":
                model = ExtraTreesClassifier(n_jobs=-1)
            if i == "GradientBoostingClassifier":
                model = GradientBoostingClassifier()
            if i == "RandomForestClassifier":
                model = RandomForestClassifier(n_jobs=-1)

            model.fit(x_train, y_train)
            y_pred = model.predict(x_test)
            y_pred_proba = model.predict_proba(x_test)

            for metric in metrics:
                try:
                    score = ClassificationMetrics._classification_metrics(
                        y_pred, y_pred_proba, y_test, metric
                    )
                    score_dict[i][metric] = score
                except:
                    score_dict[i][metric] = np.nan

        return score_dict

    def compute(
        original_data_preprocessed: dict,
        synthetic_data_preprocessed: dict,
        classification_models: list,
        metrics: list,
        metrics_round: int,
    ):
        """
        Compute the metrics on the original and synthetic data, and return a visualization.

        This method computes the specified metrics for each of the specified models, both on the original 
        and synthetic data. The results are then visualized in a pandas DataFrame.

        Parameters
        ----------
        original_data_preprocessed : dict
            The preprocessed original data. This should be a dictionary with keys 'X_train', 'y_train', 'X_test', and 'y_test'.
        synthetic_data_preprocessed : dict
            The preprocessed synthetic data. This should be a dictionary with keys 'X_train', 'y_train', 'X_test', and 'y_test'.
        classification_models : list
            The list of models to fit. These should be strings matching the names of sklearn classifiers.
        metrics : list
            The list of metrics to compute. These should be strings matching the names of sklearn metrics.
        metrics_round : int
            The number of decimal places to which the metrics should be rounded in the visualization.

        Returns
        -------
        pandas.DataFrame, pandas.DataFrame
            Two pandas DataFrames with the computed metrics for the original and synthetic data, respectively.
        """
        # Original data
        classification_summary_original_data = (
            ClassificationMetrics._classification_summary(
                original_data_preprocessed["X_train"],
                original_data_preprocessed["y_train"],
                original_data_preprocessed["X_test"],
                original_data_preprocessed["y_test"],
                classification_models,
                metrics,
            )
        )

        classification_summary_original_data = classification_metric_visualisation(
            classification_summary_original_data, metrics_round
        )

        # Synthetic data
        classification_summary_synthetic_data = (
            ClassificationMetrics._classification_summary(
                synthetic_data_preprocessed["X_train"],
                synthetic_data_preprocessed["y_train"],
                synthetic_data_preprocessed["X_test"],
                synthetic_data_preprocessed["y_test"],
                classification_models,
                metrics,
            )
        )

        classification_summary_synthetic_data = classification_metric_visualisation(
            classification_summary_synthetic_data, metrics_round
        )

        return (
            classification_summary_original_data,
            classification_summary_synthetic_data,
        )
