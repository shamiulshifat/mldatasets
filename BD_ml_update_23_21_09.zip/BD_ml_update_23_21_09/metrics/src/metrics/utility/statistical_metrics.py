from typing import List
import pandas as pd
from scipy.stats import wasserstein_distance, entropy, chisquare
from scipy.spatial.distance import jensenshannon
from metrics.src.utils.logs import log

logger = log(name="stats", path="./logs/", file="ml_logs.logs")

SAVE_LOCATION = "./metrics/src/metrics/temp/temp-dataset/"


def cs_metric_visualisation(cs_metric, r, log=True, save=True):
    """
    This function performs visualization and optional logging and saving of Chi-Square test metrics. 
    It accepts a matrix of Chi-Square test statistics, rounds them to a specified precision, 
    and saves them to a CSV file if desired.

    Parameters:
    ----------
    cs_metric : array-like
        A matrix where each row represents a feature and its Chi-Square test statistic.

    r : int
        The number of decimal places to which the Chi-Square test statistics should be rounded.

    log : bool, optional
        If True (default), logs the Chi-Square test statistics using the logger. 

    save : bool, optional
        If True (default), saves the Chi-Square test statistics to a CSV file in the location specified by SAVE_LOCATION.

    Returns:
    -------
    cs_metric : DataFrame
        A pandas DataFrame containing the features and their rounded Chi-Square test statistics.

    Side-effects:
    ------------
    If log is True, this function will log the Chi-Square Test Statistic information.
    If save is True, this function will write a CSV file to the specified SAVE_LOCATION.
    """
    cs_metric = pd.DataFrame(cs_metric)
    cs_metric.columns = ["Features", "CS-Test Statistic"]
    for i in cs_metric.columns:
        if i != "Features":
            cs_metric[i] = cs_metric[i].round(r)
    if save:
        cs_metric.to_csv(f"{SAVE_LOCATION}cs_metric.csv", index=False)
    if log:
        logger.info("Chi-Square Test Statistic:")
        logger.info(cs_metric)
    return cs_metric


def wd_metric_visualisation(wd_metric, r, log=True, save=True):
    # Wasserstein Distance
    """
    This function performs visualization and optional logging and saving of Wasserstein Distance metrics. 
    It accepts a matrix of Wasserstein Distance values, rounds them to a specified precision, 
    and saves them to a CSV file if desired.

    Parameters:
    ----------
    wd_metric : array-like
        A matrix where each row represents a feature and its Wasserstein Distance.

    r : int
        The number of decimal places to which the Wasserstein Distance should be rounded.

    log : bool, optional
        If True (default), logs the Wasserstein Distance values using the logger. 

    save : bool, optional
        If True (default), saves the Wasserstein Distance values to a CSV file in the location specified by SAVE_LOCATION.

    Returns:
    -------
    wd_metric : DataFrame
        A pandas DataFrame containing the features and their rounded Wasserstein Distance values.

    Side-effects:
    ------------
    If log is True, this function will log the Wasserstein Distance information.
    If save is True, this function will write a CSV file to the specified SAVE_LOCATION.
    """
    wd_metric = pd.DataFrame(wd_metric)
    wd_metric.columns = ["Features", "Wasserstein Distance"]
    wd_metric["Wasserstein Distance"] = wd_metric["Wasserstein Distance"].round(r)
    if save:
        wd_metric.to_csv(f"{SAVE_LOCATION}wd_metric.csv", index=False)
    if log:
        logger.info("Wasserstein Distance:")
        logger.info(wd_metric)
    return wd_metric


def kld_metric_visualisation(kld_metric, r, log=False, save=True):
    # Kullback-Leibler Divergence
    """
    This function performs visualization and optional logging and saving of Kullback-Leibler (KL) Divergence metrics. 
    It accepts a matrix of KL Divergence values, rounds them to a specified precision, 
    and saves them to a CSV file if desired.

    Parameters:
    ----------
    kld_metric : array-like
        A matrix where each row represents a feature and its KL Divergence value.

    r : int
        The number of decimal places to which the KL Divergence values should be rounded.

    log : bool, optional
        If True, logs the KL Divergence values using the logger. Default is False.

    save : bool, optional
        If True (default), saves the KL Divergence values to a CSV file in the location specified by SAVE_LOCATION.

    Returns:
    -------
    kld_metric : DataFrame
        A pandas DataFrame containing the features and their rounded KL Divergence values.

    Side-effects:
    ------------
    If log is True, this function will log the Kullback-Leibler Divergence information.
    If save is True, this function will write a CSV file to the specified SAVE_LOCATION.
    """
    kld_metric = pd.DataFrame(kld_metric)
    kld_metric.columns = ["Features", "KL-Divergence"]
    kld_metric["KL-Divergence"] = kld_metric["KL-Divergence"].round(r)
    if save:
        kld_metric.to_csv(f"{SAVE_LOCATION}kld_metric.csv", index=False)
    if log:
        logger.info("Kullback-Leibler Divergence:")
        logger.info(kld_metric)
    return kld_metric


def jsd_metric_visualisation(jsd_metric, r, log=True, save=True):
    # Jensen-Shannon Divergence
    """
    This function performs visualization and optional logging and saving of Jensen-Shannon Divergence metrics. 
    It accepts a matrix of Jensen-Shannon Divergence values, rounds them to a specified precision, 
    and saves them to a CSV file if desired.

    Parameters:
    ----------
    jsd_metric : array-like
        A matrix where each row represents a feature and its Jensen-Shannon Divergence value.

    r : int
        The number of decimal places to which the Jensen-Shannon Divergence values should be rounded.

    log : bool, optional
        If True (default), logs the Jensen-Shannon Divergence values using the logger. 

    save : bool, optional
        If True (default), saves the Jensen-Shannon Divergence values to a CSV file in the location specified by SAVE_LOCATION.

    Returns:
    -------
    jsd_metric : DataFrame
        A pandas DataFrame containing the features and their rounded Jensen-Shannon Divergence values.

    Side-effects:
    ------------
    If log is True, this function will log the Jensen Shannon Divergence information.
    If save is True, this function will write a CSV file to the specified SAVE_LOCATION.
    """
    jsd_metric = pd.DataFrame(jsd_metric)
    jsd_metric.columns = ["Features", "Jensen Shannon Distance"]
    jsd_metric["Jensen Shannon Distance"] = jsd_metric["Jensen Shannon Distance"].round(
        r
    )
    if save:
        jsd_metric.to_csv(f"{SAVE_LOCATION}jsd_metric.csv", index=False)
    if log:
        logger.info("Jensen Shannon Divergence:")
        logger.info(jsd_metric)
    return jsd_metric


class StatisticalMetrics:
    """
    This class provides a set of statistical metrics to compare real and synthetic data. It includes metrics like 
    Jensen-Shannon distance, Wasserstein distance, Chi-Squared test statistic and KL-Divergence.

    Attributes
    ----------
    real_data : pd.DataFrame
        The actual data to be compared against the synthetic data.
    fake_data : pd.DataFrame
        The synthetic data generated by a model or any other means.
    categorical_cols : List[str]
        The list of column names in the dataframe that are categorical.
    bivariate_pairs : List[List]
        The list of pairs for which to calculate the bivariate metrics.

    Methods
    -------
    get_frequencies(real: pd.Series, fake: pd.Series) -> list
        Returns the frequency distribution of the real and synthetic data.
    _preprocess_categorical_columns() -> None
        Processes the categorical columns of real and synthetic data by replacing categorical values with their index.
    jensen_shannon_distance() -> list
        Returns the Jensen-Shannon distance between the real and synthetic data.
    wasserstein_distance() -> list
        Returns the Wasserstein distance between the real and synthetic data.
    chi_squared_statistic() -> list
        Returns the chi-squared test statistics for categorical columns.
    kl_divergence() -> list
        Returns the KL-Divergence between the real and synthetic data.
    bivariate_metrics() -> pd.DataFrame
        Returns the bivariate metrics for the pairs of columns specified.
    compute_metrics() -> None
        Computes all the metrics and optionally logs and saves them.
    """
    def __init__(
        self,
        real_data: pd.DataFrame,
        fake_data: pd.DataFrame,
        categorical_cols: List[str],
        bivariate_pairs: List[List],
    ) -> None:
        self.real_data = real_data
        self.fake_data = fake_data
        self.categorical_cols = categorical_cols
        self.bivariate_pairs = bivariate_pairs
        self._preprocess_categorical_columns()

    """Utility to get histogram of a column. 
    (To view this on non-IPython interfaces, install the tkinter library. For Ubuntu based systems use the command, 'sudo apt-get install python3-tk')"""

    def get_frequencies(self, real: pd.Series, fake: pd.Series) -> list:
        real_frequency = real.value_counts()
        fake_frequency = fake.value_counts()
        all_index = real_frequency.index.union(fake_frequency.index)
        all_index = all_index.sort_values()
        real_frequency = real_frequency.reindex(all_index, fill_value=0)
        fake_frequency = fake_frequency.reindex(all_index, fill_value=0)
        real_frequency = real_frequency / sum(real_frequency)
        fake_frequency = fake_frequency / sum(fake_frequency)
        return real_frequency, fake_frequency

    """Utility function to replace categorical values with their index"""

    def _preprocess_categorical_columns(self) -> None:
        if self.categorical_cols == None or self.categorical_cols == []:
            return None
        for column in self.categorical_cols:
            series = self.real_data.loc[:, column].astype("category")
            self.real_data[column] = series.cat.codes
            fake_series = self.fake_data.loc[:, column].astype("category")
            self.fake_data[column] = fake_series.cat.codes

    """Jensen Shannon Distance used between real and synthetic data"""

    def jensen_shannon_distance(self) -> list:
        js_dist = []
        for column in self.real_data.columns:
            real_frequency, fake_frequency = self.get_frequencies(
                self.real_data[column], self.fake_data[column]
            )
            js_distance = jensenshannon(real_frequency, fake_frequency)
            js_dist.append(
                {
                    "column": column,
                    "js_dist_value": js_distance,
                }
            )
        return js_dist

    """Wasserstein Distance used between real and synthetic data"""

    def wasserstein_distance(self) -> list:
        w_dist = []
        for column in self.real_data.columns:
            dist = wasserstein_distance(self.real_data[column], self.fake_data[column])
            w_dist.append({"column": column, "wasserstein_dist": dist})
        return w_dist

    """Chi-Squared test statistic used for categorical columns"""

    def chi_squared_statistic(self) -> list:
        cs_test = []
        for column in self.categorical_cols:
            real_freq, fake_freq = self.get_frequencies(
                self.real_data[column],
                self.fake_data[column],
            )
            chi_squared_stat, p_value = chisquare(fake_freq, real_freq)
            cs_test.append(
                {
                    "column": column,
                    "cs_test_statistic": p_value,
                }
            )
        return cs_test

    """KL-Divergence values between real and synthetic data"""

    def kl_divergence(self) -> list:
        kl_list = []
        for column in self.real_data.columns:
            real_freq, fake_freq = self.get_frequencies(
                self.real_data[column], self.fake_data[column]
            )
            kl_div = entropy(real_freq, qk=fake_freq)
            kl_list.append({"column": column, "kl_divergence": kl_div})
        return kl_list

    def bivariate_metrics(self):
        df_real = self.real_data.copy()
        df_fake = self.fake_data.copy()
        pair_list = []
        corr_real_list = []
        corr_fake_list = []
        for pair in self.bivariate_pairs:
            df_real_temp = df_real[pair].copy(deep=True)
            df_fake_temp = df_fake[pair].copy(deep=True)
            corr_real = df_real_temp.corr().iloc[0, 1].round(3)
            corr_fake = df_fake_temp.corr().iloc[0, 1].round(3)
            pair_str = f"{pair[0]}-{pair[1]}"
            pair_list.append(pair_str)
            corr_real_list.append(corr_real)
            corr_fake_list.append(corr_fake)
        df = pd.DataFrame(
            {
                "Pair": pair_list,
                "Correlation Original": corr_real_list,
                "Correlation Synthetic": corr_fake_list,
            }
        )
        return df

    def compute_metrics(self) -> None:
        print_metrics = True
        save_metrics = True
        if len(self.categorical_cols) != 0:
            chi_sq = self.chi_squared_statistic()
            wd = self.wasserstein_distance()
            jsd = self.jensen_shannon_distance()
            cs_metric_visualisation(chi_sq, 3, print_metrics, save_metrics)
            wd_metric_visualisation(wd, 3, print_metrics, save_metrics)
            jsd_metric_visualisation(jsd, 3, print_metrics, save_metrics)
        else:
            wd = self.wasserstein_distance()
            jsd = self.jensen_shannon_distance()
            wd_metric_visualisation(wd, 3, print_metrics, save_metrics)
            jsd_metric_visualisation(jsd, 3, print_metrics, save_metrics)
        if len(self.bivariate_pairs) > 0:
            bivariate_metrics = self.bivariate_metrics()
            bivariate_metrics.to_csv(
                f"{SAVE_LOCATION}bivariate_metrics.csv", index=False
            )
